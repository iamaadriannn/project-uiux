<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Forgot Password - ConnecTech</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', sans-serif;
    }

    html, body {
      height: 100%;
    }

    .bg-image {
      position: relative;
      height: 100vh;
      background-image: url('login.jpg'); 
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      background-color: #888;
    }

    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      background-color: rgba(0, 0, 0, 0.4);
    }

    .branding {
      position: absolute;
      top: 50%;
      left: 10%;
      transform: translateY(-50%);
      color: #fff;
    }

    .branding h1 {
      font-size: 48px;
      font-weight: bold;
    }

    .branding p {
      font-size: 18px;
      margin-top: 8px;
    }

    .form-box {
      position: absolute;
      top: 50%;
      right: 10%;
      transform: translateY(-50%);
      background-color: rgba(255, 255, 255, 0.5); /* transparan 50% */
      padding: 30px;
      border-radius: 32px; /* border radius 32px */
      width: 300px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      color: #fff;
    }

    .form-box h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #fff;
    }

    .form-box label {
      font-size: 14px;
      color: #fff;
      display: block;
      margin-bottom: 5px;
    }

    .form-box input {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 6px;
    }

    .form-box .info-text {
      font-size: 13px;
      color: #f0f0f0;
      margin-bottom: 15px;
      margin-top: -10px;
      text-align: left;
    }


    .form-box button {
      width: 100%;
      padding: 10px;
      background-color: #2a4e7d;
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .form-box button:hover {
      background-color: #1f3c61;
    }

    .form-box .result {
      margin-top: 15px;
      font-size: 14px;
      color: #333;
      text-align: center;
    }

    @media (max-width: 768px) {
      .branding, .form-box {
        left: 5%;
        right: 5%;
        width: 90%;
        transform: translateY(-50%);
      }

      .branding h1 {
        font-size: 36px;
      }

      .form-box {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
  <div class="bg-image">
    <div class="overlay"></div>

    <div class="branding">
      <h1>ConnecTech</h1>
      <p>Powering Connection Without Limits</p>
    </div>

    <div class="form-box">
      <h2>FORGOT PASSWORD</h2>
      <form onsubmit="handleForgot(event)">
        <label for="email">Email</label>
        <input type="email" id="email" placeholder="Enter your email" required />
        <p class="info-text">Enter your Email to send your OTP Password</p>
        <button type="submit">SEND</button>
        <div class="result" id="result"></div>
      </form>

    </div>
  </div>

  <script>
    function generateOTP(length = 6) {
      let otp = '';
      for (let i = 0; i < length; i++) {
        otp += Math.floor(Math.random() * 10);
      }
      return otp;
    }

    function handleForgot(event) {
      event.preventDefault();

      const email = document.getElementById("email").value.trim();
      const result = document.getElementById("result");
      const userData = JSON.parse(localStorage.getItem("dummyUser"));

      if (!userData) {
        result.textContent = "⚠️ No account found. Please register first.";
        result.style.color = "red";
        return;
      }

      if (email === userData.email) {
        const otp = generateOTP();
        localStorage.setItem("otpCode", otp);
        localStorage.setItem("emailForReset", email);

        // Arahkan ke halaman verifikasi tanpa query string
        window.location.href = "verifikasi.php";
      } else {
        result.textContent = "❌ Email not found.";
        result.style.color = "red";
      }
    }
  </script>
</body>
</html>
