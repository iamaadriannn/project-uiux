
export const chatData = {
  "user-experience": {
    title: "User Experience",
    members: "345 Members • Public Discussion",
    tags: ["UX", "Design"],
    messages: [
      { sender: "Citra Dewi", initial: "CD", bg: "from-blue-500 to-purple-500", content: "The onboarding flow feels jumpy—should we consider a progress indicator?", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Yudha Pratama", initial: "YP", bg: "from-blue-500 to-purple-500", content: "Yes, and some tooltips get covered by the header—can we move them below?", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Intan Sari", initial: "IS", bg: "from-blue-500 to-purple-500", content: "The heatmap shows many users skip step 2—maybe the content is unclear?", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Raka Firmansyah", initial: "RF", bg: "from-blue-500 to-purple-500", content: "Add labels like 'Step 2 of 4' so users know where they are.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Siska Larasati", initial: "SL", bg: "from-blue-500 to-purple-500", content: "Agreed! Also, font size feels small on mobile—needs improvement.", bubbleColor: "bg-red-50 border-red-200" }
    ]
  },
  "website-laravel-beginner": {
    title: "Website Laravel Beginner",
    members: "400 Members • Public Discussion",
    tags: ["Laravel", "PHP", "Web Dev", "Beginner", "Backend"],
    messages: [
      { sender: "Deni Kusuma", initial: "DK", bg: "from-blue-500 to-purple-500", content: "I'm stuck on migration: 'users' table class not found error.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Mira Anindya", initial: "MA", bg: "from-blue-500 to-purple-500", content: "Check namespace—`App\\Models` is often mistyped as `App\\Model`.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Yoga Saputra", initial: "YS", bg: "from-blue-500 to-purple-500", content: "Try running `composer dump-autoload`—usually fixes it.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Nina Kartika", initial: "NK", bg: "from-blue-500 to-purple-500", content: "Check your PHP version—at least 8.1 is needed for some packages.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Andi Riyadi", initial: "AR", bg: "from-blue-500 to-purple-500", content: "Start with `php artisan serve` for easier debugging before deploy.", bubbleColor: "bg-red-50 border-red-200" }
    ]
  },
  "back-end-dev-sharing": {
    title: "Back-End Dev Sharing",
    members: "6564 Members • Public Discussion",
    tags: ["Backend", "Sharing"],
    messages: [
      { sender: "Fadil Hidayat", initial: "FH", bg: "from-blue-500 to-purple-500", content: "Just integrated Redis but cache hit rate is still low—any advice?", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Lia Putri", initial: "LP", bg: "from-blue-500 to-purple-500", content: "Use consistent keys and add userId prefix for user-specific data.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Rizky Darmawan", initial: "RD", bg: "from-blue-500 to-purple-500", content: "Watch out for TTL—too short causes frequent cache misses.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Eka Wardhani", initial: "EW", bg: "from-blue-500 to-purple-500", content: "Use cache-aside pattern: check DB first, then update cache.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Bima Sakti", initial: "BS", bg: "from-blue-500 to-purple-500", content: "Log cache hits/misses—it really helps performance tracking.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Nadya Rahma", initial: "NR", bg: "from-blue-500 to-purple-500", content: "Built a cache monitoring dashboard—real-time insights help.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Samuel Tan", initial: "ST", bg: "from-blue-500 to-purple-500", content: "Try Redis pipelining for more efficient batch operations.", bubbleColor: "bg-red-50 border-red-200" }
    ]
  },
  "front-end-development": {
    title: "Front-End Development",
    members: "1034 Members • Private Discussion",
    tags: ["React", "Vue", "Angular", "CSS", "JavaScript"],
    messages: [
      { sender: "Tiara Lestari", initial: "TL", bg: "from-blue-500 to-purple-500", content: "Debugging state in the chat component is hard—any Redux users?", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Darwin Prakoso", initial: "DP", bg: "from-blue-500 to-purple-500", content: "React Query is great for fetching—it auto-caches and refetches.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Sinta Novita", initial: "SN", bg: "from-blue-500 to-purple-500", content: "CSS Grid still struggles in IE11—fallback to Flexbox is safer.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Galuh Wicaksono", initial: "GW", bg: "from-blue-500 to-purple-500", content: "Safari animations feel laggy—try using `will-change: transform`.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Mirza Fahlevi", initial: "MF", bg: "from-blue-500 to-purple-500", content: "Don’t forget ARIA roles for accessibility in custom components.", bubbleColor: "bg-red-50 border-red-200" }
    ]
  },
  "security-awareness": {
    title: "Security Awareness",
    members: "575 Members • Private Discussion",
    tags: ["Security", "Cybersecurity", "Best Practices"],
    messages: [
      { sender: "Heri Kurniawan", initial: "HK", bg: "from-blue-500 to-purple-500", content: "Always add CSRF token on external forms—it’s often missed.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Nadia Salsabila", initial: "NS", bg: "from-blue-500 to-purple-500", content: "Make sure to configure Content-Security-Policy headers.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Vino Pratama", initial: "VP", bg: "from-blue-500 to-purple-500", content: "Set minimum password length to 12 characters + symbols.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Lia Handayani", initial: "LH", bg: "from-blue-500 to-purple-500", content: "Encrypt sensitive DB fields with AES-256 or better.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Deni Pramana", initial: "DP", bg: "from-blue-500 to-purple-500", content: "Log user request history every 24 hours for audit trail.", bubbleColor: "bg-red-50 border-red-200" }
    ]
  },
  "user-interface-design": {
    title: "User Interface Design",
    members: "6564 Members • Public Discussion",
    tags: ["UI/UX", "Design"],
    messages: [
      { sender: "Rani Oktaviani", initial: "RO", bg: "from-blue-500 to-purple-500", content: "Padding between cards feels tight—try 16px all around.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Gerry Mahendra", initial: "GM", bg: "from-blue-500 to-purple-500", content: "Secondary hover color lacks contrast—needs update.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Fiona Adrian", initial: "FA", bg: "from-blue-500 to-purple-500", content: "Heading font size on mobile is too big—check breakpoints.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Tika Wulandari", initial: "TW", bg: "from-blue-500 to-purple-500", content: "Footer icon style is inconsistent—mix of outline and filled.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Yanto Herlambang", initial: "YH", bg: "from-blue-500 to-purple-500", content: "Add hover state transition to buttons—opacity 0.2s works.", bubbleColor: "bg-red-50 border-red-200" }
    ]
  },
  "rest-api": {
    title: "REST API",
    members: "3250 Members • Public Discussion",
    tags: ["FrontEnd", "BackEnd", "WebDev"],
    messages: [
      { sender: "Wulan Anggraeni", initial: "WA", bg: "from-blue-500 to-purple-500", content: "Should REST APIs always return 200? I use 201 for new resources.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Bagus Aditya", initial: "BA", bg: "from-blue-500 to-purple-500", content: "201 is correct for POST; use 200 for successful GET or PUT.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Fitrah Ayunda", initial: "FA", bg: "from-blue-500 to-purple-500", content: "Keep the response structure consistent: `data`, `message`, `error`.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Yusuf Maulana", initial: "YM", bg: "from-blue-500 to-purple-500", content: "Laravel API Resources can help structure responses cleanly.", bubbleColor: "bg-red-50 border-red-200" }
    ]
  },
  "ai": {
    title: "AI Model",
    members: "4250 Members • Public Discussion",
    tags: ["Artificial Intelligence", "Machine Learning"],
    messages: [
      { sender: "Nadia Wulandari", initial: "NW", bg: "from-blue-500 to-purple-500", content: "My model overfits—high accuracy but bad test results.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Rizal Firmansyah", initial: "RF", bg: "from-blue-500 to-purple-500", content: "Try dropout or L2 regularization to reduce overfitting.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Winda Sari", initial: "WS", bg: "from-blue-500 to-purple-500", content: "Normalize feature values—unbalanced data can skew learning.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Handi Prakoso", initial: "HP", bg: "from-blue-500 to-purple-500", content: "Use data augmentation for image datasets to boost generalization.", bubbleColor: "bg-red-50 border-red-200" }
    ]
  },
  "front-end": {
    title: "Front End",
    members: "3300 Members • Public Discussion",
    tags: ["FrontEnd", "BackEnd"],
    messages: [
      { sender: "Zahra Amelia", initial: "ZA", bg: "from-blue-500 to-purple-500", content: "What's the go-to solution for state management in React?", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Arif Nugraha", initial: "AN", bg: "from-blue-500 to-purple-500", content: "`useState` + `useContext` is enough for small apps. For large, use Zustand or Redux.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Laila Kurnia", initial: "LK", bg: "from-blue-500 to-purple-500", content: "TanStack Query is great for managing remote data states.", bubbleColor: "bg-red-50 border-red-200" },
      { sender: "Kevin Gunawan", initial: "KG", bg: "from-blue-500 to-purple-500", content: "Add error boundaries—some async issues silently break apps.", bubbleColor: "bg-red-50 border-red-200" }
    ]
  }
};
