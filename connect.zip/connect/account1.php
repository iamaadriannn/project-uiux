<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ConnecTech - Tech Discussion Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Afacad&display=swap"
        rel="stylesheet">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            1: '#205781',
                            2: '#FFFFFF'
                        },
                        secondary: {
                            1: '#CBEAFA',
                            2: '#468CC1'
                        },
                        tertiary: {
                            1: '#FEFCF4',
                            2: '#112C41'
                        }
                    }
                }
            }
        }
    </script>
    <style>
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-fade-in-up {
            animation: fadeInUp 0.6s ease-out;
        }

        .animate-delay-100 {
            animation-delay: 0.1s;
        }

        .animate-delay-200 {
            animation-delay: 0.2s;
        }

        .animate-delay-300 {
            animation-delay: 0.3s;
        }

        /* Custom scrollbar */
        .custom-scrollbar::-webkit-scrollbar {
            height: 8px;
        }

        .custom-scrollbar::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 10px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
    </style>
</head>

<body class="flex flex-col h-screen bg-[#CBEAFA]">
    <?php include 'navbar.php'; ?>

    <div class=" flex flex-1 overflow-hidden">
        <?php include 'sidebar.php'; ?>

        <main class="ml-64 p-6 pt-20 space-y-10 overflow-x-auto font-[Afacad] ">
            <!-- Konten -->
            <div class="flex-1 p-6">
                <div class="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-lg">
                    <h2 class="text-2xl font-semibold text-center mb-6 text-[#1e3d59]">Profil Saya</h2>

                    <div class="profile-info text-center mb-6">
                        <img src="https://i.ibb.co/ZJ0kx4T/user-icon.png" alt="User" class="w-24 h-24 mx-auto rounded-full mb-2" />
                        <h3 id="displayName" class="text-lg font-bold mt-2">Nama Pengguna</h3>
                        <p id="displayRole" class="text-sm text-gray-500">Role</p>
                    </div>

                    <form onsubmit="updateAccount(event)" class="space-y-4">
                        <div>
                            <label for="name" class="font-semibold">Nama Lengkap</label>
                            <input type="text" id="name" class="w-full p-2 border rounded" readonly />
                        </div>

                        <div>
                            <label for="email" class="font-semibold">Email</label>
                            <input type="email" id="email" placeholder="Email baru" class="w-full p-2 border rounded" />
                        </div>

                        <div>
                            <label for="password" class="font-semibold">Password Baru</label>
                            <input type="password" id="password" placeholder="Kosongkan jika tidak ingin diubah" class="w-full p-2 border rounded" />
                        </div>

                        <div>
                            <label for="confirmPassword" class="font-semibold">Konfirmasi Password Baru</label>
                            <input type="password" id="confirmPassword" placeholder="Ulangi password baru" class="w-full p-2 border rounded" />
                        </div>

                        <div class="flex justify-between mt-6 gap-4 flex-wrap">
                            <button type="submit" class="bg-[#1e3d59] text-white px-4 py-2 rounded font-semibold">Simpan Perubahan</button>
                            <button type="button" class="bg-red-600 text-white px-4 py-2 rounded font-semibold" onclick="logout()">Logout</button>
                        </div>
                    </form>
                </div>
            </div>


            <!-- Script -->
            <script>
                if (localStorage.getItem("isLoggedIn") !== "true") {
                    alert("Silakan login terlebih dahulu.");
                    window.location.href = "login.html";
                }

                const userData = JSON.parse(localStorage.getItem("dummyUser")) || {};
                document.getElementById("name").value = userData.name || "";
                document.getElementById("email").value = userData.email || "";
                document.getElementById("displayName").textContent = userData.name || "Nama Pengguna";
                document.getElementById("displayRole").textContent = userData.role || "Pengguna";

                function updateAccount(event) {
                    event.preventDefault();

                    const newEmail = document.getElementById("email").value.trim();
                    const newPassword = document.getElementById("password").value.trim();
                    const confirmPassword = document.getElementById("confirmPassword").value.trim();

                    if (newPassword && newPassword !== confirmPassword) {
                        alert("Konfirmasi password tidak cocok!");
                        return;
                    }

                    if (!newEmail && !newPassword) {
                        alert("Silakan isi email atau password untuk memperbarui.");
                        return;
                    }

                    if (newEmail) userData.email = newEmail;
                    if (newPassword) userData.password = newPassword;

                    localStorage.setItem("dummyUser", JSON.stringify(userData));
                    alert("Data akun berhasil diperbarui!");
                    location.reload();
                }

                function logout() {
                    if (confirm("Yakin ingin logout?")) {
                        localStorage.removeItem("isLoggedIn");
                        window.location.href = "login.php";
                    }
                }
            </script>
        </main>
    </div> x