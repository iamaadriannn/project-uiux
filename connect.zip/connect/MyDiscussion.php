<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ConnecTech - Discussion Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            1: '#205781',
                            2: '#FFFFFF'
                        },
                        secondary: {
                            1: '#CBEAFA',
                            2: '#468CC1'
                        },
                        tertiary: {
                            1: '#FEFCF4',
                            2: '#112C41'
                        }
                    }
                }
            }
        }
    </script>
    <style>
        .chat-bubble {
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .active-discussion {
            border: 2px solid #205781;
        }

        .chat-bubble {
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .active-discussion {
            border: 2px solid #205781;
        }

        /* Custom bubble colors */
        .bg-red-50 {
            background-color: #468CC1 !important;
            border-color: #205781 !important;
        }

        .bg-green-50 {
            background-color: #205781 !important;
            border-color: #205781 !important;
        }

        /* Gradient overrides */
        .from-blue-500 {
            --tw-gradient-from: #205781 !important;
        }

        .to-purple-500 {
            --tw-gradient-to: #205781 !important;
        }

        .from-green-500 {
            --tw-gradient-from: #468CC1 !important;
        }

        .to-teal-500 {
            --tw-gradient-to: #468CC1 !important;
        }

        /* “You” messages float right */
        .you-message {
            margin-left: auto;
        }

        .you-message .flex-row-reverse {
            margin-left: auto;
        }

        /* Show edit/delete on hover */
        .chat-bubble:hover .edit-btn,
        .chat-bubble:hover .delete-btn {
            opacity: 1 !important;
        }

        textarea {
            resize: none;
            min-height: 40px;
            max-height: 200px;
        }
    </style>
</head>

<body class="bg-gray-50 font-sans">
    <!-- Header -->
    <?php include 'navbar.php'; ?>
    <div class="flex flex-col md:flex-row h-screen overflow-hidden">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Main Content -->
        <main class="ml-64 flex-1 flex overflow-hidden">
            <!-- Discussion Groups -->
            <div class="w-full md:w-96 overflow-y-auto">
                <div class="sticky top-0 overflow-y-auto">
                    <div class="p-6  border-primary-1-200 bg-secondary-1">
                        <h2 class="text-xl font-semibold text-tertiary-2">Discussion Groups</h2>
                    </div>
                </div>

                <div class="p-5 space-y-4" style="background-color: #CBEAFA">
                    <div id="discussions-container" class="gap-6">
                        <!-- Loading indicator that will be replaced by JavaScript -->
                        <div class="col-span-full text-center py-10">
                            <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto mb-4"></div>
                            <p class="text-gray-600">Loading discussions...</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Chat Area -->
            <div id="chatArea" class="w-full md:flex-1 flex flex-col bg-gray-10">
                <!-- Chat Header -->
                <div class="sticky top-0 bg-white border-b border-gray-200 p-4 z-10">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 id="chatTitle" class="font-semibold text-tertiary-2">Select a Discussion Group</h3>
                            <p id="chatMembers" class="text-sm text-secondary-2">Please choose a group to start chatting</p>
                        </div>
                        <div id="chatTags" class="flex space-x-2">
                            <!-- Tags will be inserted here -->
                        </div>
                    </div>
                </div>

                <!-- Chat Messages -->
                <div id="chatMessages" class="flex-1 flex flex-col items-center justify-center p-4 text-center text-gray-500">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    </svg>
                    <h4 class="font-medium text-secondary-2">No group selected</h4>
                    <p class="text-sm mt-1 max-w-md">Choose a discussion group from the left panel to view and participate in conversations</p>
                </div>

                <!-- Chat Input -->
                <div id="chatInput" class="sticky bottom-0 bg-white border-t border-gray-200 p-4 hidden">
                    <form id="chatInputForm" class="flex items-center space-x-3">
                        <div class="flex-1 relative">
                            <input
                                id="chatMessageInput"
                                type="text"
                                placeholder="Enter Message..."
                                class="w-full bg-primary-2 border border-primary-1 rounded-full px-4 py-3 pr-12 focus:outline-none focus:ring-2 focus:ring-secondary-2 focus:border-transparent"
                                required>
                        </div>
                        <button
                            type="submit"
                            class="bg-primary-1 text-white p-3 rounded-full">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                            </svg>
                        </button>
                    </form>
                </div>
            </div>

            <script type="module">
                import {
                    chatData
                } from './chatData.js';

                // Fungsi untuk menambahkan pesan baru
                function addNewMessage(groupId, sender, message) {
                    const isYou = sender === "You"; // Tentukan apakah pengirim adalah Anda

                    const newMessage = {
                        sender: sender,
                        initial: sender.charAt(0),
                        bg: isYou ? "from-green-500 to-teal-500" : "from-blue-500 to-purple-500",
                        content: message,
                        bubbleColor: isYou ? "bg-green-50" : "bg-blue-50 border-blue-200",
                        isYou: isYou,
                        timestamp: new Date().toISOString() // Tambahkan timestamp
                    };

                    // Tambahkan ke chatData
                    chatData[groupId].messages.push(newMessage);

                    // Refresh tampilan
                    loadChat(groupId);

                    // Simpan ke localStorage
                    localStorage.setItem('chatData', JSON.stringify(chatData));
                }

                // Fungsi untuk setup input chat
                function setupChatInput(groupId) {
                    const inputForm = document.getElementById('chatInputForm');
                    const inputField = document.getElementById('chatMessageInput');

                    if (!inputForm || !inputField) return;

                    inputForm.onsubmit = (e) => {
                        e.preventDefault();
                        const message = inputField.value.trim();
                        if (message) {
                            addNewMessage(groupId, "You", message);
                            inputField.value = '';
                        }
                    };
                }

                // Fungsi untuk setup mobile input
                function setupMobileChatInput(groupId) {
                    const form = document.getElementById('mobileChatInputForm');
                    const input = document.getElementById('mobileChatInput');

                    if (!form || !input) return;

                    form.onsubmit = (e) => {
                        e.preventDefault();
                        const message = input.value.trim();
                        if (message) {
                            addNewMessage(groupId, "You", message);
                            input.value = '';
                        }
                    };
                }

                // Fungsi untuk mengedit pesan
                function editMessage(groupId, messageIndex, newContent) {
                    if (newContent.trim() === "") {
                        deleteMessage(groupId, messageIndex);
                        return;
                    }

                    chatData[groupId].messages[messageIndex].content = newContent;
                    chatData[groupId].messages[messageIndex].timestamp = new Date().toISOString();

                    // Simpan perubahan
                    localStorage.setItem('chatData', JSON.stringify(chatData));
                    loadChat(groupId);
                }

                // Fungsi untuk menghapus pesan
                function deleteMessage(groupId, messageIndex) {
                    chatData[groupId].messages.splice(messageIndex, 1);
                    localStorage.setItem('chatData', JSON.stringify(chatData));
                    loadChat(groupId);
                }

                // Fungsi utama loadChat dengan fitur edit dan hapus
                window.loadChat = function(groupId) {
                    const group = chatData[groupId];
                    if (!group) return;

                    document.querySelectorAll('#discussions-container > div').forEach(el => {
                        el.classList.remove('active-discussion');
                    });
                    const activeEl = Array.from(document.querySelectorAll('#discussions-container > div'))
                        .find(div => div.getAttribute('onclick') === `loadChat('${groupId}')`);

                    if (activeEl) {
                        activeEl.classList.add('active-discussion');
                    }
                    // Desktop updates
                    document.getElementById('chatTitle').textContent = group.title;
                    document.getElementById('chatMembers').textContent = group.members;

                    // Update tags
                    const tagsContainer = document.getElementById('chatTags');
                    tagsContainer.innerHTML = '';
                    group.tags?.forEach(tag => {
                        const tagElement = document.createElement('span');
                        tagElement.className = 'bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs';
                        tagElement.textContent = tag;
                        tagsContainer.appendChild(tagElement);
                    });

                    // Update messages dengan fitur edit dan hapus
                    const messagesContainer = document.getElementById('chatMessages');
                    messagesContainer.innerHTML = '';
                    messagesContainer.classList.remove('flex', 'flex-col', 'items-center', 'justify-center', 'text-center');
                    messagesContainer.classList.add('overflow-y-auto', 'space-y-4');

                    group.messages.forEach((msg, index) => {
                        const messageElement = document.createElement('div');
                        messageElement.className = `chat-bubble ${msg.isYou ? 'you-message' : ''} relative group`;
                        messageElement.dataset.timestamp = msg.timestamp;

                        messageElement.innerHTML = `
                <div class="flex items-start ${msg.isYou ? 'flex-row-reverse' : ''} space-x-3">
                    <div class="w-10 h-10 bg-gradient-to-r ${msg.bg} rounded-full flex items-center justify-center text-white font-bold">
                        ${msg.initial}
                    </div>
                    <div class="flex-1 ${msg.isYou ? 'text-right' : ''}">
                        <div class="${msg.bubbleColor} rounded-lg p-3 ${msg.isYou ? 'ml-auto' : ''}" style="max-width: 80%;">
                            <div class="flex items-center mb-1 ${msg.isYou ? 'justify-between' : ''}">
                                ${msg.isYou ? `
                                    <div class="flex ml-2 space-x-1">
                                        <button class="edit-btn text-secondary-1 hover:text-blue-500" data-group="${groupId}" data-index="${index}">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                            </svg>
                                        </button>
                                        <button class="delete-btn text-secondary-1 hover:text-red-500" data-group="${groupId}" data-index="${index}">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                            </svg>
                                        </button>
                                    </div>
                                    ` : ''}
                                <span class="font-semibold text-primary-2">${msg.sender}</span>
                            </div>
                            <p class="text-tertiary-1 text-sm message-content">${msg.content}</p>
                            <span class="text-xs text-secondary-1 block mt-1">${formatTime(msg.timestamp)}</span>
                        </div>
                    </div>
                </div>
            `;
                        messagesContainer.appendChild(messageElement);
                    });

                    // Auto scroll to bottom
                    messagesContainer.scrollTop = messagesContainer.scrollHeight;

                    document.getElementById('chatInput').classList.remove('hidden');

                    // Mobile updates
                    const mobileChat = document.getElementById('mobileChat');
                    if (window.innerWidth < 768) {
                        mobileChat.classList.remove('hidden');
                        mobileChat.querySelector('h3').textContent = group.title;
                        mobileChat.querySelector('p').textContent = `${group.members.split('•')[0].trim()}`;

                        // Update mobile messages
                        const mobileMessages = document.getElementById('mobileMessages');
                        if (mobileMessages) {
                            mobileMessages.innerHTML = '';
                            group.messages.forEach((msg, index) => {
                                const mobileMessageElement = document.createElement('div');
                                mobileMessageElement.className = `chat-bubble ${msg.isYou ? 'you-message' : ''} relative group`;
                                mobileMessageElement.innerHTML = `
                        <div class="flex items-start ${msg.isYou ? 'flex-row-reverse' : ''} space-x-3">
                            <div class="w-8 h-8 bg-gradient-to-r ${msg.bg} rounded-full flex items-center justify-center text-white text-sm font-bold ml-4">
                                ${msg.initial}
                            </div>
                            <div class="flex-1 ${msg.isYou ? 'text-right' : ''}">
                                <div class="${msg.bubbleColor} rounded-lg p-3 ${msg.isYou ? 'ml-auto' : ''}" style="max-width: 80%;">
                                    <div class="flex items-center mb-1 ${msg.isYou ? 'justify-end' : ''}">
                                        <span class="font-semibold text-tertiary-1 text-sm">${msg.sender}</span>
                                        ${msg.isYou ? `
                                        <div class="flex ml-2 space-x-1">
                                            <button class="edit-btn text-gray-400 hover:text-blue-500" data-group="${groupId}" data-index="${index}">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                                </svg>
                                            </button>
                                            <button class="delete-btn text-gray-400 hover:text-red-500" data-group="${groupId}" data-index="${index}">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                </svg>
                                            </button>
                                        </div>
                                        ` : ''}
                                    </div>
                                    <p class="text-gray-700 text-xs message-content">${msg.content}</p>
                                    <span class="text-xs text-gray-400 block mt-1">${formatTime(msg.timestamp)}</span>
                                </div>
                            </div>
                        </div>
                    `;
                                mobileMessages.appendChild(mobileMessageElement);
                            });
                            mobileMessages.scrollTop = mobileMessages.scrollHeight;
                        }
                    }

                    // Setup input forms
                    setupChatInput(groupId);
                    setupMobileChatInput(groupId);
                }

                // Format waktu
                function formatTime(timestamp) {
                    if (!timestamp) return '';
                    const date = new Date(timestamp);
                    return date.toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                }

                // Initialize event listeners
                document.addEventListener('DOMContentLoaded', () => {
                    // Load saved data from localStorage
                    const savedData = localStorage.getItem('chatData');
                    if (savedData) {
                        Object.assign(chatData, JSON.parse(savedData));
                    }

                    // Desktop groups
                    document.querySelectorAll('[data-group]').forEach(group => {
                        group.addEventListener('click', () => {
                            window.loadChat(group.dataset.group);
                        });
                    });

                    // Mobile back button
                    document.getElementById('mobileBackBtn')?.addEventListener('click', () => {
                        document.getElementById('mobileChat').classList.add('hidden');
                    });

                    // Handle delete and edit buttons
                    document.addEventListener('click', function(e) {
                        // Delete button
                        if (e.target.closest('.delete-btn')) {
                            const btn = e.target.closest('.delete-btn');
                            const groupId = btn.dataset.group;
                            const msgIndex = parseInt(btn.dataset.index);

                            if (confirm('Yakin ingin menghapus pesan ini?')) {
                                deleteMessage(groupId, msgIndex);
                            }
                        }

                        // Edit button
                        if (e.target.closest('.edit-btn')) {
                            const btn = e.target.closest('.edit-btn');
                            const groupId = btn.dataset.group;
                            const msgIndex = parseInt(btn.dataset.index);
                            const messageElement = btn.closest('.chat-bubble');
                            const contentElement = messageElement.querySelector('.message-content');
                            const originalContent = contentElement.textContent;

                            // Ganti dengan input field
                            const input = document.createElement('textarea');
                            input.className = 'w-full p-2 border rounded-lg text-sm';
                            input.value = originalContent;
                            input.rows = 1;

                            // Auto-resize textarea
                            input.addEventListener('input', function() {
                                this.style.height = 'auto';
                                this.style.height = (this.scrollHeight) + 'px';
                            });

                            // Ganti element
                            contentElement.replaceWith(input);
                            input.focus();
                            input.style.height = input.scrollHeight + 'px';

                            // Handle save on blur or enter
                            const saveEdit = () => {
                                editMessage(groupId, msgIndex, input.value);
                            };

                            input.addEventListener('blur', saveEdit);
                            input.addEventListener('keydown', (e) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                    e.preventDefault();
                                    saveEdit();
                                }
                            });
                        }
                    });
                });

                // Legacy support
                window.showChat = window.loadChat;
                window.hideMobileChat = () => document.getElementById('mobileChat').classList.add('hidden');
            </script>
            <script src="discussionStorage.js"></script>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const container = document.getElementById('discussions-container');

                    // Helper functions
                    function escapeHtml(unsafe) {
                        return unsafe?.toString()
                            .replace(/&/g, "&amp;")
                            .replace(/</g, "&lt;")
                            .replace(/>/g, "&gt;")
                            .replace(/"/g, "&quot;")
                            .replace(/'/g, "&#039;") || '';
                    }

                    function formatDate(isoString) {
                        if (!isoString) return '';
                        const date = new Date(isoString);
                        return date.toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                        });
                    }

                    try {
                        if (!window.discussionStorage || typeof discussionStorage.getAllDiscussions !== 'function') {
                            throw new Error('discussionStorage is not available.');
                        }

                        const discussions = discussionStorage.getAllDiscussions() || [];

                        // Clear loading state
                        container.innerHTML = '';

                        if (discussions.length === 0) {
                            container.innerHTML = `
                    <div class="col-span-full text-center py-10">
                        <svg class="w-12 h-12 mx-auto text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path>
                        </svg>
                        <h3 class="mt-4 text-lg font-medium text-gray-900">No discussions found</h3>
                        <p class="mt-1 text-sm text-gray-500">Create your first discussion to get started.</p>
                    </div>
                `;
                            return;
                        }

                        discussions.forEach(discussion => {
                            const discussionElement = document.createElement('div');
                            discussionElement.className = 'bg-primary-2 rounded-xl p-4 text-tertiary-2 shadow-md hover:shadow-lg transition-shadow cursor-pointer mb-4';
                            discussionElement.setAttribute('onclick', `loadChat('${discussion.id}')`);

                            discussionElement.innerHTML = `
                    <div class="flex justify-between items-start mb-2">
                        <h3 class="font-semibold">${escapeHtml(discussion.subject)}</h3>
                        <button class="text-primary-1/80 hover:text-primary-1">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z"></path>
                            </svg>
                        </button>
                    </div>
                    <p class="text-sm text-primary-1/80 mb-3">${escapeHtml(discussion.members)}</p>
                    <div class="flex gap-1.5 flex-wrap">
                        ${Array.isArray(discussion.tags) ? discussion.tags.map(tag => `
                            <span class="bg-secondary-1 px-1.5 py-0.5 rounded-full text-[10px] leading-tight font-medium">${escapeHtml(tag)}</span>
                        `).join('') : ''}
                    </div>
                `;

                            container.appendChild(discussionElement);
                        });

                    } catch (error) {
                        console.error('Error loading discussions:', error);
                        container.innerHTML = `
                <div class="col-span-full text-center py-10">
                    <svg class="w-12 h-12 mx-auto text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                    </svg>
                    <h3 class="mt-4 text-lg font-medium text-gray-900">Error loading discussions</h3>
                    <p class="mt-1 text-sm text-gray-500">Please try refreshing the page.</p>
                </div>
            `;
                    }
                });
            </script>

            <style>
                /* Tambahan CSS untuk pesan kanan */
                .you-message {
                    margin-left: auto;
                }

                .you-message .flex-row-reverse {
                    margin-left: auto;
                }

                /* Others’ bubbles → #CBEAFA */
                .bg-red-50 {
                    background-color: #468CC1 !important;
                    border-color: #205781 !important;
                }

                /* Your bubbles → #205781 */
                .bg-green-50 {
                    background-color: #205781 !important;
                    border-color: #205781 !important;
                }


                /* Animasi hover untuk tombol aksi */
                .chat-bubble:hover .edit-btn,
                .chat-bubble:hover .delete-btn {
                    opacity: 1 !important;
                }

                /* Style untuk textarea edit */
                textarea {
                    resize: none;
                    min-height: 40px;
                    max-height: 200px;
                }

                /* Keep the gradient container but change the colors */

                /* “You” gradient stops */
                .from-blue-500 {
                    --tw-gradient-from: #205781 !important;
                }

                .to-purple-500 {
                    --tw-gradient-to: #205781 !important;
                }

                /* Others’ gradient stops */
                .from-green-500 {
                    --tw-gradient-from: #468CC1 !important;
                }

                .to-teal-500 {
                    --tw-gradient-to: #468CC1 !important;
                }

                .chat-bubble.you-message .w-10 {
                    margin-left: 1rem;
                }
            </style>