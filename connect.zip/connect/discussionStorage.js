// discussionStorage.js

// Import data grup statis (jika menggunakan modul ES6)
// import { grupData } from './grupData.js';

// Untuk kompatibilitas tanpa modul ES6, kita akan menggunakan versi IIFE
(function() {
    // Data grup statis (salin dari grupData.js)
    const staticGroups = {
  "user-experience": {
    id: "user-experience",
    title: "User Experience",
    members: "345 Members • Public Discussion",
    privacy: "public",
    tags: ["UX", "Design"],
    description: "Discussion about user experience design principles and best practices",
    createdAt: "2023-05-15T08:30:00Z",
    colorGradient: "from-blue-500 to-blue-600"
  },
  "website-laravel-beginner": {
    id: "website-laravel-beginner",
    title: "Website Laravel Beginner",
    members: "400 Members • Public Discussion",
    privacy: "public",
    tags: ["Laravel", "PHP", "Web Dev", "Beginner", "Backend"],
    description: "Learning Laravel framework for beginners",
    createdAt: "2023-06-20T10:15:00Z",
    colorGradient: "from-cyan-500 to-blue-500"
  },
  "back-end-dev-sharing": {
    id: "back-end-dev-sharing",
    title: "Back-End Dev Sharing",
    members: "6564 Members • Public Discussion",
    privacy: "public",
    tags: ["Backend", "Sharing"],
    description: "Knowledge sharing for backend developers",
    createdAt: "2023-04-10T14:45:00Z",
    colorGradient: "from-green-500 to-teal-500"
  },
  "front-end-development": {
    id: "front-end-development",
    title: "Front-End Development",
    members: "1034 Members • Private Discussion",
    privacy: "private",
    tags: ["React", "Vue", "Angular", "CSS", "JavaScript"],
    description: "Advanced frontend development techniques",
    createdAt: "2023-07-05T09:20:00Z",
    colorGradient: "from-purple-500 to-pink-500"
  },
  "security-awareness": {
    id: "security-awareness",
    title: "Security Awareness",
    members: "575 Members • Private Discussion",
    privacy: "private",
    tags: ["Security", "Cybersecurity", "Best Practices"],
    description: "Discussion about web security and protection",
    createdAt: "2023-08-12T11:10:00Z",
    colorGradient: "from-gray-600 to-gray-700"
  },
  "user-interface-design": {
    id: "user-interface-design",
    title: "User Interface Design",
    members: "6564 Members • Public Discussion",
    privacy: "public",
    tags: ["UI/UX", "Design"],
    description: "UI design patterns and trends",
    createdAt: "2023-03-18T13:25:00Z",
    colorGradient: "from-indigo-500 to-purple-500"
  },
  "rest-api": {
    id: "rest-api",
    title: "Resti API",
    members: "3250 Members • Public Discussion",
    privacy: "public",
    tags: ["FrontEnd", "BackEnd", "WebDev"],
    description: "Understanding REST APIs in Real Projects",
    createdAt: "2023-04-18T13:25:00Z",
    colorGradient: "from-green-500 to-teal-500"
  },
  "ai": {
    id: "ai",
    title: "AI Model",
    members: "4250 Members • Public Discussion",
    privacy: "public",
    tags: ["Artificial Intelligence", "Machine Learning"],
    description: "Build Your First AI Model with Python",
    createdAt: "2023-08-18T13:25:00Z",
    colorGradient: "from-gray-600 to-gray-700"
  },
  "front-end": {
    id: "front-end",
    title: "Front End",
    members: "3300 Members • Public Discussion",
    privacy: "public",
    tags: ["FrontEnd", "BackEnd"],
    description: "Understanding State in Front-End",
    createdAt: "2023-02-18T13:25:00Z",
    colorGradient: "from-indigo-500 to-purple-500"
  }
};


    // Fungsi untuk mendapatkan semua diskusi (gabungan static + user-created)
    function getAllDiscussions() {
        // Ambil diskusi dari localStorage
        const userDiscussions = JSON.parse(localStorage.getItem('discussions')) || [];
        
        // Gabungkan dengan data statis
        const allDiscussions = [...userDiscussions];
        
        // Tambahkan data statis sebagai grup khusus
        Object.values(staticGroups).forEach(group => {
            allDiscussions.push({
                id: group.id,
                subject: group.title,
                description: group.description,
                tags: group.tags,
                privacy: group.privacy,
                createdAt: group.createdAt,
                author: "System",
                comments: [],
                likes: 0,
                isStaticGroup: true, // Flag untuk membedakan grup statis
                members: group.members,
                colorGradient: group.colorGradient
            });
        });
        
        return allDiscussions;
    }

    // Fungsi untuk mendapatkan diskusi berdasarkan ID
    function getDiscussionById(id) {
        // Cek di data statis dulu
        if (staticGroups[id]) {
            const group = staticGroups[id];
            return {
                id: group.id,
                subject: group.title,
                description: group.description,
                tags: group.tags,
                privacy: group.privacy,
                createdAt: group.createdAt,
                author: "System",
                comments: [],
                likes: 0,
                isStaticGroup: true,
                members: group.members,
                colorGradient: group.colorGradient
            };
        }
        
        // Jika tidak ditemukan di data statis, cari di localStorage
        const discussions = JSON.parse(localStorage.getItem('discussions')) || [];
        return discussions.find(d => d.id === id);
    }

    // Fungsi untuk menghapus diskusi (hanya untuk yang dibuat user)
    function deleteDiscussion(id) {
        // Jangan izinkan menghapus grup statis
        if (staticGroups[id]) {
            console.warn("Cannot delete static group:", id);
            return false;
        }
        
        let discussions = JSON.parse(localStorage.getItem('discussions')) || [];
        discussions = discussions.filter(discussion => discussion.id !== id);
        localStorage.setItem('discussions', JSON.stringify(discussions));
        return true;
    }

    // Fungsi untuk menambahkan komentar
    function addComment(discussionId, commentText) {
        // Jika grup statis, simpan komentar di localStorage terpisah
        if (staticGroups[discussionId]) {
            let staticGroupComments = JSON.parse(localStorage.getItem('staticGroupComments')) || {};
            
            if (!staticGroupComments[discussionId]) {
                staticGroupComments[discussionId] = [];
            }
            
            staticGroupComments[discussionId].push({
                id: Date.now().toString(36),
                text: commentText,
                author: "You",
                createdAt: new Date().toISOString()
            });
            
            localStorage.setItem('staticGroupComments', JSON.stringify(staticGroupComments));
            return true;
        }
        
        // Untuk diskusi biasa
        const discussions = JSON.parse(localStorage.getItem('discussions')) || [];
        const discussion = discussions.find(d => d.id === discussionId);
        
        if (discussion) {
            if (!discussion.comments) {
                discussion.comments = [];
            }
            
            discussion.comments.push({
                id: Date.now().toString(36),
                text: commentText,
                author: "You",
                createdAt: new Date().toISOString()
            });
            
            localStorage.setItem('discussions', JSON.stringify(discussions));
            return true;
        }
        
        return false;
    }

    // Fungsi untuk like diskusi
    function likeDiscussion(id) {
        // Untuk grup statis, simpan like di localStorage terpisah
        if (staticGroups[id]) {
            let staticGroupLikes = JSON.parse(localStorage.getItem('staticGroupLikes')) || {};
            
            if (!staticGroupLikes[id]) {
                staticGroupLikes[id] = 0;
            }
            
            staticGroupLikes[id] += 1;
            localStorage.setItem('staticGroupLikes', JSON.stringify(staticGroupLikes));
            return staticGroupLikes[id];
        }
        
        // Untuk diskusi biasa
        const discussions = JSON.parse(localStorage.getItem('discussions')) || [];
        const discussion = discussions.find(d => d.id === id);
        
        if (discussion) {
            discussion.likes = (discussion.likes || 0) + 1;
            localStorage.setItem('discussions', JSON.stringify(discussions));
            return discussion.likes;
        }
        
        return false;
    }

    // Fungsi untuk mendapatkan jumlah like
    function getLikeCount(id) {
        if (staticGroups[id]) {
            const staticGroupLikes = JSON.parse(localStorage.getItem('staticGroupLikes')) || {};
            return staticGroupLikes[id] || 0;
        }
        
        const discussion = getDiscussionById(id);
        return discussion ? (discussion.likes || 0) : 0;
    }

    // Fungsi untuk mendapatkan komentar
    function getComments(id) {
        if (staticGroups[id]) {
            const staticGroupComments = JSON.parse(localStorage.getItem('staticGroupComments')) || {};
            return staticGroupComments[id] || [];
        }
        
        const discussion = getDiscussionById(id);
        return discussion ? (discussion.comments || []) : [];
    }

    // Export fungsi ke global scope
    window.discussionStorage = {
        getAllDiscussions,
        getDiscussionById,
        deleteDiscussion,
        addComment,
        likeDiscussion,
        getLikeCount,
        getComments,
        staticGroups // Jika perlu mengakses data grup statis langsung
    };
})();