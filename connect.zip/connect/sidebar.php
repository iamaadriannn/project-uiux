<?php $current_page = basename($_SERVER['PHP_SELF']); ?>

<aside class="fixed top-0 left-0 w-64 bg-[#468CC1] text-white p-6 space-y-6 pt-20 h-screen z-10">
  <nav class="space-y-2 text-sm">

    <!-- Home -->
    <a href="/connect/home.php" class="block py-2 px-4 rounded transition 
      <?php echo ($current_page == 'home.php') ? 'bg-white text-[#2c4c66]' : 'hover:bg-[#1f3a50]'; ?>">
      Home
    </a>

    <!-- Threads -->
    <a href="/connect/threads.php" class="block py-2 px-4 rounded transition 
      <?php echo ($current_page == 'threads.php') ? 'bg-white text-[#2c4c66]' : 'hover:bg-[#1f3a50]'; ?>">
      Threads
    </a>

    <!-- Discussion -->
    <a href="/connect/diskusi.php" class="block py-2 px-4 rounded transition 
      <?php echo ($current_page == 'diskusi.php') ? 'bg-white text-[#2c4c66]' : 'hover:bg-[#1f3a50]'; ?>">
      Discussion
    </a>

    <!-- My Discussion -->
    <a href="/connect/MyDiscussion.php" class="block py-2 px-4 rounded transition 
      <?php echo ($current_page == 'MyDiscussion.php') ? 'bg-white text-[#2c4c66]' : 'hover:bg-[#1f3a50]'; ?>">
      My Discussion
    </a>

    <!-- Mentorship -->
    <a href="/connect/mentor.php" class="block py-2 px-4 rounded transition 
      <?php echo ($current_page == 'mentor.php') ? 'bg-white text-[#2c4c66]' : 'hover:bg-[#1f3a50]'; ?>">
      Mentorship
    </a>

  </nav>
</aside>