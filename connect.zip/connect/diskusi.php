<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>ConnecTech - Discussion</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e6f3fb] font-sans">
  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- Layout: Sidebar + Main Content -->
  <div class="flex min-h-screen">

    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content -->
    <main class="ml-64 flex-1 p-6 pt-20">
      <!-- Header with Create Button -->
      <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-semibold text-[#103b5c]">Explore Discussions</h2>
        <a href="./CreateDiscussion.php" class="bg-[#2179c4] text-white px-6 py-2 rounded-lg shadow hover:bg-[#185a94]">
          + Create Discussion
        </a>
      </div>

      <!-- Discussion List -->
      <div class="space-y-6">
        <?php
        $discussions = [
          [
            "id" => 1,
            "title" => "User Experience for Best Practices",
            "desc" => "Discussion about user experience design principles and best practices.",
            "members" => 345,
            "status" => "Public",
            "tags" => ["UX", "Design"],
            "button" => "Join"
          ],
          [
            "id" => 2,
            "title" => "Website Laravel Beginner",
            "desc" => "Sharing about web dev on framework Laravel for beginner.",
            "members" => 400,
            "status" => "Public",
            "tags" => ["Laravel", "Website", "Beginner"],
            "button" => "Join"
          ],
          [
            "id" => 3,
            "title" => "AI & Machine Learning",
            "desc" => "Discuss the latest trends, tools, and breakthroughs in Artificial Intelligence and Machine Learning.",
            "members" => 994,
            "status" => "Private",
            "tags" => ["Machine Learning", "Artificial Intelligence"],
            "button" => "Request To Join"
          ],
          [
            "id" => 4,
            "title" => "Front-End Development",
            "desc" => "Understanding REST APIs in Real Projects.",
            "members" => 10,
            "status" => "Public",
            "tags" => ["Front End", "Back End", "Web Dev"],
            "button" => "Join"
          ],
          [
            "id" => 5,
            "title" => "Artificial Intelligence",
            "desc" => "Build Your First AI Model with Python.",
            "members" => 15,
            "status" => "Public",
            "tags" => ["Artificial Intelligence", "Machine Learning"],
            "button" => "Join"
          ],
          [
            "id" => 6,
            "title" => "Front-End Development",
            "desc" => "Understanding State in Front-End.",
            "members" => 20,
            "status" => "Public",
            "tags" => ["Front End", "Back End"],
            "button" => "Join"
          ]
        ];

        foreach ($discussions as $d) {
        ?>
          <div class="bg-white p-6 rounded-xl shadow flex justify-between flex-wrap gap-4">
            <div>
              <h3 class="text-lg font-semibold text-[#103b5c]"><?= $d["title"] ?></h3>
              <p class="text-sm text-gray-700 my-1"><?= $d["desc"] ?></p>
              <p class="text-sm text-gray-500 mb-2">👥 <?= $d["members"] ?> Members • <span class="text-blue-600"><?= $d["status"] ?> Discussion</span></p>
              <div class="flex gap-2 flex-wrap">
                <?php foreach ($d["tags"] as $tag) : ?>
                  <span class="bg-blue-100 text-blue-700 text-xs px-3 py-1 rounded-full"><?= $tag ?></span>
                <?php endforeach; ?>
              </div>
            </div>
            <div class="self-center">
              <?php
              $btnClass = "join-btn px-4 py-2 rounded-full font-medium transition";
              $statusAttr = strtolower(str_replace(' ', '-', $d["button"]));
              if ($d["button"] === "Join") {
                $btnClass .= " border border-blue-800 text-blue-800 bg-white hover:bg-blue-50";
              } elseif ($d["button"] === "Request To Join") {
                $btnClass .= " bg-gray-200 hover:bg-gray-300 text-gray-800";
              } else {
                $btnClass .= " bg-blue-800 text-white cursor-not-allowed";
              }
              ?>
              <button class="<?= $btnClass ?>" data-id="<?= $d['id'] ?>" data-status="<?= $statusAttr ?>" <?= $d['button'] === "Joined" ? 'disabled' : '' ?>>
                <?= $d["button"] ?>
              </button>
            </div>
          </div>
        <?php } ?>
      </div>
    </main>
  </div>

  <!-- JavaScript: Tombol Join/Request berubah -->
  <script>
    document.querySelectorAll('.join-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const status = this.dataset.status;

        if (status === "join") {
          this.innerText = "Joined";
          this.classList.remove("border", "text-blue-800", "bg-white", "hover:bg-blue-50");
          this.classList.add("bg-blue-800", "text-white");
          this.disabled = true;
          this.classList.add("cursor-not-allowed");
        } else if (status === "request-to-join") {
          this.innerText = "Pending";
          this.classList.remove("bg-gray-200", "hover:bg-gray-300", "text-gray-800");
          this.classList.add("bg-yellow-200", "text-yellow-800");
          this.disabled = true;
          this.classList.add("cursor-not-allowed");
        }
      });
    });
  </script>
</body>

</html>