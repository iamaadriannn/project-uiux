<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contributors - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#f1f5f9] font-sans min-h-screen flex flex-col">
    <!-- Navbar -->
    <?php include 'navbar.php'; ?>

    <!-- Layout Wrapper -->
    <div class="flex flex-1 overflow-hidden">
        <!-- Sidebar -->
        <aside class="w-64 bg-white border-r shadow-md hidden md:block">
            <?php include 'sidebar.php'; ?>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-8 pt-24 max-w-7xl mx-auto overflow-y-auto">
            <h1 class="text-3xl font-bold text-gray-800 mb-8">Top Contributors</h1>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                <!-- Contributor: Maryam -->
                <div class="bg-white rounded-xl shadow p-6 flex flex-col items-center text-center">
                    <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Maryam" class="w-20 h-20 rounded-full object-cover mb-4">
                    <h2 class="text-lg font-semibold text-gray-800">Maryam Mahmud</h2>
                    <p class="text-green-500 text-sm mb-1">Expert</p>
                    <p class="text-gray-500 text-sm mb-2">10+ Posts • 1,975 Reactions</p>
                    <div class="flex flex-wrap justify-center gap-2 mb-4">
                        <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">Front-End</span>
                        <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">Web Dev</span>
                        <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">UI Design</span>
                    </div>
                    <button onclick="handleFollow(this)" class="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition w-full">Follow</button>
                </div>

                <!-- Contributor: Dennis -->
                <div class="bg-white rounded-xl shadow p-6 flex flex-col items-center text-center">
                    <img src="https://randomuser.me/api/portraits/men/45.jpg" alt="Dennis" class="w-20 h-20 rounded-full object-cover mb-4">
                    <h2 class="text-lg font-semibold text-gray-800">Dennis Aditi</h2>
                    <p class="text-blue-600 text-sm mb-1">Skilled</p>
                    <p class="text-gray-500 text-sm mb-2">20+ Posts • 995 Reactions</p>
                    <div class="flex flex-wrap justify-center gap-2 mb-4">
                        <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">Back-End</span>
                        <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">Web Dev</span>
                        <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">Cyber Security</span>
                        <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">Database</span>
                    </div>
                    <button onclick="handleFollow(this)" class="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition w-full">Follow</button>
                </div>

                <!-- Contributor: Aisha -->
                <div class="bg-white rounded-xl shadow p-6 flex flex-col items-center text-center">
                    <img src="https://randomuser.me/api/portraits/women/21.jpg" alt="Aisha" class="w-20 h-20 rounded-full object-cover mb-4">
                    <h2 class="text-lg font-semibold text-gray-800">Aisha Rahman</h2>
                    <p class="text-purple-500 text-sm mb-1">Rising Star</p>
                    <p class="text-gray-500 text-sm mb-2">5 Posts • 540 Reactions</p>
                    <div class="flex flex-wrap justify-center gap-2 mb-4">
                        <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">AI</span>
                        <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">Data Science</span>
                        <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">Python</span>
                    </div>
                    <button onclick="handleFollow(this)" class="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition w-full">Follow</button>
                </div>
            </div>
        </main>
    </div>

    <script>
        function handleFollow(button) {
            button.disabled = true;
            button.innerText = 'Following...';
            setTimeout(() => {
                button.innerText = 'Following';
                button.classList.remove('bg-blue-600', 'text-white', 'hover:bg-blue-700');
                button.classList.add('bg-gray-200', 'text-gray-600');
            }, 1000);
        }
    </script>
</body>

</html>