<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>My Bookings</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#f3f7fb] font-sans">
    <?php include 'navbar.php'; ?>
    <div class="flex min-h-screen">
        <?php include 'sidebar.php'; ?>

        <main class="ml-64 p-6 pt-20 w-full max-w-5xl">
            <h1 class="text-2xl font-bold mb-6">My Bookings</h1>

            <div id="bookingList" class="space-y-4">
                <!-- bookings will be inserted here -->
            </div>
        </main>
    </div>

    <script>
        const bookingList = document.getElementById("bookingList");
        const bookings = JSON.parse(localStorage.getItem("bookings") || "[]");

        if (bookings.length === 0) {
            bookingList.innerHTML = "<p class='text-gray-600'>You have no bookings yet.</p>";
        } else {
            bookings.forEach((booking, index) => {
                const item = document.createElement("div");
                item.className = "bg-white shadow p-4 rounded";
                item.innerHTML = `
          <h2 class="font-semibold text-lg text-blue-800">${booking.mentor}</h2>
          <p><strong>Name:</strong> ${booking.name}</p>
          <p><strong>Date:</strong> ${booking.date}</p>
          <p><strong>Payment:</strong> ${booking.payment}</p>
          <p><strong>Total:</strong> ${booking.price}</p>
          <p><strong>Notes:</strong> ${booking.notes || '-'}</p>
          <p class="text-sm text-gray-500 mt-1">Booked at ${booking.time}</p>
        `;
                bookingList.appendChild(item);
            });
        }
    </script>
</body>

</html>