<!-- footer.html -->
<footer class="w-full bg-[#1e3a5f] text-white py-4 px-6 mt-auto">
  <div class="max-w-7xl mx-auto text-center text-sm">
    <p>&copy; 2025 ConnecTech. All rights reserved.</p>
  </div>
</footer>
