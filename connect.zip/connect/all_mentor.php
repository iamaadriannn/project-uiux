<?php
$mentors = [
    1 => ['name' => 'Ica Marica H', 'photo' => 'assets/images/ica.png', 'exp' => '10 Years', 'skills' => ['Front-End', 'Back-End', 'Web Dev'], 'rating' => 4.9, 'reviews' => 76],
    2 => ['name' => 'Alif Batasa', 'photo' => 'assets/images/alif.png', 'exp' => '11 Years', 'skills' => ['Back-End', 'Cybersecurity'], 'rating' => 4.9, 'reviews' => 71],
    3 => ['name' => 'Zalzil Zulzel', 'photo' => 'assets/images/zalzil.png', 'exp' => '8 Years', 'skills' => ['Machine Learning'], 'rating' => 4.9, 'reviews' => 68],
    4 => ['name' => 'Erna Ananda', 'photo' => 'assets/images/erna.png', 'exp' => '8 Years', 'skills' => ['Front-End', 'Back-End', 'Web Dev'], 'rating' => 4.9, 'reviews' => 76],
    5 => ['name' => 'Gavin Yoo', 'photo' => 'assets/images/gavin.png', 'exp' => '15 Years', 'skills' => ['AI', 'Back-End', 'Cybersecurity'], 'rating' => 4.8, 'reviews' => 66],
    6 => ['name' => 'Hans Burga', 'photo' => 'assets/images/hans.png', 'exp' => '10 Years', 'skills' => ['Front-End', 'User-Interface'], 'rating' => 4.9, 'reviews' => 86],
    7 => ['name' => 'Laurenz De', 'photo' => 'assets/images/laurenz.png', 'exp' => '6 Years', 'skills' => ['Front-End', 'Back-End', 'Web Dev'], 'rating' => 4.2, 'reviews' => 76],
    8 => ['name' => 'Marianne', 'photo' => 'assets/images/marianne.png', 'exp' => '5 Years', 'skills' => ['Cybersecurity', 'Back-End', 'Web Dev'], 'rating' => 4.1, 'reviews' => 75],
    9 => ['name' => 'Noah Anderson', 'photo' => 'assets/images/noah.png', 'exp' => '7 Years', 'skills' => ['Game', 'AR', 'VR'], 'rating' => 4.2, 'reviews' => 70],
    10 => ['name' => 'Maemunah', 'photo' => 'assets/images/maemunah.png', 'exp' => '13 Years', 'skills' => ['Front-End', 'Back-End', 'Web Dev'], 'rating' => 4.9, 'reviews' => 80],
    11 => ['name' => 'Muhaimin', 'photo' => 'assets/images/muhaimin.png', 'exp' => '6 Years', 'skills' => ['Artificial Intelligence ', 'Machine Learning'], 'rating' => 4.9, 'reviews' => 73],
    12 => ['name' => 'Mama Nara', 'photo' => 'assets/images/mama.png', 'exp' => '10 Years', 'skills' => ['Front-End', 'Back-End'], 'rating' => 4.9, 'reviews' => 66],
];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>All Mentors - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#f3f7fb] font-sans">
    <?php include 'navbar.php'; ?>

    <div class="flex min-h-screen">
        <?php include 'sidebar.php'; ?>

        <main class="ml-64 p-6 pt-20 max-w-6xl w-full">
            <h1 class="text-2xl font-bold mb-6">All Mentors</h1>

            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($mentors as $id => $m): ?>
                    <div class="bg-white p-4 rounded-lg shadow">
                        <div class="flex items-center gap-3 mb-2">
                            <img src="<?= $m['photo'] ?>" alt="<?= $m['name'] ?>" class="w-12 h-12 rounded-full object-cover">
                            <div>
                                <p class="font-semibold text-base"><?= $m['name'] ?> <span class="text-blue-600 font-normal text-sm">• Mentor</span></p>
                                <p class="text-sm text-gray-600"><?= $m['exp'] ?> Experience</p>
                                <p class="text-sm text-blue-600">Skills • <?= implode(' • ', $m['skills']) ?></p>
                            </div>
                        </div>

                        <div class="text-sm text-gray-600 mt-1">
                            ★★★★★ <span class="text-blue-700">(<?= number_format($m['rating'], 1) ?>)</span> • <?= $m['reviews'] ?> Reviews
                        </div>

                        <div class="mt-4 flex gap-2">
                            <a href="mentor_profile.php?id=<?= $id ?>" class="w-1/2 bg-gray-200 py-1 rounded font-semibold text-sm text-center hover:bg-gray-300">View Profile</a>
                            <a href="book_session.php?mentor_id=<?= $id ?>" class="w-1/2 bg-[#2f5c88] hover:bg-[#1d3c5a] text-white py-1 rounded font-semibold text-sm text-center">Book Now</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </main>
    </div>
</body>

</html>