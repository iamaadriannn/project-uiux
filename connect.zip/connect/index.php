<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ConnecTech - Tech Discussion Platform</title>
  <script src="https://cdn.tailwindcss.com"></script>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Afacad&display=swap"
    rel="stylesheet">

  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            primary: {
              1: '#205781',
              2: '#FFFFFF'
            },
            secondary: {
              1: '#CBEAFA',
              2: '#468CC1'
            },
            tertiary: {
              1: '#FEFCF4',
              2: '#112C41'
            }
          }
        }
      }
    }
  </script>
  <style>
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .animate-fade-in-up {
      animation: fadeInUp 0.6s ease-out;
    }

    .animate-delay-100 {
      animation-delay: 0.1s;
    }

    .animate-delay-200 {
      animation-delay: 0.2s;
    }

    .animate-delay-300 {
      animation-delay: 0.3s;
    }

    /* Custom scrollbar */
    .custom-scrollbar::-webkit-scrollbar {
      height: 8px;
    }

    .custom-scrollbar::-webkit-scrollbar-track {
      background: #f1f5f9;
      border-radius: 10px;
    }

    .custom-scrollbar::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 10px;
    }

    .custom-scrollbar::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }
  </style>
</head>

<body class="flex flex-col h-screen bg-[#CBEAFA]">
  <?php include 'navbar.php'; ?>

  <div class=" flex flex-1 overflow-hidden">
    <?php include 'sidebar.php'; ?>

    <main class="ml-64 p-6 pt-20 space-y-10 overflow-x-auto font-[Afacad] ">
      <!-- Hero Section -->
      <section class="bg-white rounded-xl shadow p-6 flex flex-col md:flex-row justify-between items-center relative bg-[url('assets/hero.png')] bg-cover bg-center text-black">
        <div class="relative z-10">
          <h1 class="text-4xl mb-8 text-tertiary-600 font-bold">Today's Discussion,</h1>
          <h2 class="text-4xl mb-8 text-tertiary-600 font-bold">Tomorrow's Innovation.</h2>
        </div>

        <a href="diskusi.php"
          class="absolute bottom-6 right-6 bg-[#CBEAFA] text-[#112C41] border-none py-4 px-8 rounded-lg text-base font-semibold cursor-pointer hover:-translate-y-1 hover:shadow-xl transition-all duration-300 shadow-lg">
          Start Discussion
        </a>

      </section>


      <!-- Trending Tags -->
      <section class="mb-12">
        <div class="flex justify-between items-center mb-6">
          <h2 class="text-2xl font-semibold text-gray-700">Trending Tags</h2>
        </div>
        <div class="flex gap-4 flex-wrap">
          <a href="threads/webdev.php" class="bg-white border-2 border-gray-200 py-3 px-6 rounded-full text-gray-600 no-underline font-medium hover:border-blue-600 hover:text-blue-600 hover:-translate-y-1 hover:shadow-lg transition-all duration-300 shadow-sm">Web Dev</a>
          <a href="threads/mobiledev.php" class="bg-white border-2 border-gray-200 py-3 px-6 rounded-full text-gray-600 no-underline font-medium hover:border-blue-600 hover:text-blue-600 hover:-translate-y-1 hover:shadow-lg transition-all duration-300 shadow-sm">Mobile Dev</a>
          <a href="threads/gamedev.php" class="bg-white border-2 border-gray-200 py-3 px-6 rounded-full text-gray-600 no-underline font-medium hover:border-blue-600 hover:text-blue-600 hover:-translate-y-1 hover:shadow-lg transition-all duration-300 shadow-sm">Game Dev</a>
          <a href="threads/cybersecurity.php" class="bg-white border-2 border-gray-200 py-3 px-6 rounded-full text-gray-600 no-underline font-medium hover:border-blue-600 hover:text-blue-600 hover:-translate-y-1 hover:shadow-lg transition-all duration-300 shadow-sm">Cybersecurity</a>
          <a href="threads/machinelearning.php" class="bg-white border-2 border-gray-200 py-3 px-6 rounded-full text-gray-600 no-underline font-medium hover:border-blue-600 hover:text-blue-600 hover:-translate-y-1 hover:shadow-lg transition-all duration-300 shadow-sm">Machine Learning</a>
          <a href="threads/database.php" class="bg-white border-2 border-gray-200 py-3 px-6 rounded-full text-gray-600 no-underline font-medium hover:border-blue-600 hover:text-blue-600 hover:-translate-y-1 hover:shadow-lg transition-all duration-300 shadow-sm">Database</a>
          <a href="threads/ai.php" class="bg-white border-2 border-gray-200 py-3 px-6 rounded-full text-gray-600 no-underline font-medium hover:border-blue-600 hover:text-blue-600 hover:-translate-y-1 hover:shadow-lg transition-all duration-300 shadow-sm">Artificial Intelligence</a>
        </div>
      </section>

      <!-- Trending Topics -->
      <section class="mb-12">
        <div class="flex justify-between items-center mb-6">
          <h2 class="text-2xl font-semibold text-gray-700">Trending Topics</h2>
          <a href="contributors.php" class="text-blue-600 no-underline font-medium hover:text-blue-800 transition-colors duration-300">See All Topics →</a>
        </div>
        <div class="flex gap-6 overflow-x-auto pb-4 custom-scrollbar">

          <!-- Card 1 -->
          <div class="bg-white rounded-2xl p-6 shadow-lg border border-gray-200 hover:-translate-y-2 hover:shadow-xl transition-all duration-300 min-w-80 max-w-96 h-48 flex-shrink-0 flex flex-col animate-fade-in-up">
            <h3 class="text-xl font-semibold mb-4 text-gray-700">
              Agentic AI
            </h3>

            <div class="flex gap-2 mb-5 flex-wrap">
              <span class="bg-[#468CC1] text-gray-50 py-1 px-3 rounded-2xl text-xs">
                Artificial Intelligence
              </span>
              <span class="bg-[#468CC1] text-gray-50 py-1 px-3 rounded-2xl text-xs">
                Machine Learning
              </span>
              <span class="bg-[#468CC1] text-gray-50 py-1 px-3 rounded-2xl text-xs">
                Development
              </span>
            </div>


            <div class="flex gap-4">
              <button
                class="py-2.5 px-5 border-none rounded-lg cursor-pointer font-semibold text-sm hover:-translate-y-1 hover:opacity-90 transition-all duration-300 flex-1 bg-[#164E81] text-white">
                Discussion
              </button>
              <button
                class="py-2.5 px-5 border-none rounded-lg cursor-pointer font-semibold text-sm hover:-translate-y-1 hover:opacity-90 transition-all duration-300 flex-1 bg-[#164E81] text-white">
                Thread
              </button>
            </div>
          </div>

          <!-- Card 2 -->
          <div class="bg-white rounded-2xl p-6 shadow-lg border border-gray-200 hover:-translate-y-2 hover:shadow-xl transition-all duration-300 min-w-80 max-w-96 h-44 flex-shrink-0 flex flex-col animate-fade-in-up animate-delay-100">
            <h3 class="text-xl font-semibold mb-4 text-gray-700">
              Post-Quantum Cryptography
            </h3>

            <div class="flex gap-2 mb-5 flex-wrap">
              <span class="bg-[#468CC1] text-gray-50 py-1 px-3 rounded-2xl text-xs">
                Cybersecurity
              </span>
              <span class="bg-[#468CC1] text-gray-50 py-1 px-3 rounded-2xl text-xs">
                Cryptography
              </span>
            </div>

            <div class="flex gap-4">
              <button
                class="py-2.5 px-5 border-none rounded-lg cursor-pointer font-semibold text-sm hover:-translate-y-1 hover:opacity-90 transition-all duration-300 flex-1 bg-[#164E81] text-white">
                Discussion
              </button>
              <button
                class="py-2.5 px-5 border-none rounded-lg cursor-pointer font-semibold text-sm hover:-translate-y-1 hover:opacity-90 transition-all duration-300 flex-1 bg-[#164E81] text-white">
                Thread
              </button>
            </div>
          </div>

          <!-- Card 3 -->
          <div class="bg-white rounded-2xl p-6 shadow-lg border border-gray-200 hover:-translate-y-2 hover:shadow-xl transition-all duration-300 min-w-80 max-w-96 h-44 flex-shrink-0 flex flex-col animate-fade-in-up animate-delay-200">
            <h3 class="text-xl font-semibold mb-4 text-gray-700">
              Spatial Computing
            </h3>

            <div class="flex gap-2 mb-5 flex-wrap">
              <span class="bg-[#468CC1] text-gray-50 py-1 px-3 rounded-2xl text-xs">
                Virtual Reality
              </span>
              <span class="bg-[#468CC1] text-gray-50 py-1 px-3 rounded-2xl text-xs">
                AR/VR
              </span>
              <span class="bg-[#468CC1] text-gray-50 py-1 px-3 rounded-2xl text-xs">
                AI Dev
              </span>
            </div>

            <div class="flex gap-4">
              <button
                class="py-2.5 px-5 border-none rounded-lg cursor-pointer font-semibold text-sm hover:-translate-y-1 hover:opacity-90 transition-all duration-300 flex-1 bg-[#164E81] text-white">
                Discussion
              </button>
              <button
                class="py-2.5 px-5 border-none rounded-lg cursor-pointer font-semibold text-sm hover:-translate-y-1 hover:opacity-90 transition-all duration-300 flex-1 bg-[#164E81] text-white">
                Thread
              </button>
            </div>
          </div>

          <!-- Card 4 -->
          <div class="bg-white rounded-2xl p-6 shadow-lg border border-gray-200 hover:-translate-y-2 hover:shadow-xl transition-all duration-300 min-w-80 max-w-96 h-44 flex-shrink-0 flex flex-col animate-fade-in-up animate-delay-300">
            <h3 class="text-xl font-semibold mb-4 text-gray-700">
              Disinformation Security
            </h3>

            <div class="flex gap-2 mb-5 flex-wrap">
              <span class="bg-[#468CC1] text-gray-50 py-1 px-3 rounded-2xl text-xs">
                Artificial Intelligence
              </span>
              <span class="bg-[#468CC1] text-gray-50 py-1 px-3 rounded-2xl text-xs">
                Security
              </span>
            </div>

            <div class="flex gap-4">
              <button
                class="py-2.5 px-5 border-none rounded-lg cursor-pointer font-semibold text-sm hover:-translate-y-1 hover:opacity-90 transition-all duration-300 flex-1 bg-[#164E81] text-white">
                Discussion
              </button>
              <button
                class="py-2.5 px-5 border-none rounded-lg cursor-pointer font-semibold text-sm hover:-translate-y-1 hover:opacity-90 transition-all duration-300 flex-1 bg-[#164E81] text-white">
                Thread
              </button>
            </div>
          </div>

        </div>

      </section>

      <section class="mb-12">
        <div class="flex justify-between items-center mb-6">
          <h2 class="text-2xl font-semibold text-gray-700">Trending Threads</h2>
          <a href="thread.php" class="text-blue-600 no-underline font-semibold hover:text-blue-800 transition-colors duration-300">
            See All Thread →
          </a>
        </div>
        <div class="flex gap-6 overflow-x-auto pb-4 custom-scrollbar">
          <!-- Thread Card -->
          <div class="bg-white rounded-2xl p-6 shadow-lg border border-gray-200 hover:-translate-y-1 hover:shadow-xl transition-all duration-300 min-w-96 flex-shrink-0">
            <div class="flex items-center mb-4">
              <img src="assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-4 rounded-full object-cover">

              <div class="flex-1">
                <h4 class="text-gray-700 mb-1">
                  Paul Jackson <span class="text-green-500">Expert</span>
                </h4>
                <div class="text-gray-500 text-sm">22 days ago</div>
              </div>

              <a
                href="threads/webdev1.php"
                class="border border-blue-600 text-blue-600 py-2 px-6 rounded-full ml-auto hover:bg-blue-50 transition-all duration-300">
                Open Thread
              </a>
            </div>
            <div class="mb-4 text-gray-600 leading-relaxed">
              Is it worth learning Rust in 2025 for system-level development?
            </div>
            <div class="flex gap-4 text-gray-500 text-sm">
              <span>👁 50,060 Views</span>
              <span>👍 997 Likes</span>
              <span>💬 74 Comments</span>
            </div>
          </div>

          <!-- Thread Card -->
          <div class="bg-white rounded-2xl p-6 shadow-lg border border-gray-200 hover:-translate-y-1 hover:shadow-xl transition-all duration-300 min-w-96 flex-shrink-0">
            <div class="flex items-center mb-4">
              <img src="assets/images/aisha.png" alt="Aisha Farouq" class="w-10 h-10 mr-4 rounded-full object-cover">

              <div class="flex-1">
                <h4 class="text-gray-700 mb-1">
                  Aisha Farouq <span class="text-green-500">Expert</span>
                </h4>
                <div class="text-gray-500 text-sm">8 hours ago</div>
              </div>

              <a
                href="threads/database6.php"
                class="border border-blue-600 text-blue-600 py-2 px-6 rounded-full ml-auto hover:bg-blue-50 transition-all duration-300">
                Open Thread
              </a>
            </div>
            <div class="mb-4 text-gray-600 leading-relaxed">
              I've built a small API but need tips on securing it before going live.
            </div>
            <div class="flex gap-4 text-gray-500 text-sm">
              <span>👁 48,456 Views</span>
              <span>👍 987 Likes</span>
              <span>💬 68 Comments</span>
            </div>
          </div>
        </div>
      </section>


      <!-- Top Discussions -->
      <section class="mb-12">
        <h2 class="text-2xl font-semibold text-gray-700 mb-4">Top Discussions</h2>
        <div class="flex gap-6 overflow-x-auto pb-4">
          <!-- Public Join -->
          <div class="bg-white rounded-2xl p-6 shadow border min-w-80 flex-shrink-0">
            <h3 class="text-lg font-semibold mb-2 text-gray-700">How to transition from Web Dev to AI?</h3>
            <p class="text-gray-500 mb-4">Tips for web devs on switching to AI—where to start and what to learn.</p>
            <div class="text-gray-500 text-sm mb-4">👥 273k Members • Public Discussion</div>
            <button onclick="handleJoin(this)" class="bg-green-500 text-white py-2 px-6 rounded-full hover:bg-green-600 transition-all duration-300">
              Join
            </button>
          </div>

          <!-- Private Join -->
          <div class="bg-white rounded-2xl p-6 shadow border min-w-80 flex-shrink-0">
            <h3 class="text-lg font-semibold mb-2 text-gray-700">Best Free Resources to Learn Go in 2025</h3>
            <p class="text-gray-500 mb-4">Sharing top free websites, videos, and tools to master Go in 2025.</p>
            <div class="text-gray-500 text-sm mb-4">👥 232k Members • Private Discussion</div>
            <button onclick="handleJoin(this)" class="bg-transparent text-blue-600 border-2 border-blue-600 py-2 px-6 rounded-full hover:bg-blue-600 hover:text-white transition-all duration-300">
              Request To Join
            </button>
          </div>
        </div>
      </section>

      <!-- Top Contributors -->
      <section class="mb-12">
        <div class="flex justify-between items-center mb-6">
          <h2 class="text-2xl font-semibold text-gray-700">Top Contributors</h2>
          <a href="contributors.php" class="text-blue-600 font-medium hover:text-blue-800 transition">See All Contributors →</a>
        </div>

        <div class="flex gap-6 overflow-x-auto pb-4">
          <!-- Maryam -->
          <div class="bg-white rounded-2xl p-6 shadow border min-w-96 h-56 flex-shrink-0 flex flex-col">
            <div class="flex items-center mb-4">
              <img src="assets/images/maryam.png" alt="Maryam" class="w-12 h-12 rounded-full object-cover mr-4">
              <div class="flex-1">
                <h4 class="text-gray-700 mb-1">Maryam Mahmud • <span class="text-green-500">Expert</span></h4>
                <div class="text-green-500 text-sm">10+ Posts • 1,975 Reactions</div>
              </div>
            </div>
            <div class="text-gray-500 mb-2">Skills</div>
            <div class="flex gap-2 flex-wrap mb-4">
              <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-xl text-xs">Front-End</span>
              <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-xl text-xs">Web Dev</span>
              <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-xl text-xs">UI Design</span>
            </div>
            <button onclick="handleFollow(this)" class="bg-transparent text-blue-600 border-2 border-blue-600 py-2 px-6 rounded-full hover:bg-blue-600 hover:text-white transition w-full">Follow</button>
          </div>

          <!-- Dennis -->
          <div class="bg-white rounded-2xl p-6 shadow border min-w-96 h-56 flex-shrink-0 flex flex-col">
            <div class="flex items-center mb-4">
              <img src="assets/images/dennis.png" alt="Dennis" class="w-12 h-12 rounded-full object-cover mr-4">
              <div class="flex-1">
                <h4 class="text-gray-700 mb-1">Dennis Aditi • <span class="text-blue-600">Skilled</span></h4>
                <div class="text-blue-600 text-sm">20+ Posts • 995 Reactions</div>
              </div>
            </div>
            <div class="text-gray-500 mb-2">Skills</div>
            <div class="flex gap-2 flex-wrap mb-4">
              <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-xl text-xs">Back-End</span>
              <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-xl text-xs">Web Dev</span>
              <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-xl text-xs">Cyber Security</span>
              <span class="bg-gray-200 text-gray-600 px-3 py-1 rounded-xl text-xs">Database</span>
            </div>
            <button onclick="handleFollow(this)" class="bg-blue-600 text-white border-2 border-blue-600 py-2 px-6 rounded-full hover:bg-blue-700 transition w-full">Follow</button>
          </div>
        </div>
      </section>


      <!-- Script -->
      <script>
        function handleJoin(button) {
          const originalText = button.innerText;
          button.disabled = true;
          button.innerHTML = `
        <svg class="animate-spin h-5 w-5 mr-2 inline-block text-white align-middle" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.4 0 0 5.4 0 12h4z"></path>
        </svg> Joining...`;

          setTimeout(() => {
            button.innerHTML = 'Joined';
            button.classList.remove('bg-green-500', 'text-white', 'border-blue-600', 'text-blue-600');
            button.classList.add('bg-gray-200', 'text-gray-600');
            button.disabled = true;
          }, 1000);
        }

        function handleFollow(button) {
          button.disabled = true;
          button.innerHTML = 'Following...';

          setTimeout(() => {
            button.innerHTML = 'Following';
            button.classList.remove('text-blue-600', 'border-blue-600', 'hover:bg-blue-600', 'hover:text-white');
            button.classList.add('bg-gray-200', 'text-gray-600', 'border-gray-300');
          }, 1000);
        }
      </script>