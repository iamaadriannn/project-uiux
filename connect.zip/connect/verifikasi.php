<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>OTP Verification - ConnecTech</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', sans-serif;
    }

    html, body {
      height: 100%;
    }

    .bg-image {
      position: relative;
      height: 100vh;
      background-image: url('login.jpg');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      background-color: #888;
    }

    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      background-color: rgba(0, 0, 0, 0.4);
    }

    .branding {
      position: absolute;
      top: 50%;
      left: 10%;
      transform: translateY(-50%);
      color: #fff;
    }

    .branding h1 {
      font-size: 44px;
      font-weight: bold;
    }

    .branding p {
      font-size: 16px;
      margin-top: 8px;
    }

    .form-box {
      position: absolute;
      top: 50%;
      right: 10%;
      transform: translateY(-50%);
      background-color: rgba(255, 255, 255, 0.6);
      padding: 28px;
      border-radius: 28px;
      width: 300px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      color: #fff;
    }

    .otp-display {
      font-size: 14px;
      text-align: center;
      margin-bottom: 10px;
      color: #fff;
      font-weight: bold;
    }

    .form-box .info-text {
      font-size: 12px;
      color: #f0f0f0;
      margin-bottom: 12px;
      margin-top: -6px;
      text-align: left;
    }

    .form-box label {
      display: block;
      font-size: 13px;
      margin-bottom: 4px;
    }

    .form-box input {
      width: 100%;
      padding: 10px;
      margin-bottom: 12px;
      border-radius: 6px;
      border: 1px solid #ccc;
      font-size: 13px;
    }

    .form-box button {
      width: 100%;
      padding: 10px;
      background-color: #2a4e7d;
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      font-size: 14px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .form-box button:hover {
      background-color: #1f3c61;
    }

    .message {
      margin-top: 10px;
      font-size: 13px;
      text-align: center;
    }

    @media (max-width: 768px) {
      .branding, .form-box {
        left: 5%;
        right: 5%;
        width: 90%;
        transform: translateY(-50%);
      }

      .branding h1 {
        font-size: 32px;
      }

      .form-box {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
  <div class="bg-image">
    <div class="overlay"></div>

    <div class="branding">
      <h1>ConnecTech</h1>
      <p>Powering Connection Without Limits</p>
    </div>

    <div class="form-box">
      <div class="otp-display" id="otpDisplay"></div>
      <form onsubmit="verifyOTP(event)">
        <label for="otpInput">OTP</label>
        <input type="text" id="otpInput" placeholder="Enter your OTP" required />
        <p class="info-text">Enter OTP from your email</p>
        <button type="submit">VERIFY</button>
        <div class="message" id="message"></div>
      </form>
    </div>
  </div>

  <script>
    const otp = localStorage.getItem("otpCode");
    const otpDisplay = document.getElementById("otpDisplay");

    if (otp) {
      otpDisplay.textContent = "Your OTP: " + otp; // Hanya untuk demo
    } else {
      otpDisplay.textContent = "⚠️ No OTP generated.";
      otpDisplay.style.color = "red";
    }

    function verifyOTP(event) {
      event.preventDefault();
      const enteredOTP = document.getElementById("otpInput").value.trim();
      const message = document.getElementById("message");

      if (!otp) {
        message.textContent = "⚠️ OTP not available. Please restart forgot password process.";
        message.style.color = "red";
        return;
      }

      if (enteredOTP === otp) {
        message.textContent = "✅ OTP verified! Redirecting to reset page...";
        message.style.color = "limegreen";
        setTimeout(() => {
          window.location.href = "reset.php";
        }, 1500);
      } else {
        message.textContent = "❌ Invalid OTP. Please try again.";
        message.style.color = "red";
      }
    }
  </script>
</body>
</html>
