<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link
  href="https://fonts.googleapis.com/css2?family=Share+Tech&display=swap"
  rel="stylesheet">

<nav class="w-full h-16 bg-[#1e3a5f] flex items-center justify-between px-6 shadow text-white fixed top-0 left-0 z-50">
  <!-- Logo -->
  <div class="text-3xl tracking-wide" style="font-family:'Share Tech', sans-serif">
    ConnecTech
  </div>


  <!-- Search + Icons -->
  <div class="flex items-center space-x-4 relative">
    <!-- Search Bar -->
    <div class="relative w-64 hidden md:block">
      <input type="text" placeholder="Search..." class="w-full pl-4 pr-10 py-2 rounded-full bg-white text-gray-800 placeholder-gray-500 shadow focus:outline-none text-sm" />
      <div class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      </div>
    </div>

    <!-- Icons -->
    <div class="flex items-center space-x-4 text-xl relative">
      <!-- Notification Icon -->
      <div class="relative">
        <button id="notifBtn" class="hover:text-gray-300" aria-label="Notifications">
          <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
              d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C8.67 6.165 8 7.388 8 8.75v5.408c0 .538-.214 1.055-.595 1.437L6 17h5m4 0v1a3 3 0 11-6 0v-1m6 0H9" />
          </svg>
        </button>
        <!-- Dummy Notification Dropdown -->
        <div id="notifDropdown" class="hidden absolute right-0 mt-2 w-64 bg-white text-gray-800 rounded-md shadow-lg z-50 text-sm">
          <div class="px-4 py-2 border-b font-semibold">Notifikasi</div>
          <div class="px-4 py-2 hover:bg-gray-100">✅ Diskusi kamu sudah direspon</div>
          <div class="px-4 py-2 hover:bg-gray-100">📢 Mentor baru tersedia</div>
          <div class="px-4 py-2 hover:bg-gray-100">📅 Jadwal diskusi kamu besok jam 14:00</div>
        </div>
      </div>

      <!-- User Dropdown -->
      <div class="relative">
        <button id="userMenuBtn" class="hover:text-gray-300 focus:outline-none" aria-label="User Profile">
          <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
              d="M5.121 17.804A4 4 0 016 16h12a4 4 0 01.879 1.804M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
        </button>

        <!-- User Dropdown Menu -->
        <div id="userDropdown" class="hidden absolute right-0 mt-2 w-40 bg-white text-gray-800 rounded-md shadow-lg z-50">
          <!-- Diisi oleh JS -->
        </div>
      </div>
    </div>
  </div>
</nav>

<script>
  const userBtn = document.getElementById("userMenuBtn");
  const userDropdown = document.getElementById("userDropdown");
  const notifBtn = document.getElementById("notifBtn");
  const notifDropdown = document.getElementById("notifDropdown");

  const userData = JSON.parse(localStorage.getItem("dummyUser"));
  const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";

  // Render isi dropdown user berdasarkan status login
  if (isLoggedIn && userData) {
    userDropdown.innerHTML = `
      <a href="account.php" class="block px-4 py-2 hover:bg-gray-100 text-sm">Hello, ${userData.name}</a>
      <button onclick="handleLogout()" class="w-full text-left px-4 py-2 hover:bg-gray-100 text-sm">Logout</button>
    `;
  } else {
    userDropdown.innerHTML = `
      <a href="login.php" class="block px-4 py-2 hover:bg-gray-100 text-sm">Login</a>
      <a href="register.php" class="block px-4 py-2 hover:bg-gray-100 text-sm">Register</a>
    `;
    // Sembunyikan notifikasi jika belum login
    notifBtn.style.display = "none";
  }

  // Toggle dropdown user
  userBtn.addEventListener("click", () => {
    userDropdown.classList.toggle("hidden");
    notifDropdown.classList.add("hidden");
  });

  // Toggle dropdown notifikasi
  notifBtn.addEventListener("click", () => {
    notifDropdown.classList.toggle("hidden");
    userDropdown.classList.add("hidden");
  });

  // Tutup dropdown jika klik di luar
  window.addEventListener("click", (e) => {
    if (!userBtn.contains(e.target) && !userDropdown.contains(e.target)) {
      userDropdown.classList.add("hidden");
    }
    if (!notifBtn.contains(e.target) && !notifDropdown.contains(e.target)) {
      notifDropdown.classList.add("hidden");
    }
  });

  // Logout handler
  function handleLogout() {
    localStorage.setItem("isLoggedIn", "false"); // ✅ Tidak hapus dummyUser
    alert("Berhasil logout");
    window.location.href = "index.php";
  }
</script>