<?php
$mentorId = $_GET['mentor_id'] ?? null;
$dateFromUrl = $_GET['date'] ?? '';
$timeFromUrl = $_GET['time'] ?? '';

$mentors = [
    1 => ['name' => 'Ica Marica H', 'photo' => 'assets/images/ica.png', 'exp' => '10 Years', 'skills' => ['Front-End', 'Back-End', 'Web Dev'], 'rating' => 4.9, 'reviews' => 76],
    2 => ['name' => 'Alif Batasa', 'photo' => 'assets/images/alif.png', 'exp' => '11 Years', 'skills' => ['Back-End', 'Cybersecurity'], 'rating' => 4.9, 'reviews' => 71],
    3 => ['name' => 'Zalzil Zulzel', 'photo' => 'assets/images/zalzil.png', 'exp' => '8 Years', 'skills' => ['Machine Learning'], 'rating' => 4.9, 'reviews' => 68],
    4 => ['name' => 'Erna Ananda', 'photo' => 'assets/images/erna.png', 'exp' => '8 Years', 'skills' => ['Front-End', 'Back-End', 'Web Dev'], 'rating' => 4.9, 'reviews' => 76],
    5 => ['name' => 'Gavin Yoo', 'photo' => 'assets/images/gavin.png', 'exp' => '15 Years', 'skills' => ['AI', 'Back-End', 'Cybersecurity'], 'rating' => 4.8, 'reviews' => 66],
    6 => ['name' => 'Hans Burga', 'photo' => 'assets/images/hans.png', 'exp' => '10 Years', 'skills' => ['Front-End', 'User-Interface'], 'rating' => 4.9, 'reviews' => 86],
    7 => ['name' => 'Laurenz De', 'photo' => 'assets/images/laurenz.png', 'exp' => '6 Years', 'skills' => ['Front-End', 'Back-End', 'Web Dev'], 'rating' => 4.2, 'reviews' => 76],
    8 => ['name' => 'Marianne', 'photo' => 'assets/images/marianne.png', 'exp' => '5 Years', 'skills' => ['Cybersecurity', 'Back-End', 'Web Dev'], 'rating' => 4.1, 'reviews' => 75],
    9 => ['name' => 'Noah Anderson', 'photo' => 'assets/images/noah.png', 'exp' => '7 Years', 'skills' => ['Game', 'AR', 'VR'], 'rating' => 4.2, 'reviews' => 70],
];

$mentor = $mentors[$mentorId] ?? null;
if (!$mentor) {
    echo "Mentor not found.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Mentor Booking</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#f3f7fb] font-sans">

    <?php include 'navbar.php'; ?>
    <div class="flex min-h-screen">
        <?php include 'sidebar.php'; ?>

        <main class="ml-64 p-6 pt-20 w-full max-w-3xl">
            <a href="javascript:history.back()" class="text-blue-700 text-xl font-bold mb-4 inline-block">←</a>

            <h1 class="text-2xl font-bold mb-6">Mentor Booking</h1>

            <div class="bg-white p-6 rounded-lg shadow space-y-6">
                <div class="flex items-center gap-4">
                    <img src="<?= $mentor['photo'] ?>" class="w-20 h-20 rounded-full object-cover" />
                    <div>
                        <h2 class="text-lg font-semibold text-gray-900"><?= $mentor['name'] ?> <span class="text-blue-600 font-normal">• Mentor</span></h2>
                        <p class="text-sm text-gray-700"><?= $mentor['exp'] ?> Experience</p>
                    </div>
                </div>

                <form id="bookingForm" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Name</label>
                        <input type="text" id="name" required class="w-full mt-1 px-4 py-2 border border-gray-300 rounded-md" placeholder="Your name">
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Date</label>
                            <input type="date" id="date" value="<?= htmlspecialchars($dateFromUrl) ?>" required class="w-full mt-1 px-4 py-2 border border-gray-300 rounded-md">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Time</label>
                            <input type="time" id="time" value="<?= htmlspecialchars($timeFromUrl) ?>" required class="w-full mt-1 px-4 py-2 border border-gray-300 rounded-md">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Notes (Optional)</label>
                        <textarea id="notes" rows="3" class="w-full mt-1 px-4 py-2 border border-gray-300 rounded-md" placeholder="Your message..."></textarea>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Payment</label>
                        <input type="text" id="payment" required class="w-full mt-1 px-4 py-2 border border-gray-300 rounded-md" placeholder="Account number / phone">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Total Price</label>
                        <input type="text" id="price" value="Rp. 200.000" readonly class="w-full mt-1 px-4 py-2 border border-gray-300 rounded-md bg-gray-100">
                    </div>

                    <div>
                        <button type="submit" class="bg-[#2f5c88] hover:bg-[#1d3c5a] text-white font-semibold px-6 py-2 rounded">
                            Make Order
                        </button>
                    </div>
                </form>
            </div>

            <!-- Message -->
            <div id="message" class="mt-6 hidden bg-green-100 text-green-800 p-4 rounded"></div>
        </main>
    </div>

    <script>
        const form = document.getElementById("bookingForm");
        const messageBox = document.getElementById("message");

        form.addEventListener("submit", function(e) {
            e.preventDefault();
            const order = {
                mentor: "<?= $mentor['name'] ?>",
                name: document.getElementById("name").value,
                date: document.getElementById("date").value,
                time: document.getElementById("time").value,
                notes: document.getElementById("notes").value,
                payment: document.getElementById("payment").value,
                price: document.getElementById("price").value,
                submittedAt: new Date().toLocaleString()
            };

            const existing = JSON.parse(localStorage.getItem("bookings") || "[]");
            existing.push(order);
            localStorage.setItem("bookings", JSON.stringify(existing));

            form.reset();
            messageBox.innerText = "✅ Your booking with " + order.mentor + " has been saved!";
            messageBox.classList.remove("hidden");

            // Redirect ke halaman history
            setTimeout(() => {
                window.location.href = "booking_history.php";
            }, 1500);
        });
    </script>

</body>

</html>