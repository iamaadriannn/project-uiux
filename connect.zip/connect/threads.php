<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>ConnecTech - Thread</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Afacad&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Afacad', sans-serif;
    }
  </style>
</head>

<body class="bg-[#CBEAFA] font-sans">

  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <div class="flex flex-1 overflow-hidden">
    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content -->
    <main class="flex-1 ml-64 p-6 pt-20 space-y-10">

      <!-- Create Thread Input -->
      <div class="bg-white p-4 rounded-lg shadow mb-6">
        <div class="flex items-start space-x-4">
          <div class="w-10 h-10 rounded-full bg-gray-300"></div>
          <div class="flex-1">
            <input id="threadInput" type="text" placeholder="Let's share what’s going on your mind..." class="w-full border-none outline-none" />
            <div class="flex items-center justify-between mt-4">
              <div class="flex items-center space-x-4 text-sm text-gray-500">
                <!-- File Icon -->
                <label for="fileInput" class="cursor-pointer">
                  <span class="inline-flex items-center space-x-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5s8.268 2.943 9.542 7c-1.274 4.057-5.065 7-9.542 7s-8.268-2.943-9.542-7z" />
                    </svg>
                    <span>50,060</span>
                  </span>


                </label>
                <input type="file" id="fileInput" class="hidden" />
                <span id="fileName" class="text-xs text-gray-600"></span>

                <!-- Image Icon -->
                <label for="imageInput" class="cursor-pointer">
                  <span class="inline-flex items-center space-x-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M3 8a5 5 0 015-5h4a5 5 0 015 5v1a5 5 0 01-5 5h-1.586l-2.707 2.707a1 1 0 01-1.414 0L7.586 14H8a5 5 0 01-5-5V8z" />
                    </svg>
                    <span>997</span>
                  </span>

                </label>
                <input type="file" id="imageInput" accept="image/*" class="hidden" />
                <span id="imageName" class="text-xs text-gray-600"></span>

                <!-- Category Text Input -->
                <label for="categoryInput" class="cursor-pointer">
                  <span class="inline-flex items-center space-x-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8h2a2 2 0 012 2v10l-4-4H7a2 2 0 01-2-2V8a2 2 0 012-2h2" />
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 3h6m0 0v6m0-6L10 14" />
                    </svg>
                    <span>74</span>
                  </span>

                </label>
                <input id="categoryInput" type="text" placeholder="e.g. Front-end" class="text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded outline-none w-24" />
              </div>
              <button id="createBtn" class="bg-[#2c4c66] text-white px-4 py-1 rounded hover:bg-[#1f3a50]">Create</button>
            </div>
          </div>
        </div>
      </div>


      <div id="threadContainer" class="space-y-4">
        <!-- Thread Default -->
        <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
          <div class="flex items-center mb-2">
            <img src="./assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />
            <div>
              <span class="font-semibold">Ali Ahmad</span> · <span class="text-sm text-gray-500">19 hours ago</span>
            </div>
          </div>
          <p class="mb-4">Why do I get undefined is not a function when calling my function?</p>


          <div class="mb-4">
            <img src="assets/images/threadsali.png" alt="img" class="rounded-lg border border-gray-300 w-full object-contain">
          </div>

          <div class="flex items-center justify-between text-sm text-gray-500">
            <div class="space-x-2">
              <span>👁 50.060</span>
              <span>👍 997</span>
              <span>💬 74</span>
            </div>
            <button class="text-blue-600 hover:underline">
              <a href="threads/webdev7.php">Open Thread</a>
            </button>
          </div>
        </div>
      </div>

      <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
        <div class="flex items-center mb-2">
          <!-- Avatar -->
          <img src="./assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />

          <!-- Nama dan tanggal -->
          <div>
            <span class="font-semibold">Paul Jackson</span>
            <span class="text-sm text-gray-500 ml-1">· 22 days ago</span>
          </div>
        </div>

        <p class="mb-4">Is it worth learning Rust in 2025 for system-level development?</p>
        <div class="flex items-center justify-between text-sm text-gray-500">
          <div class="space-x-2">
            <span>👁 50.060</span>
            <span>👍 997</span>
            <span>💬 74</span>
          </div>
          <button class="text-blue-600 hover:underline">
            <a href="./webdev1.php">Open Thread</a>
          </button>
        </div>
      </div>

      <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
        <div class="flex items-center mb-2">
          <!-- Avatar -->
          <img src="./assets/images/aisha.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />

          <!-- Nama dan tanggal -->
          <div>
            <span class="font-semibold">Gabriela Suárez</span>
            <span class="text-sm text-gray-500 ml-1">· 3 weeks ago</span>
          </div>
        </div>

        <p class="mb-4">How do you optimize a React app for performance when rendering large lists?</p>
        <div class="flex items-center justify-between text-sm text-gray-500">
          <div class="space-x-2">
            <span>👁 50.060</span>
            <span>👍 997</span>
            <span>💬 74</span>
          </div>
          <button class="text-blue-600 hover:underline">
            <a href="threads/webdev8.php">Open Thread</a>
          </button>
        </div>
      </div>

  </div>

  </main>
  </div>

  <!-- JavaScript -->
  <!-- Script -->
  <script>
    const createBtn = document.getElementById("createBtn");
    const threadInput = document.getElementById("threadInput");
    const threadContainer = document.getElementById("threadContainer");

    const fileInput = document.getElementById("fileInput");
    const imageInput = document.getElementById("imageInput");
    const categoryInput = document.getElementById("categoryInput");

    const fileName = document.getElementById("fileName");
    const imageName = document.getElementById("imageName");

    let uploadedImageURL = null;
    let uploadedFileName = null;

    fileInput.addEventListener("change", () => {
      if (fileInput.files.length > 0) {
        uploadedFileName = fileInput.files[0].name;
        fileName.textContent = uploadedFileName;
      } else {
        uploadedFileName = null;
        fileName.textContent = "";
      }
    });

    imageInput.addEventListener("change", () => {
      if (imageInput.files.length > 0) {
        const reader = new FileReader();
        reader.onload = (e) => {
          uploadedImageURL = e.target.result;
          imageName.textContent = imageInput.files[0].name;
        };
        reader.readAsDataURL(imageInput.files[0]);
      } else {
        uploadedImageURL = null;
        imageName.textContent = "";
      }
    });

    createBtn.addEventListener("click", () => {
      const content = threadInput.value.trim();
      const category = categoryInput.value.trim();

      if (content === "") {
        alert("Please enter a thread message.");
        return;
      }

      let imageHTML = uploadedImageURL ? `<img src="${uploadedImageURL}" class="mt-2 rounded border border-gray-300 w-full max-h-64 object-cover">` : "";
      let fileHTML = uploadedFileName && !uploadedImageURL ?
        `<p class="mt-2 text-sm text-blue-600 underline">📄 ${uploadedFileName}</p>` :
        "";

      let categoryTag = category ?
        `<span class="inline-block bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full mb-2">${category}</span>` :
        "";

      const newThread = document.createElement("div");
      newThread.className = "bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg";

      newThread.innerHTML = `
        <div class="flex justify-between items-center mb-2">
          <div><span class="font-semibold">You</span> · <span class="text-sm text-gray-500">Just now</span></div>
        </div>
        <p class="mb-2">${content}</p>
        ${categoryTag}
        ${imageHTML}
        ${fileHTML}
        <div class="flex items-center justify-between text-sm text-gray-500 mt-3">
          <div class="space-x-2">
            <span>👁️ 0</span>
            <span>👍 0</span>
            <span>💬 0</span>
          </div>
          <button class="text-blue-600 hover:underline open-thread" data-id="new">Open Thread</button>
        </div>
      `;

      threadContainer.prepend(newThread);

      // Reset
      threadInput.value = "";
      fileInput.value = "";
      imageInput.value = "";
      categorySelect.value = "";
      uploadedImageURL = null;
      uploadedFileName = null;
      fileName.textContent = "";
      imageName.textContent = "";
    });

    // Open thread dummy
    document.addEventListener("click", function(e) {
      if (e.target.classList.contains("open-thread")) {
        const id = e.target.getAttribute("data-id");
        window.location.href = `thread-detail.php?id=${id}`;
      }
    });
  </script>



</body>

</html>