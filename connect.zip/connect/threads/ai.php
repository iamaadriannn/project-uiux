<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>ConnecTech - Artificial Intelligence</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">

    <?php include '../navbar.php' ?>

    <div class="flex">
        <?php include '../sidebar.php' ?>
        <main class="flex-1 ml-64 p-6 pt-20 space-y-10">
            <!-- Title Section -->
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-semibold text-gray-700">Threads about Artificial Intelligence</h2>
                <a href="#" class="text-blue-600 no-underline font-semibold hover:text-blue-800 transition">
                    See All Thread →
                </a>
            </div>

            <!-- Thread List -->
            <div id="threadContainer" class="space-y-4">

                <!-- Example Thread -->
                <div class="bg-white p-6 rounded-xl shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <!-- Header -->
                    <div class="flex items-center justify-between mb-2">
                        <div class="flex items-center space-x-3">
                            <img src="../assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />
                            <div>
                                <p class="text-sm font-semibold">Alex Bijer <span class="text-blue-500 font-normal">• Machine Learning Engineer</span></p>
                                <p class="text-xs text-gray-500">2 days ago</p>
                            </div>
                        </div>
                        <button class="text-gray-400 text-xl">⋯</button>
                    </div>

                    <!-- Content -->
                    <p class="text-sm font-medium text-gray-800 mb-4">
                        What’s a good way to implement a chatbot with large context and memory?
                    </p>

                    <!-- Tags -->
                    <div class="flex flex-wrap gap-2 text-xs mb-4">
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Chatbot</span>
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">AI</span>
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">NLP</span>
                    </div>

                    <!-- Stats -->
                    <div class="flex items-center justify-between text-xs text-gray-600">
                        <div class="flex gap-4 items-center">
                            <span>👁 9,500 Views</span>
                            <span>🤍 220 Likes</span>
                            <span>💬 40 Comments</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./ai1.php">Open Thread</a>
                        </button>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-xl shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex items-center justify-between mb-2">
                        <div class="flex items-center space-x-3">
                            <img src="../assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />
                            <div>
                                <p class="text-sm font-semibold">James Peterson <span class="text-blue-500 font-normal">• XR Developer</span></p>
                                <p class="text-xs text-gray-500">2 hours ago</p>
                            </div>
                        </div>
                        <button class="text-gray-400 text-xl">⋯</button>
                    </div>

                    <p class="text-sm font-medium text-gray-800 mb-4">
                        How is <span class="font-semibold">Spatial Computing</span> shaping the future of human-computer interaction?
                    </p>

                    <div class="flex flex-wrap gap-2 text-xs mb-4">
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Spatial</span>
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">XR</span>
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">HCI</span>
                    </div>

                    <div class="flex items-center justify-between text-xs text-gray-600">
                        <div class="flex gap-4 items-center">
                            <span>👁 2,800 Views</span>
                            <span>🤍 40 Likes</span>
                            <span>💬 10 Comments</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./ai2.php">Open Thread</a>
                        </button>

                    </div>
                </div>
                <!-- Thread 8 -->
                <div class="bg-white p-6 rounded-xl shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex items-center justify-between mb-2">
                        <div class="flex items-center space-x-3">
                            <img src="../assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />
                            <div>
                                <p class="text-sm font-semibold">Nina Patel <span class="text-blue-500 font-normal">• Machine Learning Engineer</span></p>
                                <p class="text-xs text-gray-500">1 hour ago</p>
                            </div>
                        </div>
                        <button class="text-gray-400 text-xl">⋯</button>
                    </div>

                    <p class="text-sm font-medium text-gray-800 mb-4">
                        What is Agentic AI, and how can we implement it in enterprise applications?
                    </p>

                    <div class="flex flex-wrap gap-2 text-xs mb-4">
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Agentic</span>
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">AI</span>
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Enterprise</span>
                    </div>

                    <div class="flex items-center justify-between text-xs text-gray-600">
                        <div class="flex gap-4 items-center">
                            <span>👁 3,500 Views</span>
                            <span>🤍 60 Likes</span>
                            <span>💬 15 Comments</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./ai3.php">Open Thread</a>
                        </button>
                    </div>
                </div>
        </main>
    </div>

</body>

</html>