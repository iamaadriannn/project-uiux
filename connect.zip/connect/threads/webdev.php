<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>ConnecTech - Web Development</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <!-- Navbar -->
    <?php include '../navbar.php'; ?>

    <div class="flex">
        <!-- Sidebar -->
        <?php include '../sidebar.php'; ?>

        <!-- Main Content -->
        <main class="flex-1 ml-64 p-6 pt-20 space-y-10">
            <h1 class="text-2xl font-semibold mb-6">Web Development</h1>

            <!-- Create Thread Input -->
            <div class="bg-white p-4 rounded-lg shadow mb-6">
                <div class="flex items-start space-x-4">
                    <div class="w-10 h-10 rounded-full bg-gray-300"></div>
                    <div class="flex-1">
                        <input id="threadInput" type="text" placeholder="Let's share what’s going on in Web Development…" class="w-full border-none outline-none" />
                        <div class="flex items-center justify-between mt-2">
                            <div class="space-x-3 text-sm text-gray-500">
                                <button>📁 Files</button>
                                <button>🖼️ Images</button>
                                <button>🏷️ Category</button>
                            </div>
                            <button id="createBtn" class="bg-[#2c4c66] text-white px-4 py-1 rounded hover:bg-[#1f3a50]">Create</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Threads -->
            <div id="threadContainer" class="space-y-4">
                <!-- Thread 1 -->
                <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex items-center mb-2">
                        <!-- Avatar -->
                        <img src="../assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />

                        <!-- Nama dan tanggal -->
                        <div>
                            <span class="font-semibold">Paul Jackson</span>
                            <span class="text-sm text-gray-500 ml-1">· 22 days ago</span>
                        </div>
                    </div>

                    <p class="mb-4">Is it worth learning Rust in 2025 for system-level development?</p>
                    <div class="flex items-center justify-between text-sm text-gray-500">
                        <div class="space-x-2">
                            <span>👁 50.060</span>
                            <span>👍 997</span>
                            <span>💬 74</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./webdev1.php">Open Thread</a>
                        </button>
                    </div>
                </div>

                <!-- Thread 2 -->
                <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex items-center mb-2">
                        <img src="../assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />
                        <div>
                            <span class="font-semibold">Mike</span> · <span class="text-sm text-gray-500">1 day ago</span>
                        </div>
                    </div>
                    <p class="mb-4">Best practices for designing a scalable API?</p>
                    <div class="flex items-center justify-between text-sm text-gray-500">

                        <div class="space-x-2">
                            <span>👁 250</span>
                            <span>👍 10</span>
                            <span>💬 5</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./webdev2.php">Open Thread</a>
                        </button>

                    </div>
                </div>

                <!-- Thread 3 -->
                <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex items-center mb-2">
                        <img src="../assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />
                        <div>
                            <span class="font-semibold">Charlie</span> · <span class="text-sm text-gray-500">3 hours ago</span>
                        </div>
                    </div>
                    <p class="mb-4">How to implement dark and light mode efficiently?</p>
                    <div class="flex items-center justify-between text-sm text-gray-500">
                        <div class="space-x-2">
                            <span>👁 100</span>
                            <span>👍 5</span>
                            <span>💬 2</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./webdev3.php">Open Thread</a>
                        </button>

                    </div>
                </div>

                <!-- Thread 4 -->
                <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex items-center mb-2">
                        <img src="../assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />
                        <div>
                            <span class="font-semibold">Daniel</span> · <span class="text-sm text-gray-500">5 hours ago</span>
                        </div>
                    </div>
                    <p class="mb-4">Tips for securing a single page application (SPA)?</p>
                    <div class="flex items-center justify-between text-sm text-gray-500">
                        <div class="space-x-2">
                            <span>👁 80</span>
                            <span>👍 4</span>
                            <span>💬 1</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./webdev4.php">Open Thread</a>
                        </button>

                    </div>
                </div>

                <!-- Thread 5 -->
                <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex items-center mb-2">
                        <img src="../assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />
                        <div>
                            <span class="font-semibold">Sophie</span> · <span class="text-sm text-gray-500">just now</span>
                        </div>
                    </div>
                    <p class="mb-4">Framework vs vanilla JavaScript — when to use which?</p>
                    <div class="flex items-center justify-between text-sm text-gray-500">
                        <div class="space-x-2">
                            <span>👁 20</span>
                            <span>👍 1</span>
                            <span>💬 0</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./webdev5.php">Open Thread</a>
                        </button>

                    </div>
                </div>
            </div>

            <!-- Thread 8 -->
            <div class="bg-white p-6 rounded-xl shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="../assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />
                        <div>
                            <p class="text-sm font-semibold">James Peterson <span class="text-blue-500 font-normal">• XR Developer</span></p>
                            <p class="text-xs text-gray-500">2 hours ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-medium text-gray-800 mb-4">
                    How is <span class="font-semibold">Spatial Computing</span> shaping the future of human-computer interaction?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Spatial</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">XR</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">HCI</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-600">
                    <div class="flex gap-4 items-center">
                        <span>👁 2,800 Views</span>
                        <span>🤍 40 Likes</span>
                        <span>💬 10 Comments</span>
                    </div>
                    <button class="text-blue-600 hover:underline">
                        <a href="./webdev6.php">Open Thread</a>
                    </button>

                </div>


            </div>

            <!-- Threads gabungan -->
            <div id="threadContainer" class="space-y-4">
                <!-- Thread Umum 1 -->
                <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex items-center mb-2">
                        <img src="../assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />
                        <div>
                            <span class="font-semibold">Ali Ahmad</span> · <span class="text-sm text-gray-500">Beginner · 19 hours ago</span>
                        </div>
                    </div>
                    <p class="mb-4">Why do I get undefined is not a function when calling my function?</p>
                    <div class="mb-4">
                        <img src="../assets/images/threadsali.png" alt="img" class="rounded-lg border border-gray-300 w-full object-contain">
                    </div>
                    <div class="flex items-center justify-between text-sm text-gray-500">
                        <div class="space-x-2">
                            <span>👁️ 30,250</span>
                            <span>👍 798</span>
                            <span>💬 55</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./webdev7.php">Open Thread</a>
                        </button>
                    </div>
                </div>

                <!-- Thread Umum 2 -->
                <div class="bg-white rounded-xl shadow p-6 space-y-4 transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-3">
                            <img src="../assets/images/paul.png" alt="Paul Jackson" class="w-10 h-10 mr-3 rounded-full object-cover" />
                            <div>
                                <p class="text-sm font-semibold">Gabriela Suárez <span class="text-blue-500 font-normal">• Skilled</span></p>
                                <p class="text-xs text-gray-500">3 weeks ago</p>
                            </div>
                        </div>
                        <button class="text-gray-400 text-xl">⋯</button>
                    </div>
                    <p class="text-sm font-medium text-gray-800">
                        How do you optimize a React app for performance when rendering large lists?
                    </p>
                    <div class="flex flex-wrap gap-2 text-xs">
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Website</span>
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Front-end</span>
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Web Dev</span>
                    </div>
                    <div class="flex items-center justify-between text-xs text-gray-600">
                        <div class="flex gap-4 items-center">
                            <span>👁️ 39,965 Views</span>
                            <span>🤍 873 Likes</span>
                            <span>💬 38 Comments</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./webdev8.php">Open Thread</a>
                        </button>
                    </div>
                </div>



        </main>
    </div>

    <!-- JS -->
    <script>
        const createBtn = document.getElementById("createBtn");
        const threadInput = document.getElementById("threadInput");
        const threadContainer = document.getElementById("threadContainer");

        createBtn.addEventListener("click", () => {
            const content = threadInput.value.trim();
            if (content === "") {
                alert("Please enter a thread message.");
                return;
            }
            const newThread = document.createElement("div");
            newThread.className = "bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg";
            newThread.innerHTML = `
        <div class="flex items-center mb-2">
          <div>
            <span class="font-semibold">You</span> · <span class="text-sm text-gray-500">Just now</span>
          </div>
        </div>
        <p class="mb-4">${content}</p>
        <div class="flex items-center justify-between text-sm text-gray-500">
          <div class="space-x-2">
            <span>👁 0</span>
            <span>👍 0</span>
            <span>💬 0</span>
          </div>
          <button class="text-blue-600 hover:underline">Open Thread</button>
        </div>`;
            threadContainer.prepend(newThread);
            threadInput.value = "";
        });
    </script>

</body>

</html>