<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Ali's Thread</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include('../navbar.php'); ?>
    <?php include('../sidebar.php'); ?>

    <div class="flex ml-64 p-6 pt-20">
        <div class="flex-1">
            <div class="bg-white p-6 rounded-lg shadow mb-6">
                <div class="flex justify-between items-center mb-2">
                    <div>
                        <span class="font-semibold">Ali Ahmad</span>
                        <span class="text-sm text-gray-500">Beginner · 19 hours ago</span>
                    </div>
                </div>

                <p class="mb-4">
                    Why do I get <code>undefined is not a function</code> when calling my function?
                </p>

                <div class="mb-4">
                    <img src="../assets/images/threadsali.png" alt="Thread Image" class="rounded-lg border border-gray-300 w-full object-contain">
                </div>

                <div class="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div class="space-x-2">
                        <span>👁️ 30,250</span>
                        <span>👍 798</span>
                        <span>💬 55</span>
                    </div>
                </div>

                <a href="../threads.php" class="text-blue-600 hover:underline">&larr; Back to threads</a>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Dee</span> <span class="text-gray-500 ml-2 text-sm">5 hours ago</span>
                        <p>Check if the function is properly declared before calling.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Andra</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Maybe you're calling it before it's defined or imported correctly.</p>
                    </li>
                </ul>

                <input id="commentInput" type="text" placeholder="Add a comment…" class="w-full p-2 mb-2 border rounded outline-none">
                <button id="addCommentBtn" class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">Comment</button>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();
            if (comment !== '') {
                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;
                document.getElementById('commentList').prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>