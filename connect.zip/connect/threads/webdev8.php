<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Gabriela's Thread</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include('../navbar.php'); ?>
    <?php include('../sidebar.php'); ?>

    <div class="flex ml-64 p-6 pt-20">
        <div class="flex-1">
            <div class="bg-white p-6 rounded-lg shadow mb-6">
                <div class="flex justify-between items-center mb-2">
                    <div>
                        <span class="font-semibold">Gabriela Suárez</span>
                        <span class="text-sm text-blue-500">• Skilled</span>
                        <span class="text-sm text-gray-500 ml-2">3 weeks ago</span>
                    </div>
                </div>

                <p class="mb-4">
                    How do you optimize a React app for performance when rendering large lists?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Website</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Front-end</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Web Dev</span>
                </div>

                <div class="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div class="space-x-2">
                        <span>👁️ 39,965</span>
                        <span>👍 873</span>
                        <span>💬 38</span>
                    </div>
                </div>

                <a href="../threads.php" class="text-blue-600 hover:underline">&larr; Back to threads</a>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Noah</span> <span class="text-gray-500 ml-2 text-sm">1 week ago</span>
                        <p>Use virtualization libraries like react-window or react-virtualized.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Lina</span> <span class="text-gray-500 ml-2 text-sm">3 days ago</span>
                        <p>Memoization and avoiding unnecessary re-renders is key!</p>
                    </li>
                </ul>

                <input id="commentInput" type="text" placeholder="Add a comment…" class="w-full p-2 mb-2 border rounded outline-none">
                <button id="addCommentBtn" class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">Comment</button>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();
            if (comment !== '') {
                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;
                document.getElementById('commentList').prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>