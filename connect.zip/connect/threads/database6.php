<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Aisha's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="aisha.jpg" alt="Aisha Farouq" class="w-10 h-10 rounded-full object-cover">
                        <div>
                            <p class="font-semibold">
                                Aisha Farouq <span class="text-green-500 font-normal">• Expert</span>
                            </p>
                            <p class="text-xs text-gray-500">8 hours ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    I've built a small API but need tips on securing it before going live.
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">API</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Security</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Best Practices</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 48,456 Views</span>
                        <span>🤍 987 Likes</span>
                        <span>💬 68 Comments</span>
                    </div>
                    <a href="./database.php" class="text-blue-500 hover:underline">
                        &larr; Back to Database
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Brian</span> <span class="text-gray-500 ml-2 text-sm">5 hours ago</span>
                        <p>Start with HTTPS everywhere — never allow plain HTTP access to your API endpoints.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Celine</span> <span class="text-gray-500 ml-2 text-sm">5 hours ago</span>
                        <p>Use strong authentication like OAuth 2.0 or API keys stored securely. Rotate keys regularly.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Daniel</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Don't expose internal errors in your API responses — use generic error messages for clients.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Emily</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Limit request rates with rate limiting and throttling to prevent abuse and DDoS.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Farhan</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Validate all inputs to prevent SQL Injection, XSS, and other common attacks.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Grace</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Enable logging and monitoring to detect unusual behavior or breach attempts.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Henry</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Keep your dependencies up to date to patch known vulnerabilities in your stack.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ivy</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Use JSON Web Tokens (JWT) for stateless auth, but always validate expiration and signature.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Jorge</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Set proper CORS headers if your API is meant to be consumed across domains.</p>
                    </li>
                </ul>

                <input id="commentInput" type="text" placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn" class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>