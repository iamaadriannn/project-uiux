<?php
$mentors = [
  1 => ['name' => 'Ica Marica H', 'photo' => 'assets/images/ica.png', 'exp' => '10 Years', 'skills' => ['Front-End', 'Back-End', 'Web Dev'], 'rating' => 4.9, 'reviews' => 76],
  2 => ['name' => 'Alif Batasa', 'photo' => 'assets/images/alif.png', 'exp' => '11 Years', 'skills' => ['Back-End', 'Cybersecurity'], 'rating' => 4.9, 'reviews' => 71],
  3 => ['name' => 'Zalzil Zulzel', 'photo' => 'assets/images/zalzil.png', 'exp' => '8 Years', 'skills' => ['Machine Learning'], 'rating' => 4.9, 'reviews' => 68],
];

$public = [
  10 => ['name' => 'Maemunah', 'photo' => 'assets/images/maemunah.png', 'exp' => '13 Years', 'skills' => ['Front-End', 'Back-End', 'Web Dev'], 'rating' => 4.9, 'reviews' => 80],
  11 => ['name' => 'Muhaimin', 'photo' => 'assets/images/muhaimin.png', 'exp' => '6 Years', 'skills' => ['Artificial Intelligence', 'Machine Learning'], 'rating' => 4.9, 'reviews' => 73],
  12 => ['name' => 'Mama Nara', 'photo' => 'assets/images/mama.png', 'exp' => '10 Years', 'skills' => ['Front-End', 'Back-End'], 'rating' => 4.9, 'reviews' => 66],
];
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Mentorship - ConnecTech</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e6f3fb] font-sans">
  <?php include 'navbar.php'; ?>
  <div class="flex min-h-screen">
    <?php include 'sidebar.php'; ?>

    <main class="ml-64 p-6 pt-20 w-full max-w-7xl">
      <h2 class="text-2xl font-bold mb-4">Level Up Your Tech Journey With a Mentor</h2>

      <div class="flex gap-4 mb-8">
        <a href="all_mentor.php" class="bg-blue-600 text-white font-semibold py-2 px-6 rounded shadow hover:bg-blue-700">Book a Private Session</a>
        <a href="diskusi.php" class="bg-blue-600 text-white font-semibold py-2 px-6 rounded shadow hover:bg-blue-700">Join a Public Session</a>
      </div>

      <!-- PRIVATE MENTORS -->
      <div class="flex justify-between items-center mb-4">
        <h3 class="text-xl font-semibold">Find Your Tech Mentor</h3>
        <a href="all_mentor.php" class="text-blue-700 font-medium">See All Mentors →</a>
      </div>

      <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
        <?php foreach ($mentors as $id => $m): ?>
          <div class="bg-white rounded-lg p-4 shadow">
            <div class="flex items-center gap-3">
              <img src="<?= $m['photo'] ?>" alt="<?= $m['name'] ?>" class="w-14 h-14 rounded-full object-cover">
              <div>
                <p class="text-base font-semibold"><?= $m['name'] ?> <span class="text-blue-600 font-normal">• Mentor</span></p>
                <p class="text-sm text-gray-700"><?= $m['exp'] ?> Experience</p>
                <p class="text-sm text-blue-600">Skills • <?= implode(' • ', $m['skills']) ?></p>
              </div>
            </div>

            <div class="text-sm mt-2 text-gray-600">
              ★★★★★ <span class="text-blue-700">(<?= number_format($m['rating'], 1) ?>)</span> • <?= $m['reviews'] ?> Reviews
            </div>

            <div class="mt-3 flex gap-2">
              <a href="mentor_profile.php?id=<?= $id ?>" class="w-1/2 bg-gray-200 text-center py-1 rounded font-semibold text-sm">View Profile</a>
              <a href="book_session.php?mentor_id=<?= $id ?>" class="w-1/2 bg-[#2f5c88] hover:bg-[#1d3c5a] text-white text-center py-1 rounded font-semibold text-sm">Book Now</a>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <!-- PUBLIC SESSIONS -->
      <div class="mt-12">
        <div class="flex justify-between items-center mb-4">
          <h3 class="text-xl font-semibold">Join a Public Session</h3>
          <a href="diskusi.php" class="text-blue-700 font-medium">See All Public Sessions →</a>
        </div>

        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
          <?php foreach ($public as $id => $p): ?>
            <div class="bg-white rounded-lg p-4 shadow">
              <p class="font-semibold">Join Session with <?= $p['name'] ?></p>
              <div class="flex items-center gap-3 mt-2">
                <img src="<?= $p['photo'] ?>" alt="<?= $p['name'] ?>" class="w-10 h-10 rounded-full object-cover">
                <div>
                  <p class="text-sm">With <?= $p['name'] ?> <span class="text-blue-600">• Mentor</span></p>
                  <p class="text-xs text-gray-700"><?= $p['exp'] ?> Experience</p>
                  <p class="text-xs text-blue-600">Skills • <?= implode(' • ', $p['skills']) ?></p>
                </div>
              </div>
              <div class="text-sm mt-2 text-gray-600">
                ★★★★★ <span class="text-blue-700">(<?= number_format($p['rating'], 1) ?>)</span> • <?= $p['reviews'] ?> Reviews
              </div>
              <div class="mt-3 flex gap-2">
                <a href="diskusi.php?id=<?= $id ?>" class="w-1/2 bg-gray-200 text-center py-1 rounded font-semibold text-sm">Detail Session</a>
                <a href="diskusi.php?id=<?= $id ?>" class="w-1/2 bg-[#2f5c88] hover:bg-[#1d3c5a] text-white text-center py-1 rounded font-semibold text-sm">Join Now</a>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </main>
  </div>
</body>

</html>