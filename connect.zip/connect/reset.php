<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Reset Password - ConnecTech</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', sans-serif;
    }

    html, body {
      height: 100%;
    }

    .bg-image {
      position: relative;
      height: 100vh;
      background-image: url('login.jpg');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      background-color: #888;
    }

    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      background-color: rgba(0, 0, 0, 0.4);
    }

    .branding {
      position: absolute;
      top: 50%;
      left: 10%;
      transform: translateY(-50%);
      color: #fff;
    }

    .branding h1 {
      font-size: 44px;
      font-weight: bold;
    }

    .branding p {
      font-size: 16px;
      margin-top: 6px;
    }

    .form-box {
      position: absolute;
      top: 50%;
      right: 10%;
      transform: translateY(-50%);
      background-color: rgba(255, 255, 255, 0.6);
      padding: 26px;
      border-radius: 28px;
      width: 320px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      color: #fff;
    }

    .form-box label {
      font-size: 14px;
      display: block;
      margin-bottom: 5px;
    }

    .form-box input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 18px;
      border-radius: 6px;
      border: 1px solid #ccc;
      font-size: 14px;
    }

    .form-box button {
      width: 100%;
      padding: 10px;
      background-color: #2a4e7d;
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      font-size: 14px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .form-box button:hover {
      background-color: #1f3c61;
    }

    .message {
      margin-top: 12px;
      font-size: 13px;
      text-align: center;
    }

    @media (max-width: 768px) {
      .branding, .form-box {
        left: 5%;
        right: 5%;
        width: 90%;
        transform: translateY(-50%);
      }

      .branding h1 {
        font-size: 32px;
      }

      .branding p {
        font-size: 14px;
      }

      .form-box {
        padding: 20px;
      }

      .form-box input,
      .form-box button {
        font-size: 13px;
      }
    }
  </style>
</head>
<body>
  <div class="bg-image">
    <div class="overlay"></div>

    <div class="branding">
      <h1>ConnecTech</h1>
      <p>Powering Connection Without Limits</p>
    </div>

    <div class="form-box">
      <form onsubmit="resetPassword(event)">
        <label for="newPass">Password</label>
        <input type="password" id="newPass" placeholder="Enter new password" required />

        <label for="confirmPass">Confirm your Password</label>
        <input type="password" id="confirmPass" placeholder="Re-type new password" required />

        <button type="submit">CONFIRM</button>
        <div class="message" id="message"></div>
      </form>
    </div>
  </div>

  <script>
    function resetPassword(event) {
      event.preventDefault();
      const newPass = document.getElementById("newPass").value;
      const confirmPass = document.getElementById("confirmPass").value;
      const message = document.getElementById("message");

      if (newPass !== confirmPass) {
        message.textContent = "❌ Passwords do not match.";
        message.style.color = "red";
        return;
      }

      const email = localStorage.getItem("emailForReset");
      const user = JSON.parse(localStorage.getItem("dummyUser"));

      if (!user || user.email !== email) {
        message.textContent = "⚠️ Account not found or expired session.";
        message.style.color = "red";
        return;
      }

      // Simpan password baru
      user.password = newPass;
      localStorage.setItem("dummyUser", JSON.stringify(user));

      // Bersihkan data sementara
      localStorage.removeItem("otpCode");
      localStorage.removeItem("emailForReset");

      message.textContent = "✅ Password reset successful! Redirecting to login...";
      message.style.color = "limegreen";

      setTimeout(() => {
        window.location.href = "login.php";
      }, 2000);
    }
  </script>
</body>
</html>
