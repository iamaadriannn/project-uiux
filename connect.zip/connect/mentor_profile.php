<?php
$mentors = [
  1 => ['name' => 'Ica Marica H', 'photo' => 'assets/images/ica.png', 'exp' => '10 Years', 'skills' => ['Front-End', 'Back-End', 'Web Dev'], 'rating' => 4.9, 'reviews' => 76],
  2 => ['name' => 'Alif Batasa', 'photo' => 'assets/images/alif.png', 'exp' => '11 Years', 'skills' => ['Back-End', 'Cybersecurity'], 'rating' => 4.9, 'reviews' => 71],
  3 => ['name' => 'Zalzil Zulzel', 'photo' => 'assets/images/zalzil.png', 'exp' => '8 Years', 'skills' => ['Machine Learning'], 'rating' => 4.9, 'reviews' => 68],
  4 => ['name' => 'Erna Ananda', 'photo' => 'assets/images/erna.png', 'exp' => '8 Years', 'skills' => ['Front-End', 'Back-End', 'Web Dev'], 'rating' => 4.9, 'reviews' => 76],
  5 => ['name' => 'Gavin Yoo', 'photo' => 'assets/images/gavin.png', 'exp' => '15 Years', 'skills' => ['AI', 'Back-End', 'Cybersecurity'], 'rating' => 4.8, 'reviews' => 66],
  6 => ['name' => 'Hans Burga', 'photo' => 'assets/images/hans.png', 'exp' => '10 Years', 'skills' => ['Front-End', 'User-Interface'], 'rating' => 4.9, 'reviews' => 86],
  7 => ['name' => 'Laurenz De', 'photo' => 'assets/images/laurenz.png', 'exp' => '6 Years', 'skills' => ['Front-End', 'Back-End', 'Web Dev'], 'rating' => 4.2, 'reviews' => 76],
  8 => ['name' => 'Marianne', 'photo' => 'assets/images/marianne.png', 'exp' => '5 Years', 'skills' => ['Cybersecurity', 'Back-End', 'Web Dev'], 'rating' => 4.1, 'reviews' => 75],
  9 => ['name' => 'Noah Anderson', 'photo' => 'assets/images/noah.png', 'exp' => '7 Years', 'skills' => ['Game', 'AR', 'VR'], 'rating' => 4.2, 'reviews' => 70],
];


$id = isset($_GET['id']) ? (int)$_GET['id'] : 1;
$mentor = $mentors[$id] ?? null;

if (!$mentor) {
  echo "<p class='text-red-500'>Mentor not found.</p>";
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Mentor Profile - ConnecTech</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#f3f7fb] font-sans">
  <?php include 'navbar.php'; ?>
  <div class="flex min-h-screen">
    <?php include 'sidebar.php'; ?>

    <main class="ml-64 p-6 pt-20 max-w-6xl w-full">
      <div class="bg-white p-6 rounded-lg shadow-md">
        <a href="javascript:history.back()" class="text-blue-700 text-xl font-bold mb-4 inline-block">←</a>
        <h1 class="text-2xl font-bold mb-4">View Profile</h1>

        <div class="flex items-center gap-4 mb-4">
          <img src="<?= $mentor['photo'] ?>" alt="Photo" class="w-20 h-20 rounded-full object-cover">
          <div>
            <h2 class="text-xl font-semibold text-black"><?= $mentor['name'] ?> <span class="text-blue-600 font-normal">• Mentor</span></h2>
            <p class="text-md text-gray-700"><?= $mentor['exp'] ?> Experience</p>
            <p class="text-sm text-blue-600">Skills · <?= implode(' • ', $mentor['skills']) ?></p>
          </div>
        </div>

        <div class="mb-8">
          <h3 class="text-md font-semibold text-black mb-2">Select Date & Time</h3>
          <form id="bookingForm" class="space-y-4 flex flex-col sm:flex-row sm:items-center gap-4">
            <input type="date" id="bookingDate" class="border rounded px-4 py-2 text-sm w-52" required>
            <input type="time" id="bookingTime" class="border rounded px-4 py-2 text-sm w-40" required>
            <button type="submit" class="bg-[#2f5c88] hover:bg-[#1d3c5a] text-white font-semibold px-6 py-2 rounded">
              Book Now
            </button>
          </form>
        </div>

        <div class="mt-6">
          <h3 class="text-md font-bold text-black mb-4">Other Available Mentors</h3>
          <div class="flex gap-4 overflow-x-auto">
            <?php foreach ($mentors as $otherId => $other): if ($otherId === $id) continue; ?>
              <a href="mentor_profile.php?id=<?= $otherId ?>" class="bg-blue-100 p-4 rounded-lg min-w-[220px] block hover:bg-blue-200 transition">
                <div class="flex items-center gap-3 mb-2">
                  <img src="<?= $other['photo'] ?>" class="w-10 h-10 rounded-full" alt="<?= $other['name'] ?>">
                  <div>
                    <p class="font-semibold text-sm text-black"><?= $other['name'] ?></p>
                    <p class="text-xs text-gray-700"><?= $other['exp'] ?> Experience</p>
                  </div>
                </div>
                <p class="text-xs text-gray-700"><?= implode(' • ', $other['skills']) ?></p>
              </a>
            <?php endforeach; ?>
          </div>
        </div>

      </div>
    </main>
  </div>

  <script>
    document.getElementById("bookingForm").addEventListener("submit", function(e) {
      e.preventDefault();

      const date = document.getElementById("bookingDate").value;
      const time = document.getElementById("bookingTime").value;
      const mentorId = <?= $id ?>;

      if (!date || !time) {
        alert("Please select both date and time.");
        return;
      }

      const url = `book_session.php?mentor_id=${mentorId}&date=${encodeURIComponent(date)}&time=${encodeURIComponent(time)}`;
      window.location.href = url;
    });
  </script>

</body>

</html>