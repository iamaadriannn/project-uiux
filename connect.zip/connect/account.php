<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>ConnecTech - Akun</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Afacad&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech&display=swap" rel="stylesheet">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            1: '#205781',
                            2: '#FFFFFF'
                        },
                        secondary: {
                            1: '#CBEAFA',
                            2: '#468CC1'
                        },
                        tertiary: {
                            1: '#FEFCF4',
                            2: '#112C41'
                        }
                    }
                }
            }
        }
    </script>

    <style>
        * {
            font-family: 'Segoe UI', sans-serif;
        }

        .navbar {
            background-color: #1e3d59;
            color: white;
            padding: 12px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar img {
            height: 40px;
        }

        .navbar h1 {
            font-size: 20px;
            margin-left: 12px;
            font-weight: bold;
        }

        .navbar .left {
            display: flex;
            align-items: center;
            gap: 10px;
        }
    </style>
</head>

<body class="bg-[#f0f2f5]">

    <!-- Navbar -->
    <div class="navbar w-full fixed top-0 left-0 z-50">
        <div class="text-3xl tracking-wide" style="font-family:'Share Tech', sans-serif">
            ConnecTech
        </div>

        <button onclick="logout()" class="bg-red-600 hover:bg-red-700 px-4 py-2 rounded text-white">Logout</button>
    </div>

    <!-- Layout utama -->
    <div class="flex pt-[72px] min-h-screen">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Konten -->
        <div class="flex-1 pl-24">
            <div class="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow-lg">
                <h2 class="text-2xl font-semibold text-center mb-6 text-[#1e3d59]">Profil Saya</h2>

                <div class="profile-info text-center mb-6">
                    <img src="https://i.ibb.co/ZJ0kx4T/user-icon.png" alt="User" class="w-24 h-24 mx-auto rounded-full mb-2" />
                    <h3 id="displayName" class="text-lg font-bold mt-2">Nama Pengguna</h3>
                    <p id="displayRole" class="text-sm text-gray-500">Role</p>
                </div>

                <form onsubmit="updateAccount(event)" class="space-y-4">
                    <div>
                        <label for="name" class="font-semibold">Nama Lengkap</label>
                        <input type="text" id="name" class="w-full p-2 border rounded" readonly />
                    </div>

                    <div>
                        <label for="email" class="font-semibold">Email</label>
                        <input type="email" id="email" placeholder="Email baru" class="w-full p-2 border rounded" />
                    </div>

                    <div>
                        <label for="password" class="font-semibold">Password Baru</label>
                        <input type="password" id="password" placeholder="Kosongkan jika tidak ingin diubah" class="w-full p-2 border rounded" />
                    </div>

                    <div>
                        <label for="confirmPassword" class="font-semibold">Konfirmasi Password Baru</label>
                        <input type="password" id="confirmPassword" placeholder="Ulangi password baru" class="w-full p-2 border rounded" />
                    </div>

                    <div>
                        <label for="profilePic" class="font-semibold">Foto Profil</label>
                        <input type="file" id="profilePic" accept="image/*" class="w-full p-2 border rounded" />
                    </div>

                    <div class="flex justify-between mt-6 gap-4 flex-wrap">
                        <button type="submit" class="bg-[#1e3d59] text-white px-4 py-2 rounded font-semibold">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        // Jika belum login, redirect
        if (localStorage.getItem("isLoggedIn") !== "true") {
            alert("Silakan login terlebih dahulu.");
            window.location.href = "login.html";
        }

        // Ambil data user dari localStorage
        const userData = JSON.parse(localStorage.getItem("dummyUser")) || {};

        // Tampilkan data
        document.getElementById("name").value = userData.name || "";
        document.getElementById("email").value = userData.email || "";
        document.getElementById("displayName").textContent = userData.name || "Nama Pengguna";
        document.getElementById("displayRole").textContent = userData.role || "Pengguna";

        // Tampilkan foto profil jika ada
        if (userData.profilePic) {
            document.querySelector(".profile-info img").src = userData.profilePic;
        }

        // Preview gambar ketika dipilih
        document.getElementById("profilePic").addEventListener("change", (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (ev) => {
                    document.querySelector(".profile-info img").src = ev.target.result;
                };
                reader.readAsDataURL(file);
            }
        });

        // Fungsi update
        function updateAccount(event) {
            event.preventDefault();

            const newEmail = document.getElementById("email").value.trim();
            const newPassword = document.getElementById("password").value.trim();
            const confirmPassword = document.getElementById("confirmPassword").value.trim();
            const profileFile = document.getElementById("profilePic").files[0];

            if (newPassword && newPassword !== confirmPassword) {
                alert("Konfirmasi password tidak cocok!");
                return;
            }

            if (!newEmail && !newPassword && !profileFile) {
                alert("Tidak ada perubahan yang dikirim.");
                return;
            }

            const commit = () => {
                localStorage.setItem("dummyUser", JSON.stringify(userData));
                alert("Data akun berhasil diperbarui!");
                location.reload();
            };

            if (newEmail) userData.email = newEmail;
            if (newPassword) userData.password = newPassword;

            if (!profileFile) {
                commit();
                return;
            }

            const reader = new FileReader();
            reader.onload = (ev) => {
                userData.profilePic = ev.target.result;
                commit();
            };
            reader.readAsDataURL(profileFile);
        }

        function logout() {
            if (confirm("Yakin ingin logout?")) {
                localStorage.removeItem("isLoggedIn");
                window.location.href = "login.php";
            }
        }
    </script>
</body>

</html>
