<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ConnecTech - Create Discussion</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'primary-1': '#205781',
                        'primary-2': '#FFFFFF',
                        'secondary-1': '#CBEAFA',
                        'secondary-2': '#468CC1',
                        'tertiary-1': '#FEFCF4',
                        'tertiary-2': '#112C41'
                    }
                }
            }
        }
    </script>
</head>

<body class="bg-gray-50 font-sans">
    <!-- Include Navbar -->
    <?php include 'navbar.php'; ?>

    <div class="flex min-h-screen">
        <!-- Include Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Main Content -->
        <main class="flex-1 p-4 md:p-8 bg-gradient-to-br from-blue-50/30 to-blue-100/30 ml-64">
            <div class="max-w-4xl mx-auto">
                <!-- Success Message -->
                <div id="successMessage" class="hidden bg-green-50 border-2 border-green-200 rounded-xl p-4 mb-6 text-green-700 animate-fadeInUp">
                    <div class="flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                        </svg>
                        Discussion created successfully! Redirecting...
                    </div>
                </div>

                <!-- Form Container -->
                <div class="bg-white rounded-2xl shadow-xl border border-blue-100 p-6 md:p-10 animate-fadeInUp">
                    <h2 class="text-2xl md:text-3xl font-semibold text-tertiary-2 text-center mb-8">
                        Create New Discussion
                    </h2>

                    <form id="discussionForm" class="space-y-6">
                        <!-- Subject -->
                        <div class="form-group">
                            <label for="subject" class="block text-sm font-semibold text-gray-700 mb-3">
                                Subject
                            </label>
                            <input
                                type="text"
                                id="subject"
                                class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-secondary-2 focus:bg-white focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all duration-300 hover:-translate-y-0.5"
                                placeholder="Enter discussion subject..."
                                maxlength="100"
                                required>
                            <div id="subjectCounter" class="text-right text-sm text-gray-500 mt-2">
                                0/100 characters
                            </div>
                        </div>

                        <!-- Description -->
                        <div class="form-group">
                            <label for="description" class="block text-sm font-semibold text-gray-700 mb-3">
                                Description
                            </label>
                            <textarea
                                id="description"
                                rows="5"
                                class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-secondary-2 focus:bg-white focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all duration-300 resize-y min-h-[120px]"
                                placeholder="Describe your discussion topic in detail..."
                                maxlength="500"
                                required></textarea>
                            <div id="descriptionCounter" class="text-right text-sm text-gray-500 mt-2">
                                0/500 characters
                            </div>
                        </div>

                        <!-- Tags -->
                        <div class="form-group">
                            <label for="tags" class="block text-sm font-semibold text-gray-700 mb-3">
                                Tags
                            </label>
                            <div class="tags-input-container">
                                <div id="tagsDisplay" class="min-h-[3rem] p-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus-within:border-secondary-2 focus-within:bg-white focus-within:ring-4 focus-within:ring-blue-100 transition-all duration-300">
                                    <div class="flex flex-wrap gap-2 mb-2" id="tagsContainer"></div>
                                    <input
                                        type="text"
                                        id="tagInput"
                                        class="w-full border-none outline-none bg-transparent text-sm placeholder-gray-400"
                                        placeholder="Type a tag and press Enter...">
                                </div>
                            </div>
                            <small class="text-gray-500 text-sm mt-2 block">
                                Press Enter or comma to add tags. Maximum 5 tags.
                            </small>
                        </div>

                        <!-- Privacy Options -->
                        <div class="form-group">
                            <label class="block text-sm font-semibold text-gray-700 mb-3">
                                Privacy
                            </label>
                            <div class="privacy-options">
                                <div class="privacy-option selected" data-value="public">
                                    <div class="privacy-radio"></div>
                                    <span class="privacy-label">Public</span>
                                </div>
                                <div class="privacy-option" data-value="private">
                                    <div class="privacy-radio"></div>
                                    <span class="privacy-label">Private</span>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Buttons -->
                        <div class="flex flex-col md:flex-row justify-center gap-4 pt-6">
                            <button
                                type="button"
                                id="cancelBtn"
                                class="px-8 py-3 border-2 border-gray-300 text-gray-600 font-medium rounded-full hover:border-gray-400 hover:text-gray-700 hover:-translate-y-1 transition-all duration-300 order-2 md:order-1">
                                Cancel
                            </button>
                            <button
                                type="submit"
                                id="submitBtn"
                                class="px-8 py-3 bg-gradient-to-r from-secondary-2 to-primary-1 text-white font-semibold rounded-full hover:-translate-y-1 hover:shadow-xl transition-all duration-300 relative overflow-hidden order-1 md:order-2 group">
                                <span class="relative z-10">Create Discussion</span>
                                <div class="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 -translate-x-full group-hover:translate-x-full transition-transform duration-500"></div>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>

    <style>
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: scale(0.8);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        @keyframes pulse {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.05);
            }
        }

        .animate-fadeInUp {
            animation: fadeInUp 0.6s ease-out;
        }

        .animate-slideIn {
            animation: slideIn 0.3s ease-out;
        }

        .animate-pulse-custom {
            animation: pulse 1s infinite;
        }

        /* Privacy Options */
        .privacy-options {
            display: flex;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .privacy-option {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            cursor: pointer;
            padding: 1rem;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            transition: all 0.3s;
            flex: 1;
            background: #fafafa;
        }

        .privacy-option:hover {
            border-color: #468CC1;
            background: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(70, 140, 193, 0.1);
        }

        .privacy-option.selected {
            border-color: #468CC1;
            background: rgba(70, 140, 193, 0.05);
            color: #468CC1;
        }

        .privacy-radio {
            width: 18px;
            height: 18px;
            border: 2px solid #cbd5e1;
            border-radius: 50%;
            position: relative;
            transition: all 0.3s;
        }

        .privacy-option.selected .privacy-radio {
            border-color: #468CC1;
            background: #468CC1;
        }

        .privacy-option.selected .privacy-radio::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 6px;
            height: 6px;
            background: white;
            border-radius: 50%;
        }

        .privacy-label {
            font-weight: 500;
            font-size: 0.95rem;
        }

        /* Responsive untuk privacy options */
        @media (max-width: 768px) {
            .privacy-options {
                flex-direction: column;
                gap: 1rem;
            }
        }
    </style>

    <script>
        // discussionStorage.js
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize discussions array from localStorage or create empty array
            let discussions = JSON.parse(localStorage.getItem('discussions')) || [];

            // Form elements
            const form = document.getElementById('discussionForm');
            const subjectInput = document.getElementById('subject');
            const descriptionInput = document.getElementById('description');
            const tagInput = document.getElementById('tagInput');
            const tagsContainer = document.getElementById('tagsContainer');
            const privacyOptions = document.querySelectorAll('.privacy-option');
            const submitBtn = document.getElementById('submitBtn');
            const cancelBtn = document.getElementById('cancelBtn');
            const successMessage = document.getElementById('successMessage');

            // Character counters
            const subjectCounter = document.getElementById('subjectCounter');
            const descriptionCounter = document.getElementById('descriptionCounter');

            // Tags array
            let tags = [];
            let selectedPrivacy = 'public';

            // Character counting
            function updateCharCounter(input, counter, maxLength) {
                const length = input.value.length;
                counter.textContent = `${length}/${maxLength} characters`;

                if (length > maxLength * 0.9) {
                    counter.classList.add('text-red-500');
                } else {
                    counter.classList.remove('text-red-500');
                }
            }

            subjectInput.addEventListener('input', function() {
                updateCharCounter(this, subjectCounter, 100);
            });

            descriptionInput.addEventListener('input', function() {
                updateCharCounter(this, descriptionCounter, 500);
            });

            // Tags functionality
            function addTag(tagText) {
                const trimmedTag = tagText.trim().toLowerCase();

                if (trimmedTag && !tags.includes(trimmedTag) && tags.length < 5) {
                    tags.push(trimmedTag);
                    renderTags();
                    tagInput.value = '';
                }
            }

            function removeTag(tagToRemove) {
                tags = tags.filter(tag => tag !== tagToRemove);
                renderTags();
            }

            function renderTags() {
                tagsContainer.innerHTML = '';

                tags.forEach(tag => {
                    const tagElement = document.createElement('div');
                    tagElement.className = 'flex items-center gap-2 px-3 py-1.5 bg-secondary-2 text-white text-sm rounded-full animate-slideIn';
                    tagElement.innerHTML = `
                <span>${tag}</span>
                <button type="button" class="remove-tag w-4 h-4 flex items-center justify-center rounded-full hover:bg-white/20 transition-colors duration-200" data-tag="${tag}">
                    <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                    </svg>
                </button>
            `;
                    tagsContainer.appendChild(tagElement);
                });

                // Add event listeners to remove buttons
                document.querySelectorAll('.remove-tag').forEach(btn => {
                    btn.addEventListener('click', function() {
                        removeTag(this.dataset.tag);
                    });
                });
            }

            // Tag input events
            tagInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter' || e.key === ',') {
                    e.preventDefault();
                    addTag(this.value);
                }
            });

            tagInput.addEventListener('blur', function() {
                if (this.value.trim()) {
                    addTag(this.value);
                }
            });

            // Privacy selection
            privacyOptions.forEach(option => {
                option.addEventListener('click', function() {
                    privacyOptions.forEach(opt => opt.classList.remove('selected'));
                    this.classList.add('selected');
                    selectedPrivacy = this.dataset.value;
                });
            });

            // Form validation
            function validateForm() {
                const subject = subjectInput.value.trim();
                const description = descriptionInput.value.trim();

                if (!subject) {
                    alert('Please enter a subject for your discussion.');
                    subjectInput.focus();
                    return false;
                }

                if (!description) {
                    alert('Please provide a description for your discussion.');
                    descriptionInput.focus();
                    return false;
                }

                if (tags.length === 0) {
                    alert('Please add at least one tag to your discussion.');
                    tagInput.focus();
                    return false;
                }

                return true;
            }

            // Generate unique ID for discussions
            function generateId() {
                return Date.now().toString(36) + Math.random().toString(36).substr(2);
            }

            // Form submission
            form.addEventListener('submit', function(e) {
                e.preventDefault();

                if (!validateForm()) {
                    return;
                }

                // Show loading state
                submitBtn.classList.add('animate-pulse-custom', 'pointer-events-none', 'opacity-70');
                submitBtn.innerHTML = '<span class="relative z-10">Creating...</span>';

                // Create discussion object
                const newDiscussion = {
                    id: generateId(),
                    subject: subjectInput.value.trim(),
                    description: descriptionInput.value.trim(),
                    tags: [...tags],
                    privacy: selectedPrivacy,
                    members: `1 Member • ${selectedPrivacy === 'public' ? 'Public' : 'Private'} Discussion`,
                    createdAt: new Date().toISOString(),
                    author: "You", // Default author since we don't have user system
                    comments: [],
                    likes: 0
                };



                // Add to discussions array
                discussions.unshift(newDiscussion);

                // Save to localStorage
                localStorage.setItem('discussions', JSON.stringify(discussions));

                // Show success message
                successMessage.classList.remove('hidden');

                // Reset form
                form.reset();
                tags = [];
                renderTags();
                selectedPrivacy = 'public';
                privacyOptions.forEach(opt => opt.classList.remove('selected'));
                privacyOptions[0].classList.add('selected');

                // Reset counters
                subjectCounter.textContent = '0/100 characters';
                descriptionCounter.textContent = '0/500 characters';
                subjectCounter.classList.remove('text-red-500');
                descriptionCounter.classList.remove('text-red-500');

                // Reset button
                submitBtn.classList.remove('animate-pulse-custom', 'pointer-events-none', 'opacity-70');
                submitBtn.innerHTML = '<span class="relative z-10">Create Discussion</span><div class="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 -translate-x-full group-hover:translate-x-full transition-transform duration-500"></div>';

                // Redirect after 3 seconds
                setTimeout(function() {
                    window.location.href = 'MyDiscussion.php';
                }, 3000);
            });

            // Cancel button
            cancelBtn.addEventListener('click', function() {
                if (confirm('Are you sure you want to cancel? All data will be lost.')) {
                    form.reset();
                    tags = [];
                    renderTags();
                    subjectCounter.textContent = '0/100 characters';
                    descriptionCounter.textContent = '0/500 characters';
                    // Redirect to discussions page or go back
                    window.history.back();
                }
            });

            // Auto-resize textarea
            descriptionInput.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = Math.min(this.scrollHeight, 200) + 'px';
            });
        });

        // Function to get all discussions (can be used in MyDiscussion.php)
        function getAllDiscussions() {
            return JSON.parse(localStorage.getItem('discussions')) || [];
        }

        // Function to get a single discussion by ID
        function getDiscussionById(id) {
            const discussions = getAllDiscussions();
            return discussions.find(discussion => discussion.id === id);
        }

        // Function to delete a discussion
        function deleteDiscussion(id) {
            let discussions = getAllDiscussions();
            discussions = discussions.filter(discussion => discussion.id !== id);
            localStorage.setItem('discussions', JSON.stringify(discussions));
            return true;
        }

        // Function to add a comment to a discussion
        function addComment(discussionId, commentText) {
            const discussions = getAllDiscussions();
            const discussion = discussions.find(d => d.id === discussionId);

            if (discussion) {
                discussion.comments.push({
                    id: Date.now().toString(36),
                    text: commentText,
                    author: "You",
                    createdAt: new Date().toISOString()
                });

                localStorage.setItem('discussions', JSON.stringify(discussions));
                return true;
            }

            return false;
        }

        // Function to like a discussion
        function likeDiscussion(id) {
            const discussions = getAllDiscussions();
            const discussion = discussions.find(d => d.id === id);

            if (discussion) {
                discussion.likes = (discussion.likes || 0) + 1;
                localStorage.setItem('discussions', JSON.stringify(discussions));
                return discussion.likes;
            }

            return false;
        }
    </script>
</body>

</html>