<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>James's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-semibold">
                                James Peterson <span class="text-blue-500 font-normal">• Database Engineer</span>
                            </p>
                            <p class="text-xs text-gray-500">2 days ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    MySQL vs PostgreSQL for a high-transaction banking application?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">MySQL</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Postgres</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Scakability</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 7.000 Views</span>
                        <span>🤍 100 Likes</span>
                        <span>💬 30 Comments</span>
                    </div>
                    <a
                        href="./database.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to Database
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Postgres is often preferred for banking due to its strong ACID compliance.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>MySQL performs well under heavy read workloads, but for transactions, Postgres shines.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">55 minutes ago</span>
                        <p>Postgres has MVCC, which avoids table locks during transactions.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">50 minutes ago</span>
                        <p>MySQL's InnoDB is strong, but Postgres handles concurrent transactions more gracefully.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">45 minutes ago</span>
                        <p>Postgres supports advanced data types, useful for complex financial transactions.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">40 minutes ago</span>
                        <p>MySQL is simpler to set up and faster for lightweight workloads, not heavy transactions.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">35 minutes ago</span>
                        <p>Postgres’s PL/pgSQL lets you implement complex procedures directly in the DB.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">30 minutes ago</span>
                        <p>Postgres handles referential integrity and transactions with greater robustness.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">25 minutes ago</span>
                        <p>For banking, you need strong consistency — Postgres excels at this.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">20 minutes ago</span>
                        <p>MySQL's ecosystem is vast, but for financial transactions, consistency matters more.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">18 minutes ago</span>
                        <p>Postgres has a richer set of isolation levels, perfect for banking operations.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">15 minutes ago</span>
                        <p>MySQL's lightweight approach might lead to anomalies under heavy transactions.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">13 minutes ago</span>
                        <p>Postgres’ ability to handle multiversion snapshots lets readers and writers coexist.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">10 minutes ago</span>
                        <p>MySQL, with its simpler architecture, sometimes struggles under heavy concurrent transactions.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">9 minutes ago</span>
                        <p>Postgres’s strong consistency guarantees align with financial regulations.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">8 minutes ago</span>
                        <p>MySQL excels in read-heavy workloads; banking is more about transactions and consistency.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">7 minutes ago</span>
                        <p>Postgres has extensive support for PL/pgSQL, useful for financial routines.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">6 minutes ago</span>
                        <p>MySQL's ecosystem focuses more on simplicity and scaling reads.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">5 minutes ago</span>
                        <p>Postgres performs well under heavy write conditions — perfect for banking.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">4 minutes ago</span>
                        <p>MySQL's storage engines like InnoDB handle transactions, but not as robustly.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">3 minutes ago</span>
                        <p>Postgres's ability to execute complex queries efficiently is a plus for banking reports.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 minutes ago</span>
                        <p>MySQL might be faster for simple transactions, but it weakens under heavy workloads.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 minute ago</span>
                        <p>Postgres's robustness makes it a natural choice for banking applications.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 minute ago</span>
                        <p>MySQL might be simpler for small workloads, but it's not designed for heavy transactions.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 minute ago</span>
                        <p>Postgres's MVCC, PL/pgSQL, and strong ACID make it more suitable for banking.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 minute ago</span>
                        <p>MySQL might be faster for simple workloads, but for transactions, Postgres wins.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 minute ago</span>
                        <p>Postgres handles large amounts of concurrent transactions without bottleneck.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 minute ago</span>
                        <p>MySQL is a lightweight solution, not designed for heavy financial workloads.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 minute ago</span>
                        <p>Postgres excels in both integrity and reliability — key for banking data.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 minute ago</span>
                        <p>Final conclusion: Postgres is a better match for high-transaction banking applications.</p>
                    </li>
                </ul>

                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>