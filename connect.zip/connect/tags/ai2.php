<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>James Peterson's Thread</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <!-- Navbar -->
    <?php include('../navbar.php'); ?>
    <!-- Sidebar -->
    <?php include('../sidebar.php'); ?>

    <div class="flex ml-64 p-6 pt-20">
        <div class="flex-1">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="text-sm font-semibold">
                                James Peterson <span class="text-blue-500 font-normal">• XR Developer</span>
                            </p>
                            <p class="text-xs text-gray-500">2 hours ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-medium text-gray-800 mb-4">
                    How is <span class="font-semibold">Spatial Computing</span> shaping the future of human-computer interaction?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Spatial</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">XR</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">HCI</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-600">
                    <div class="flex gap-4 items-center">
                        <span>👁 2,800 Views</span>
                        <span>🤍 40 Likes</span>
                        <span>💬 10 Comments</span>
                    </div>
                    <a
                        href="./webdev.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to threads
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>This is a very insightful view on the future of HCI. Really liked your points!</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">30 minutes ago</span>
                        <p>Can't wait to see where this technology evolves in the next few years.</p>
                    </li>
                </ul>

                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>