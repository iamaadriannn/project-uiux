<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>ConnecTech - Database</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">

    <?php include '../navbar.php' ?>

    <div class="flex">
        <?php include '../sidebar.php' ?>
        <main class="flex-1 ml-64 p-6 pt-20 space-y-10">
            <!-- Title Section -->
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-semibold text-gray-700">Threads about Database</h2>
                <a href="#" class="text-blue-600 no-underline font-semibold hover:text-blue-800 transition">
                    See All Thread →
                </a>
            </div>
            <!-- Thread 2 -->
            <div class="bg-white p-6 rounded-xl shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="text-sm font-semibold">James Peterson <span class="text-blue-500 font-normal">• Database Engineer</span></p>
                            <p class="text-xs text-gray-500">2 days ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-medium text-gray-800 mb-4">
                    MySQL vs PostgreSQL for a high-transaction banking application?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">MySQL</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Postgres</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Scalability</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-600">
                    <div class="flex gap-4 items-center">
                        <span>👁 7,000 Views</span>
                        <span>🤍 100 Likes</span>
                        <span>💬 30 Comments</span>
                    </div>
                    <button class="text-blue-600 hover:underline">
                        <a href="./database1.php">Open Thread</a>
                    </button>
                </div>
            </div>

            <!-- Thread 3 -->
            <div class="bg-white p-6 rounded-xl shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="text-sm font-semibold">Alice Harper <span class="text-blue-500 font-normal">• Cloud Engineer</span></p>
                            <p class="text-xs text-gray-500">3 days ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-medium text-gray-800 mb-4">
                    Best backup strategies for multi-database architecture?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Backup</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Redundancy</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Disaster Recovery</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-600">
                    <div class="flex gap-4 items-center">
                        <span>👁 1.000 Views</span>
                        <span>🤍 80 Likes</span>
                        <span>💬 10 Comments</span>
                    </div>
                    <button class="text-blue-600 hover:underline">
                        <a href="./database2.php">Open Thread</a>
                    </button>
                </div>
            </div>

            <!-- Thread 4 -->
            <div class="bg-white p-6 rounded-xl shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="text-sm font-semibold">Mike Rogers <span class="text-blue-500 font-normal">• Database Analyst</span></p>
                            <p class="text-xs text-gray-500">5 days ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-medium text-gray-800 mb-4">
                    How to optimize slow JOIN queries in a large table?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Query</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Index</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Performance</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-600">
                    <div class="flex gap-4 items-center">
                        <span>👁 2,000 Views</span>
                        <span>🤍 90 Likes</span>
                        <span>💬 20 Comments</span>
                    </div>
                    <button class="text-blue-600 hover:underline">
                        <a href="./database3.php">Open Thread</a>
                    </button>
                </div>
            </div>

            <!-- Thread 5 -->
            <div class="bg-white p-6 rounded-xl shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="text-sm font-semibold">Laura Kim <span class="text-blue-500 font-normal">• Data Scientist</span></p>
                            <p class="text-xs text-gray-500">1 week ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-medium text-gray-800 mb-4">
                    Tips for designing a scalable multi-tenant database schema?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Scalable</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Multi-Tenant</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Design</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-600">
                    <div class="flex gap-4 items-center">
                        <span>👁 9,000 Views</span>
                        <span>🤍 150 Likes</span>
                        <span>💬 50 Comments</span>
                    </div>
                    <button class="text-blue-600 hover:underline">
                        <a href="./database4.php">Open Thread</a>
                    </button>
                </div>
            </div>

            <!-- Thread 6 -->
            <div class="bg-white p-6 rounded-xl shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="text-sm font-semibold">Charlie Zhang <span class="text-blue-500 font-normal">• Database Engineer</span></p>
                            <p class="text-xs text-gray-500">1 hours ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-medium text-gray-800 mb-4">
                    What's Post-Quantum Cryptography and how will it affect database security?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Post-Quantum</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Cryptography</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Security</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-600">
                    <div class="flex gap-4 items-center">
                        <span>👁 10.000 Views</span>
                        <span>🤍 1.000 Likes</span>
                        <span>💬 50 Comments</span>
                    </div>
                    <button class="text-blue-600 hover:underline">
                        <a href="./database5.php">Open Thread</a>
                    </button>
                </div>
            </div>

    </div>
    </main>
    </div>

</body>

</html>