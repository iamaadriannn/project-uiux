<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Sophie's Thread</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <!-- Navbar -->
    <?php include('../navbar.php'); ?>
    <!-- Sidebar -->
    <?php include('../sidebar.php'); ?>

    <div class="flex ml-64 p-6 pt-20">
        <div class="flex-1">
            <div class="bg-white p-6 rounded-lg shadow mb-6">
                <div class="flex justify-between items-center mb-2">
                    <div>
                        <span class="font-semibold">Sophie</span>
                        <span class="text-sm text-gray-500">just now</span>
                    </div>
                </div>

                <p class="mb-4">
                    Framework vs vanilla JavaScript — when to use which?
                </p>

                <div class="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div class="space-x-2">
                        <span>👁 20</span>
                        <span>👍 1</span>
                        <span>💬 0</span>
                    </div>
                </div>

                <a
                    href="./webdev.php"
                    class="text-blue-600 hover:underline">
                    &larr; Back to threads
                </a>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <!-- Currently no comments -->
                    <li class="text-gray-500 p-4 rounded shadow">
                        Be the first to comment on this thread.
                    </li>
                </ul>

                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                // Remove "Be the first" if it's present
                if (ul.children.length === 1 && ul.children[0].innerHTML.indexOf('Be the first') !== -1) {
                    ul.innerHTML = '';
                }

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>