<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Mike's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-semibold">
                                Mike Brown <span class="text-blue-500 font-normal">• VR Developer</span>
                            </p>
                            <p class="text-xs text-gray-500">3 days ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    Best SDK for developing VR games in 2025?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">VR</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Unity</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">SDK</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 9.000 Views</span>
                        <span>🤍 400 Likes</span>
                        <span>💬 25 Comments</span>
                    </div>
                    <a
                        href="./mobiledev.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to Game Development
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 day ago</span>
                        <p>Unity’s XR Interaction Toolkit is a solid base for VR games in 2025.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">23 hours ago</span>
                        <p>OpenXR is a must-know; it's a universal standard across VR platforms now.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">20 hours ago</span>
                        <p>Meta Quest SDK is great if you’re developing for Quest 2 or Quest 3.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">18 hours ago</span>
                        <p>For PC VR, SteamVR plugin lets you connect to a huge range of headsets.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Daniel</span> <span class="text-gray-500 ml-2 text-sm">15 hours ago</span>
                        <p>Unreal 5’s VR Template is a strong starting point if you prefer C++/Blueprints.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">13 hours ago</span>
                        <p>OpenXR + Unity lets you deploy once across multiple headsets — huge time-saver.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">11 hours ago</span>
                        <p>Don’t forget about AR Foundation if you’re branching into AR/VR hybrid.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">9 hours ago</span>
                        <p>VRTK is a powerful framework for interaction in Unity, great for prototyping.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">8 hours ago</span>
                        <p>For enterprise VR, Microsoft’s Mixed Reality Toolkit (MRTK) is a strong contender.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">7 hours ago</span>
                        <p>OpenFrameworks with C++ can be a lightweight solution for custom VR applications.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">6 hours ago</span>
                        <p>A-Frame is nice for Web VR; it lets you create VR scenes directly in HTML and JavaScript.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">5 hours ago</span>
                        <p>Three.js + WebXR is a lightweight stack for developing VR for the browser.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>OpenVR plugin is a fallback for older VR headsets.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Using XR Plugin in Unity lets you streamline SDKs under a unified API.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Don’t forget to check headset-specific SDKs (like Pico or Vive) for advanced controls.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Hand-tracking SDKs (like Ultraleap) can add a lot of depth to your VR experience.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Physics SDKs, like NVIDIA PhysX, are useful for realistic VR interactions.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Networking for VR is a consideration — Mirror or Photon can handle multi-user worlds.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Consider SDKs with good community and ecosystem; Unity and Meta Quest are strong here.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Developer docs and community support can be a huge time-saver when choosing SDKs.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">50 minutes ago</span>
                        <p>OpenSource SDKs like Godot VR may be viable if you prefer lightweight solutions.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">40 minutes ago</span>
                        <p>Hand and Eye tracking SDKs can add depth to UX; Meta Quest supports both now.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">30 minutes ago</span>
                        <p>Don’t ignore performance; lightweight SDKs often outperform heavy ones on Quest.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">20 minutes ago</span>
                        <p>Unity’s Asset Store has many VR toolkits to kickstart your project quickly.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">10 minutes ago</span>
                        <p>Ultimately, choosing SDK depends on your hardware, platform, and team expertise.</p>
                    </li>
                </ul>



                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>