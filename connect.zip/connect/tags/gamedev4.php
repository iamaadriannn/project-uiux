<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Alex's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-semibold">
                                Alex Peterson <span class="text-blue-500 font-normal">• Audio Engineer</span>
                            </p>
                            <p class="text-xs text-gray-500">6 hours ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    How to integrate adaptive audio in games?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Audio</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Design</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Implementation</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 2.000 Views</span>
                        <span>🤍 500 Likes</span>
                        <span>💬 10 Comments</span>
                    </div>
                    <a
                        href="./mobiledev.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to Game Development
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 day ago</span>
                        <p>Using Audio Mixers can help you blend different audio snapshots smoothly during gameplay.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 day ago</span>
                        <p>Consider using Audio Parameter (RTPC) to respond to health, speed, or enemies nearby.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">20 hours ago</span>
                        <p>Using Wwise or FMOD lets you implement adaptive audio without hard-coding all transitions.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">18 hours ago</span>
                        <p>Design your audio in Layers (music, ambiance, effects) to control each separately.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Daniel</span> <span class="text-gray-500 ml-2 text-sm">15 hours ago</span>
                        <p>Consider adding a small state machine to handle transitions between audio states.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">10 hours ago</span>
                        <p>Using audio snapshots lets you morph audio when entering a cave or a battle scene.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">9 hours ago</span>
                        <p>Consider adding lowpass or reverb effects to reflect environment change.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">7 hours ago</span>
                        <p>Using Audio Bus controls, you can smoothly adjust volumes of groups of sounds.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">5 hours ago</span>
                        <p>Pair audio events with game signals to activate/deactivate musical motifs.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Don’t forget to fine-tune audio transitions to match game pacing.</p>
                    </li>
                </ul>


                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>