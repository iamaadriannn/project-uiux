<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Alice's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-semibold">
                                Alice Kim <span class="text-blue-500 font-normal">• Security Engineer</span>
                            </p>
                            <p class="text-xs text-gray-500">1 days ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    Security implications of using multi-cloud services?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">cloud</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">deployment</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">compliance</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 7.500 Views</span>
                        <span>🤍 220 Likes</span>
                        <span>💬 35 Comments</span>
                    </div>
                    <a
                        href="./mobiledev.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to Cyber Security
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <ul id="commentList" class="space-y-4 mb-4">
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Using multi-cloud certainly increases attack surface; we need strong controls across all providers.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Consistent policy enforcement across clouds is a huge challenge for enterprise security teams.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Misconfigurations are more likely when you deal with different platforms’ settings.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Managing identities across clouds (IAM) is a key vulnerability if not properly configured.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Using multi-cloud without a unified view can create blind spots in your security posture.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Encryption and key management must be consistent across clouds, which is hard to implement.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>API endpoints become numerous and harder to control in multi-cloud setups.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Traffic between clouds can become a weak link if not properly encrypted and routed.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Different logging and monitoring platforms can undermine unified incident response.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Security controls may vary in depth and capabilities across providers.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Maintaining compliance across platforms is challenging and prone to oversight.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>A unified vulnerability management approach is hard to implement in multi-cloud.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>The attack surface grows with each additional service and API you expose.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Supply chain attacks become more plausible in a multicloud context.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Different clouds may have different patch schedules, adding to vulnerability exposure.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Privilege escalation is a huge risk if roles and policies aren’t properly defined across clouds.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Using a multi-cloud architecture without a strong IAM strategy is a recipe for chaos.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Configuration drift is a hidden danger when you manually manage multiple clouds.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Automated compliance checks become more complex in a multicloud context.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Maintaining a unified view of all resources is a huge operational challenge.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>A strong vulnerability scanning process must account for all clouds in use.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>The shared responsibility model varies by provider; understanding it is key to securing workloads.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Audit and compliance reports become more cumbersome to produce across clouds.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Staff need specialized knowledge for each platform, adding to training burdens.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>A unified Security Operations Center (SOC) view is hard to achieve in multicloud.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Automated incident response workflows may break when different clouds handle signals differently.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Event enrichment and threat correlation become more challenging across clouds.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Managing secrets safely across clouds is a delicate issue.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Using multicloud-native services can create hidden dependency chains.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Managing certificates and PKI across clouds adds operational complexity.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Higher likelihood of human error when configuring numerous services manually.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>The key is having strong orchestration, policy-as-code, and automated controls.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>A multicloud strategy should be designed with security in mind from the outset.</p>
                            </li>
                            <li class="bg-gray-50 p-4 rounded shadow">
                                <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 days ago</span>
                                <p>Ultimately, visibility, consistency, and automation are key to mitigating multicloud risks.</p>
                            </li>
                        </ul>


                        <input id="commentInput"
                            type="text"
                            placeholder="Add a comment…"
                            class="w-full p-2 mb-2 border rounded outline-none">

                        <button id="addCommentBtn"
                            class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                            Comment
                        </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>