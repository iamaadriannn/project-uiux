<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>ConnecTech - Mobile Development</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20 space-y-10">
            <h1 class="text-2xl font-semibold mb-6">Mobile Development</h1>
            <div class="bg-white p-4 rounded-lg shadow mb-6">
                <div class="flex items-start space-x-4">
                    <div class="w-10 h-10 rounded-full bg-gray-300"></div>
                    <div class="flex-1">
                        <input id="threadInput" type="text" placeholder="Let's share what’s going on in Mobile Development…" class="w-full border-none outline-none" />
                        <div class="flex items-center justify-between mt-2">
                            <div class="space-x-3 text-sm text-gray-500">
                                <button>📁 Files</button>
                                <button>🖼️ Images</button>
                                <button>🏷️ Category</button>
                            </div>
                            <button id="createBtn" class="bg-[#2c4c66] text-white px-4 py-1 rounded hover:bg-[#1f3a50]">Create</button>
                        </div>
                    </div>
                </div>
            </div>

            <div id="threadContainer" class="space-y-4">
                <!-- Thread Example -->
                <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex justify-between items-center mb-2">
                        <div>
                            <span class="font-semibold">Alice</span> · <span class="text-sm text-gray-500">2 days ago</span>
                        </div>
                    </div>
                    <p class="mb-4">How to handle state efficiently in Flutter?</p>
                    <div class="flex items-center justify-between text-sm text-gray-500">
                        <div class="space-x-2">
                            <span>👁 500</span>
                            <span>👍 20</span>
                            <span>💬 10</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./mobiledev1.php">Open Thread</a>
                        </button>
                    </div>
                </div>
                <!-- Thread 2 -->
                <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex justify-between items-center mb-2">
                        <div>
                            <span class="font-semibold">Mike</span> · <span class="text-sm text-gray-500">1 day ago</span>
                        </div>
                    </div>
                    <p class="mb-4">Best practices for Flutter folder structure?</p>
                    <div class="flex items-center justify-between text-sm text-gray-500">
                        <div class="space-x-2">
                            <span>👁 250</span>
                            <span>👍 10</span>
                            <span>💬 5</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./mobiledev2.php">Open Thread</a>
                        </button>
                    </div>
                </div>

                <!-- Thread 3 -->
                <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex justify-between items-center mb-2">
                        <div>
                            <span class="font-semibold">Charlie</span> · <span class="text-sm text-gray-500">3 hours ago</span>
                        </div>
                    </div>
                    <p class="mb-4">How to implement Push Notifications in React Native?</p>
                    <div class="flex items-center justify-between text-sm text-gray-500">
                        <div class="space-x-2">
                            <span>👁 100</span>
                            <span>👍 5</span>
                            <span>💬 2</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./mobiledev3.php">Open Thread</a>
                        </button>
                    </div>
                </div>

                <!-- Thread 4 -->
                <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex justify-between items-center mb-2">
                        <div>
                            <span class="font-semibold">Daniel</span> · <span class="text-sm text-gray-500">5 hours ago</span>
                        </div>
                    </div>
                    <p class="mb-4">What’s the best state management for large Flutter apps?</p>
                    <div class="flex items-center justify-between text-sm text-gray-500">
                        <div class="space-x-2">
                            <span>👁 80</span>
                            <span>👍 4</span>
                            <span>💬 1</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./mobiledev4.php">Open Thread</a>
                        </button>
                    </div>
                </div>

                <!-- Thread 5 -->
                <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex justify-between items-center mb-2">
                        <div>
                            <span class="font-semibold">Sophie</span> · <span class="text-sm text-gray-500">just now</span>
                        </div>
                    </div>
                    <p class="mb-4">Framework comparison: Flutter vs React Native in 2025</p>
                    <div class="flex items-center justify-between text-sm text-gray-500">
                        <div class="space-x-2">
                            <span>👁 20</span>
                            <span>👍 1</span>
                            <span>💬 0</span>
                        </div>
                        <button class="text-blue-600 hover:underline">
                            <a href="./mobiledev5.php">Open Thread</a>
                        </button>
                    </div>
                </div>

                <!-- Thread 6 -->
                <div class="bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                    <div class="flex justify-between items-center mb-2">
                        <div>
                            <span class="font-semibold">James</span> · <span class="text-sm text-gray-500">10 minutes ago</span>
                        </div>
                    </div>
                    <p class="mb-4">How to handle deep linking in Flutter apps?</p>
                    <div class="flex items-center justify-between text-sm text-gray-500">
                        <div class="space-x-2">
                            <span>👁 35</span>
                            <span>👍 2</span>
                            <span>💬 0</span>
                        </div>
                       <button class="text-blue-600 hover:underline">
                            <a href="./mobiledev6.php">Open Thread</a>
                        </button>
                    </div>
                </div>

            </div>
        </main>
    </div>

    <script>
        const createBtn = document.getElementById("createBtn");
        const threadInput = document.getElementById("threadInput");
        const threadContainer = document.getElementById("threadContainer");

        createBtn.addEventListener("click", () => {
            const content = threadInput.value.trim();
            if (content === "") {
                alert("Please enter a thread message.");
                return;
            }
            const newThread = document.createElement("div");
            newThread.className = "bg-white p-4 rounded-lg shadow transition duration-300 transform hover:-translate-y-1 hover:shadow-lg";
            newThread.innerHTML = `
        <div class="flex justify-between items-center mb-2">
          <div>
            <span class="font-semibold">You</span> · <span class="text-sm text-gray-500">Just now</span>
          </div>
        </div>
        <p class="mb-4">${content}</p>
        <div class="flex items-center justify-between text-sm text-gray-500">
          <div class="space-x-2">
            <span>👁 0</span>
            <span>👍 0</span>
            <span>💬 0</span>
          </div>
          <button class="text-blue-600 hover:underline">Open Thread</button>
        </div>
      `;
            threadContainer.prepend(newThread);
            threadInput.value = "";
        });
    </script>

</body>

</html>