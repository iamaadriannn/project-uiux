<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Maria's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-semibold">
                                Maria Lopez <span class="text-blue-500 font-normal">• Data Scientist</span>
                            </p>
                            <p class="text-xs text-gray-500">1 days ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    What are the best practices for avoiding overfitting in deep neural nets?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Deep Learning</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Overfitting</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Genealization</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 11.500 Views</span>
                        <span>🤍 220 Likes</span>
                        <span>💬 35 Comments</span>
                    </div>
                    <a
                        href="./machinelearning.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to Machine Learning
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 day ago</span>
                        <p>Using dropout is a classic way to avoid overfitting in deep nets.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">23 hours ago</span>
                        <p>Regularization methods like L1 and L2 help keep weights small and avoid overfitting.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">20 hours ago</span>
                        <p>Reducing network complexity (fewer layers or neurons) can cut back overfitting.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">18 hours ago</span>
                        <p>Using dropout at different points in the network prevents co-adaptation.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">17 hours ago</span>
                        <p>Data augmentation, like adding transforms or cropping, can help the network generalize.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">16 hours ago</span>
                        <p>Using batch normalization can stabilize training and reduce overfitting.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">15 hours ago</span>
                        <p>Early stopping lets you halt training when validation error starts to rise.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">14 hours ago</span>
                        <p>Reducing the number of epochs prevents the network from memorizing the training set.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">13 hours ago</span>
                        <p>Weight tying and parameter sharing can cut back on redundancy and overfitting.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">12 hours ago</span>
                        <p>Using a small validation set lets you track when overfitting starts.</p>
                    </li>

                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">11 hours ago</span>
                        <p>Drop connect is another form of dropout, dropping weights instead of neurons.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">10 hours ago</span>
                        <p>Label smoothing prevents the network from becoming overconfident.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">9 hours ago</span>
                        <p>Using a lower learning rate can avoid overfitting by slowing convergence.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">8 hours ago</span>
                        <p>Hyperparameter tuning (like choosing dropout rate or weight decay) is key to preventing overfitting.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">7 hours ago</span>
                        <p>Using smaller batches during training adds some beneficial “noise” to the update.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">6 hours ago</span>
                        <p>Pruning can cut back needless weights, simplifying the network afterwards.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">5 hours ago</span>
                        <p>Using transfer learning lets you leverage a pre-trained network instead of starting from scratch.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Reducing the capacity of the network can cut back on overfitting.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Using k-fold cross-validation lets you robustly validate performance.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Normalization techniques, like layernorm or instancenorm, help control variance.</p>
                    </li>

                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Using a validation set to guide hyperparameter choices prevents overfitting to training data.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Weight clipping can control the magnitude of weights during training.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Using a smaller network first and scaling up if necessary is a good practice.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Weight freezing lets you control which parts of the network learn.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Using an appropriate activation function can affect overfitting; ReLU is often a good baseline.</p>
                    </li>

                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Reducing redundancy by adding bottleneck layers can cut back overfitting.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Using skip connections (residuals) lets the network learn more robust representations.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Reduce training data complexity by removing duplicates or simplifying inputs.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Consider adding Gaussian noise to inputs to make the network more robust.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Using label dropout (ignoring a small % of labels) prevents overdependence on training signals.</p>
                    </li>

                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Training with adversarial samples can toughen the network against overfitting.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Using small kernel sizes and stride can cut back on redundancy in convolutional nets.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Final fine-tuning with lower LR prevents over-adjusting weights.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Using a combination of these methods often performs better than just one.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Ultimately, trial and validation are key — there’s no one-size-fits-all.</p>
                    </li>
                </ul>

                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>