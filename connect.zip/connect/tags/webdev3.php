<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Charlie's Thread</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <!-- Navbar -->
    <?php include('../navbar.php'); ?>
    <!-- Sidebar -->
    <?php include('../sidebar.php'); ?>

    <div class="flex ml-64 p-6 pt-20">
        <div class="flex-1">
            <div class="bg-white p-6 rounded-lg shadow mb-6">
                <div class="flex justify-between items-center mb-2">
                    <div>
                        <span class="font-semibold">Charlie</span>
                        <span class="text-sm text-gray-500">3 hours ago</span>
                    </div>
                </div>

                <p class="mb-4">
                    How to implement dark and light mode efficiently?
                </p>

                <div class="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div class="space-x-2">
                        <span>👁 100</span>
                        <span>👍 5</span>
                        <span>💬 2</span>
                    </div>
                </div>

                <a
                    href="./webdev.php"
                    class="text-blue-600 hover:underline">
                    &larr; Back to threads
                </a>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Using a context or state to track the theme is a good approach.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Alice</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Also consider adding a button to manually switch themes.</p>
                    </li>
                </ul>

                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                document.getElementById('commentList').prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>