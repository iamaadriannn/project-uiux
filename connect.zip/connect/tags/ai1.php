<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Alex's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-semibold">
                                Alex Bijer <span class="text-blue-500 font-normal">• Machine Learning Engineer</span>
                            </p>
                            <p class="text-xs text-gray-500">2 days ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    What's a good way to implement a chatbot with large context and memory?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Chatbot</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">AI</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">NLP</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 9.500 Views</span>
                        <span>🤍 220 Likes</span>
                        <span>💬 40 Comments</span>
                    </div>
                    <a
                        href="./ai.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to Artificial Intelligence
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Alice</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Using vector databases like Pinecone or FAISS lets you efficiently store and retrieve large context.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ben</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Chunk your documents first and generate embeddings for each piece to enable semantic search.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>OpenAI’s Embedding API is a popular way to transform text into vector representations quickly.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Diana</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>A retrieval-optimized chatbot typically performs a semantic search first, then feeds context to the LLM.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Evan</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Using LangChain or LlamaIndex can streamline the process of integrating vector stores with LLMs.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Faith</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Chatbot memory often comprises two components: short-term (context window) and long-term (vector search).</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">George</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Short term lets you maintain flow, while long term lets you remember conversations across sessions.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Hana</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>A hybrid approach lets you combine both methods effectively.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ian</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Redis can be a lightweight cache for short conversations, while vector DB handles deep memory.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Jade</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Consider adding metadata to your vector documents (like IDs, tags, timestamps) for context filtering.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ken</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>A well-engineered pipeline first parses messages, then performs retrieval and context injection.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Lia</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>This lets you handle large knowledge bases without exceeding the LLM's context window.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Some chatbot architectures use "Chat history + retrieved documents" as context for the prompt.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Nina</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>The key is retrieving the most relevant chunks efficiently under latency constraints.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Oscar</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Using approximate nearest neighbors makes vector search faster and more scalable.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Paul</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>FAISS is a popular option when you need to implement vector search yourself.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Queen</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Scalable vector stores often use HNSW graphs or IVF to index large amounts of data quickly.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ryan</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>The architecture should allow adding, updating, and removing documents gracefully.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sarah</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>A good practice is to regularly prune or consolidate vector documents to control size.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Tom</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Design your storage to handle multi-user, multi-session contexts separately.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ursula</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Identify conversations by IDs and retrieve context by matching those IDs first.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Victor</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Some methods combine vector search with traditional keyword search for robustness.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Wendy</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Scenarios with large context may need to paginate or prioritize context segments.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Xavier</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Using a scoring algorithm to rerank retrieved segments can improve coherence.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Yana</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Some implement a "Chat Summary" to shorten conversations over time.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Zane</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>A periodic summarization lets you retain key points without overwhelm.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Amber</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>The summary can act as “compacted memory” alongside vector search.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Blake</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Design your prompting to gracefully fallback if context isn’t available.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie 2</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>This prevents weird responses when context retrieval fails.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Derek</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>A fallback might be a friendly “I don't remember, please tell me again.”</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Elias</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>The context pipeline should be well-engineered to handle failures gracefully.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Flora</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Designing retrieval strategies is an art — it's about choosing what matters most.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Gordon</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Some implement scoring to cut off segments below a certain similarity.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Hector</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>A well-tuned cutoff prevents overloading context with irrelevant details.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Iris</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Some strategies leverage Hybrid Search (combining semantic and keywords).</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Hybrid lets you match both literal keywords and semantic context.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Kate</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Design consideration: how frequently you update your vector index with new messages.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Leo</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>A well-updated index lets you reflect conversations in real time.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mia</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Ultimately, designing large-context chat is about choosing the right combination of methods for your use case.</p>
                    </li>
                </ul>

                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>