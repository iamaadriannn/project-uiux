<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Charlie's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-semibold">
                                Charlie Zang <span class="text-blue-500 font-normal">• Database Engineer </span>
                            </p>
                            <p class="text-xs text-gray-500">1 hours ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    Tips for designing a scalable multi-tenant database schema?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Scalable</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Multi-talent</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Design</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 10.000 Views</span>
                        <span>🤍 1.000 Likes</span>
                        <span>💬 50 Comments</span>
                    </div>
                    <a
                        href="./database.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to Database
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Alice</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Post-Quantum Cryptography (PQC) focuses on developing algorithms that can resist attacks from quantum computers.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ben</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>This matters for databases because a large-scale quantum computer could break classical encryption methods we use today.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>RSA and elliptic curve, which we rely on for securing data at rest and in transit, may become vulnerable.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Diana</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>PQC algorithms aim to use mathematical problems that are hard for both classical and quantum computers to solve.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Evan</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Lattice, hash, multivariate polynomial, and code-based cryptography are some of the leading approaches.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Faith</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Switching to PQC will require updating database authentication, backup, and encryption mechanisms.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">George</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>This might affect both password storage and communication protocols for database connections.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Hana</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Post-Quantum readiness involves choosing algorithm suites that NIST is standardizing now.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ian</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The NIST Post-Quantum Standardization process is currently evaluating candidate algorithms.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Jade</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Some databases may implement hybrid schemes — classical plus PQC — during the transition.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ken</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>This lets organizations gradually move forward without losing backward compatibility immediately.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Lia</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The main impact will be greater key sizes and possibly slower operations for certain transactions.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Database vendors need to update their storage, indexing, and backup methods to handle PQC keys.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Nina</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Encryption-at-rest might move toward lattice-based schemes instead of RSA, for future-proofing.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Oscar</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Backup files may need to be re-encrypted with post-quantum-safe methods to avoid future compromise.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Paul</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Key exchange during database connection handshake will need post-quantum-safe protocols.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Queen</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>This guarantees that future messages encrypted today remain secret even if a quantum computer emerges.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ryan</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Some databases already implement “post-quantum-safe” versions of their connect protocols in preview.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sarah</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The industry must reassess PKI certificates and renewal timelines to account for PQC migration.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Tom</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Some organizations are already inventorying their cryptographic components in preparation.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ursula</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Scalable database architecture must account for bigger keys and messages.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Victor</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The CPU, memory, and network requirements for PQC may be greater, affecting performance.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Wendy</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Design decisions made today should account for future-proof cryptographic primitives.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Xavier</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Backup and recovery strategies should include a PQC migration path.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Yana</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>This might require multi-phase rollout and extensive testing to avoid disruptions.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Zane</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Some legacy databases may struggle to support PQC without significant refactor.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Amber</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>A hybrid approach lets you combine classical and PQC to balance risk and performance.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Blake</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The main drivers for change are growing computing power and “harvest now, decrypt later” attacks.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie 2</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>This means encrypted data stolen today might be vulnerable in the future when quantum machines become viable.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Derek</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Backup strategies should consider future-proofing against “harvest now, decrypt later” attacks.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Elias</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The migration process must be carefully tested to avoid service outages and data-loss risks.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Flora</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Training and education for database administrators is key to a smooth PQC rollout.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Gordon</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Some backup software vendors are already adding PQC readiness to their roadmaps.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Hector</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Encryption libraries need to be carefully updated to avoid interoperability issues.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Iris</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Some database-native encryption may need refactor to accommodate PQC primitives.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Key management services must be upgraded to handle new algorithm suites.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Kathy</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The cost of implementation will depend on scale and complexity of the existing architecture.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Loren</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>A gradual rollout lets you minimize risk and learn from small-scale deployment first.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mona</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Some organizations may combine PQC migration with a broader database modernization effort.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Nate 2</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Using a hybrid approach lets you backtrack if a PQC algorithm shows weaknesses later on.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Opal</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Some companies are already trialling post-quantum-safe databases in their lab environment.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Pete</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The migration is not a “flip of a switch”—it involves careful planning, testing, and rollout phases.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Qiana</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Ultimately, PQC aims to future-proof data against attacks from powerful quantum computers.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ramesh</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The main benefits will be confidentiality and integrity of data for decades to come.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Silas</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Some sectors, like banking and healthcare, will be first movers due to high-risk data.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Tariq</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The industry will need collaboration to standardize and implement PQC smoothly.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Urs</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Some clouds already provide PQC primitives in their key management services.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Van</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Open-source libraries like Open Quantum Safe help integrate PQC into existing codebases.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Willow</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The main consideration is securing both future and legacy data in a cost-effective way.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Xia</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The first step for many companies is a cryptographic inventory to assess readiness.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Yuri</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Once inventories are complete, companies can plan their migration roadmapping.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Zoe</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Ultimately, PQC is a key piece in securing databases against future cyberthreats.</p>
                    </li>
                </ul>


                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>