<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Laura's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-semibold">
                                Laura Kim <span class="text-blue-500 font-normal">• Data Scientist </span>
                            </p>
                            <p class="text-xs text-gray-500">1 week ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    Tips for designing a scalable multi-tenant database schema?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Scalable</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Multi-talent</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Design</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 9.000 Views</span>
                        <span>🤍 150 Likes</span>
                        <span>💬 50 Comments</span>
                    </div>
                    <a
                        href="./database.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to Database
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Alice</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Start by deciding your tenancy model: shared database & schema, shared database with separate schemas, or separate databases per tenant.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Bob</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Use a tenant identifier column in all shared tables to isolate data logically.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Clara</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Index the tenant ID column to improve query performance for tenant-specific data.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">David</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Consider schema-per-tenant if tenant data size or customization needs vary significantly.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ella</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Design your schema to allow easy tenant onboarding and offboarding without downtime.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Frank</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Implement row-level security to enforce tenant data isolation at the database level.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Grace</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Use connection pooling and caching per tenant to improve scalability.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Henry</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Keep tenant metadata in a separate, centralized table to manage configurations and limits.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ivy</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Partition large shared tables by tenant ID to improve query speed and maintenance.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Jack</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Design for horizontal scalability—sharding tenants across database clusters if needed.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Kate</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Automate tenant provisioning with scripts or orchestration tools for consistent setups.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Leo</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Be cautious with cross-tenant joins or queries; always filter by tenant ID to avoid data leaks.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Maya</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Encrypt sensitive tenant data, and manage encryption keys per tenant if possible.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Nate</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Monitor tenant-specific usage patterns to identify hotspots and optimize performance.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Olivia</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Design APIs to always accept tenant context to prevent accidental data cross-access.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Paul</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Use soft deletes or archival strategies tailored per tenant for data retention policies.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Quinn</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Regularly run cleanup jobs to maintain database health across all tenants.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Rita</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Test schema migrations thoroughly in a multi-tenant environment to avoid downtime or data loss.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sam</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Design tenant identifiers as immutable to avoid complex updates and maintain consistency.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Tina</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Consider tenant-specific feature flags to customize behavior without schema changes.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Umar</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Use database views or row-level security to provide tenant isolation without duplicating data.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Vera</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Plan for tenant data growth; periodically archive inactive tenants or their data.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Will</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Isolate tenant backups for easier restores and disaster recovery.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Xena</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Automate tenant scaling and resource allocation based on load or SLA requirements.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Yusuf</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Keep schema changes backward-compatible to avoid tenant disruptions during deployments.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Zara</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Use consistent tenant naming conventions and metadata for easy maintenance.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Aaron</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Keep tenant-specific logs separate for auditing and troubleshooting.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Bella</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Consider the trade-offs between cost and isolation when choosing tenancy model.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Caleb</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Use metadata-driven schema extensions for tenant-specific customizations without altering core schema.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Diana</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Leverage cloud-native database features for scaling multi-tenant workloads efficiently.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ethan</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Perform load testing with simulated tenants to identify bottlenecks before production.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Fiona</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Implement tenant quotas to prevent noisy neighbors from degrading overall system performance.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Gabe</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Ensure tenant data compliance by supporting data residency and GDPR-like regulations per tenant.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Holly</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Design tenant identifiers to be immutable and unique across all databases and shards.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Ivan</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Use multi-tenant-aware monitoring tools to track per-tenant performance and errors.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Jade</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Regularly review and optimize indexes, especially on tenant ID and frequently queried columns.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Kyle</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Document tenant onboarding and schema management processes for operational consistency.</p>
                    </li>
                </ul>


                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>