<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Sarah's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-semibold">
                                Sarah Lee <span class="text-blue-500 font-normal">• 3D Artist</span>
                            </p>
                            <p class="text-xs text-gray-500">5 hours ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    Tips for designing low-poly models for games?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Blender</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Model</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Design</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 5.000 Views</span>
                        <span>🤍 100 Likes</span>
                        <span>💬 20 Comments</span>
                    </div>
                    <a
                        href="./mobiledev.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to Game Development
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 day ago</span>
                        <p>Start by blocking out your silhouette first. Low-poly is all about simplicity of form.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 day ago</span>
                        <p>Reduce unnecessary vertices; aim for the lowest poly count while retaining the character's shape.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">20 hours ago</span>
                        <p>Mirror components (like limbs) to cut down on modeling time.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">18 hours ago</span>
                        <p>Start from primitives — cubes, cylinders — then extrude and move from there.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Daniel</span> <span class="text-gray-500 ml-2 text-sm">15 hours ago</span>
                        <p>Limit details; focus on strong silhouette over small details.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">10 hours ago</span>
                        <p>Consider color and texture to add depth instead of geometry.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">9 hours ago</span>
                        <p>Remove hidden faces — they add needless polygons.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">7 hours ago</span>
                        <p>For mobile games, aim for under 1,000 polys per character if you can.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">5 hours ago</span>
                        <p>Using flat colors or simple gradients can be more stylish than heavy texture details.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Remove small geometry that the camera will barely see during gameplay.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Bake details into normal maps instead of adding geometry.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Good UV mapping lets you reuse texture space efficiently.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Avoid overcomplicating topology; keep it clean and simple for easier rigging and skinning.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">30 minutes ago</span>
                        <p>Consider adding a small amount of asymmetry to make models more organic.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">20 minutes ago</span>
                        <p>Reduce texture resolution if the game view will be far from the character.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">15 minutes ago</span>
                        <p>Consider using a small color palette for a cohesive style across all models.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">10 minutes ago</span>
                        <p>Watch your edge flow; proper edge loops help keep low-poly models deform nicely.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">5 minutes ago</span>
                        <p>Consider adding small details with texture instead of adding more geometry.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">3 minutes ago</span>
                        <p>Using a consistent scale across models helps keep your scene coherent.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                        <p>Final Tip: Less is more — simplicity often makes your game look more polished.</p>
                    </li>
                </ul>



                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>