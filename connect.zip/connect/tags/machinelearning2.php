<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>James's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-semibold">
                                James Peterson <span class="text-blue-500 font-normal">• ML Researcher</span>
                            </p>
                            <p class="text-xs text-gray-500">3 days ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    Why is transfer learning so popular in computer vision tasks?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Transfer</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">CV</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Pretrained</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 14.000 Views</span>
                        <span>🤍 500 Likes</span>
                        <span>💬 60 Comments</span>
                    </div>
                    <a
                        href="./machinelearning.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to Machine Learning
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 day ago</span>
                        <p>It lets you reuse knowledge from large, pre-trained models instead of starting from scratch.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">23 hours ago</span>
                        <p>Training from zero is expensive and data-intensive; transfer cuts down both.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">20 hours ago</span>
                        <p>Pre-trained models already learn rich, universal features useful across many tasks.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">18 hours ago</span>
                        <p>It saves a huge amount of computational resources and time during training.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">17 hours ago</span>
                        <p>Allows you to achieve great performance with small amounts of labeled data.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">16 hours ago</span>
                        <p>Helps to avoid overfitting when your own training set isn’t large enough.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">15 hours ago</span>
                        <p>Pre-trained nets already know low-level patterns — edges, colors, texture — universal to images.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">14 hours ago</span>
                        <p>It lets you leverage vast amounts of knowledge from large benchmark datasets like ImageNet.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">13 hours ago</span>
                        <p>Using transfer, you fine-tune only the last few layers instead of the whole network.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">12 hours ago</span>
                        <p>This reduces training time and computing power requirements dramatically.</p>
                    </li>

                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">11 hours ago</span>
                        <p>It makes developing specialized models much faster and cheaper.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">10 hours ago</span>
                        <p>Helps practitioners without huge computing clusters to compete.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">9 hours ago</span>
                        <p>The weights already capture universal components of images.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">8 hours ago</span>
                        <p>It avoids the need to learn from messy, small, specialized datasets directly.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">7 hours ago</span>
                        <p>The models already know how to extract useful features immediately upon fine-tuning.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">6 hours ago</span>
                        <p>Effective for a huge range of tasks — from object detection to segmentation — with tiny tweaks.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">5 hours ago</span>
                        <p>Transfer lets you leverage knowledge from a rich, large, well-labeled domain.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Generalized feature detectors help models adapt quickly to new problems.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Saves resources by not needing to learn everything from raw pixels again.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Pre-trained nets act as strong baseline models for numerous tasks.</p>
                    </li>

                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>Effective when labeled data is scarce and expensive to produce.</p>
                    </li>
                </ul>


                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>