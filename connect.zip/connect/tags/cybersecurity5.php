<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Charlie's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-semibold">
                                Charlie Lee <span class="text-blue-500 font-normal">• Security Researcher</span>
                            </p>
                            <p class="text-xs text-gray-500">5 days ago</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    What's the future of password authentication?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">authentication</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">human-2fa</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">future</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 9.000 Views</span>
                        <span>🤍 400 Likes</span>
                        <span>💬 25 Comments</span>
                    </div>
                    <a
                        href="./cybersecurity.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to Cyber Security
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 day ago</span>
                        <p>The future of password authentication is moving toward passwordless methods, like biometrics or phone authentication.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">23 hours ago</span>
                        <p>Passkeys, backed by FIDO, are a growing standard to replace traditional password authentication.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">20 hours ago</span>
                        <p>Biometric authentication, like fingerprint and face recognition, is becoming more popular and reliable.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">18 hours ago</span>
                        <p>The future will likely be a hybrid approach — password plus phone, face, or fingerprint.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">17 hours ago</span>
                        <p>Passkeys use public-private key pairs, making phishing attacks much less effective.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">15 hours ago</span>
                        <p>Single Sign-On (SSO) will become more ubiquitous, reducing password reuse across sites.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">14 hours ago</span>
                        <p>Public key cryptography lets you authenticate without sending a password over the network.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">13 hours ago</span>
                        <p>Using phone’s Face ID or Touch ID makes authentication faster and more convenient.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">12 hours ago</span>
                        <p>The industry is shifting toward a passwordless future to combat phishing and weak password habits.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">11 hours ago</span>
                        <p>Some companies are already adopting WebAuthn to streamline authentication across platforms.</p>
                    </li>

                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">10 hours ago</span>
                        <p>The future might combine multi-layered factors — something you have, something you know, and something you are.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">9 hours ago</span>
                        <p>Reducing password reuse and weak credentials will cut back account takeover attacks significantly.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">8 hours ago</span>
                        <p>Biometric and phone-based methods will become the new standard for consumer authentication.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">7 hours ago</span>
                        <p>Security tokens, like YubiKeys, will be a key piece in enterprise passwordless strategies.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">6 hours ago</span>
                        <p>AI may help identify anomalous authentication patterns and block suspicious attempts in real time.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">5 hours ago</span>
                        <p>The future will be more about verifying “who you are” instead of “what you know.”</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Non-password methods cut back on phishing, credential stuffing, and password reuse attacks.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>As smartphones become universal, phone-native authentication will become more dominant.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>The future will be about simplifying the login experience while strengthening security at the same time.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Passwordless will help companies cut password-related help desk calls and fraud losses.</p>
                    </li>

                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Open standards like FIDO2 and WebAuthn will drive interoperability across platforms.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>The future will be a passwordless ecosystem, supported by smartphones, hardware tokens, and biometrics.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>This move will simplify the login process and make it more convenient for everyone.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>The future focuses on reducing password-related cybercrime, which makes up a huge portion of attacks today.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Ultimately, password authentication will become a fallback, not a primary method of securing accounts.</p>
                    </li>
                </ul>

                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>