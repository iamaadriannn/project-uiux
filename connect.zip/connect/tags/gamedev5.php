<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>David's Thread - ConnecTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#e9f0f7] font-sans">
    <?php include '../navbar.php'; ?>
    <div class="flex">
        <?php include '../sidebar.php'; ?>
        <main class="flex-1 ml-64 p-6 pt-20">
            <div class="bg-white p-6 rounded-xl shadow mb-6">
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center space-x-3">
                        <img src="https://via.placeholder.com/40" alt="User Photo" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-semibold">
                                David Kim <span class="text-blue-500 font-normal">• UI/UX Designer</span>
                            </p>
                            <p class="text-xs text-gray-500">yesterday</p>
                        </div>
                    </div>
                    <button class="text-gray-400 text-xl">⋯</button>
                </div>

                <p class="text-sm font-semibold mb-4">
                    UI best practices for game menus and HUDs?
                </p>

                <div class="flex flex-wrap gap-2 text-xs mb-4">
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">UI</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Design</span>
                    <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full">HUD</span>
                </div>

                <div class="flex items-center justify-between text-xs text-gray-500">
                    <div class="flex gap-4 items-center">
                        <span>👁 7.500 Views</span>
                        <span>🤍 250 Likes</span>
                        <span>💬 30 Comments</span>
                    </div>
                    <a
                        href="./mobiledev.php"
                        class="text-blue-500 hover:underline">
                        &larr; Back to Game Development
                    </a>
                </div>
            </div>

            <!-- Comments Section -->
            <div id="comments" class="bg-gray-100 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-4">Comments</h2>

                <ul id="commentList" class="space-y-4 mb-4">
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">1 day ago</span>
                        <p>Keep menus simple and clear; avoid overloading players with information.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 day ago</span>
                        <p>Design menus to match the game’s style and mood to maintain immersion.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">20 hours ago</span>
                        <p>Avoid placing crucial UI elements in the center; use borders or corners instead.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">18 hours ago</span>
                        <p>Design menus to be navigable with a controller, mouse, or keyboard smoothly.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Daniel</span> <span class="text-gray-500 ml-2 text-sm">15 hours ago</span>
                        <p>Consistency in button placement makes menus more intuitive to use.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">10 hours ago</span>
                        <p>Design HUD to show health, ammo, and quest info at a quick glance — not overwhelm players.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">9 hours ago</span>
                        <p>Use color-coding or icons to help players quickly identify elements in the HUD.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">7 hours ago</span>
                        <p>Avoid adding needless details; simplicity lets players focus on gameplay first.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">5 hours ago</span>
                        <p>Consider different screen sizes; UI should be responsive across platforms.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">4 hours ago</span>
                        <p>Design menus to minimize the number of menus a player must navigate through.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">3 hours ago</span>
                        <p>Consider adding hover or tooltips to clarify icon meanings when needed.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">2 hours ago</span>
                        <p>A clear visual hierarchy guides the player's eyes naturally.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">1 hour ago</span>
                        <p>Using contrast and bold highlights can draw attention to key UI components.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">30 minutes ago</span>
                        <p>Design menus to be scalable for future content without messy expansion.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">20 minutes ago</span>
                        <p>Consider adding audio or hover effects to give players feedback.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">15 minutes ago</span>
                        <p>A well-structured UI lets players find what they need quickly.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">10 minutes ago</span>
                        <p>Design menus to match the pace and mood of your game (slow vs fast-paced).</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">9 minutes ago</span>
                        <p>Consider adding shortcuts or hotkeys for frequently used menus.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">8 minutes ago</span>
                        <p>Design menus to be consistent across all screens (inventory, settings, quests).</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">7 minutes ago</span>
                        <p>A small amount of animation can make menus feel more alive and polished.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">6 minutes ago</span>
                        <p>Design for clarity first — fancy UI shouldn’t undermine functionality.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">5 minutes ago</span>
                        <p>Consider adding customization options to match players’ preferences.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">4 minutes ago</span>
                        <p>Design menus to be readable at a distance for players sitting far from the TV.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">3 minutes ago</span>
                        <p>A consistent color scheme ties all UI components together nicely.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">2 minutes ago</span>
                        <p>Design menus to be easily navigable with both a controller and mouse.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">1 minute ago</span>
                        <p>Consider adding brief instructional text or icon hints where helpful.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Mike</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                        <p>A well-laid UI lets players focus more on gameplay instead of menus.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Sophie</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                        <p>Design menus with clear, actionable choices to avoid confusion.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">James</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                        <p>Avoid overcomplicating UI; simplicity often results in a better UX.</p>
                    </li>
                    <li class="bg-gray-50 p-4 rounded shadow">
                        <span class="font-semibold">Charlie</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                        <p>Final Tip: Always test UI with real players for feedback and tweaks.</p>
                    </li>
                </ul>


                <input id="commentInput"
                    type="text"
                    placeholder="Add a comment…"
                    class="w-full p-2 mb-2 border rounded outline-none">

                <button id="addCommentBtn"
                    class="bg-[#2c4c66] text-gray-100 px-4 py-1 rounded">
                    Comment
                </button>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('addCommentBtn').addEventListener('click', () => {
            const comment = document.getElementById('commentInput').value.trim();

            if (comment !== '') {
                const ul = document.getElementById('commentList');

                const li = document.createElement('li');
                li.className = 'bg-gray-50 p-4 rounded shadow';
                li.innerHTML = `
                    <span class="font-semibold">You</span> <span class="text-gray-500 ml-2 text-sm">just now</span>
                    <p>${comment}</p>
                `;

                ul.prepend(li);
                document.getElementById('commentInput').value = '';
            }
        });
    </script>
</body>

</html>