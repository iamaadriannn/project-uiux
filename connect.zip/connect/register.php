<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>ConnecTech - Register</title>
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', sans-serif;
    }

    html, body {
      height: 100%;
    }

    .bg-image {
      position: relative;
      height: 100vh;
      background-image: url('login.jpg'); 
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      background-color: #888;
    }

    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      background-color: rgba(0, 0, 0, 0.4);
    }

    .branding {
      position: absolute;
      top: 50%;
      left: 10%;
      transform: translateY(-50%);
      color: #fff;
    }

    .branding h1 {
      font-size: 48px;
      font-weight: bold;
    }

    .branding p {
      font-size: 18px;
      margin-top: 8px;
    }

    .form-box {
      position: absolute;
      top: 50%;
      right: 10%;
      transform: translateY(-50%);
      background-color: rgba(255, 255, 255, 0.5);
      padding: 30px;
      border-radius: 32px;
      width: 300px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      color: #fff;
    }

    .form-box label {
      font-size: 14px;
      color: #fff;
      display: block;
      margin-bottom: 5px;
    }

    .form-box input {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 6px;
    }

    .password-wrapper {
      position: relative;
    }

    .toggle-password {
      position: absolute;
      top: 50%;
      right: 10px;
      transform: translateY(-50%);
      background: none;
      border: none;
      cursor: pointer;
      font-size: 16px;
      color: #2a4e7d;
    }

    .form-box button[type="submit"] {
      width: 100%;
      padding: 10px;
      background-color: #2a4e7d;
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .form-box button:hover {
      background-color: #1f3c61;
    }

    .form-box .login-link {
      text-align: center;
      margin-top: 10px;
      font-size: 14px;
    }

    .form-box .login-link a {
      color: #fff;
      text-decoration: underline;
    }

    @media (max-width: 768px) {
      .branding, .form-box {
        left: 5%;
        right: 5%;
        width: 90%;
        transform: translateY(-50%);
      }

      .branding h1 {
        font-size: 36px;
      }

      .form-box {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
  <div class="bg-image">
    <div class="overlay"></div>

    <div class="branding">
      <h1>ConnecTech</h1>
      <p>Join the Network Without Limits</p>
    </div>

    <form class="form-box" onsubmit="handleRegister(event)">
      <label for="name">Full Name</label>
      <input type="text" id="name" placeholder="Enter your full name" required />

      <label for="email">Email</label>
      <input type="email" id="email" placeholder="Enter your email" required />

      <label for="password">Password</label>
      <div class="password-wrapper">
        <input type="password" id="password" placeholder="Create a password" required />
        <button type="button" class="toggle-password" onclick="toggleVisibility('password', this)">
          <i class="fas fa-eye"></i>
        </button>
      </div>

      <label for="confirmPassword">Confirm Password</label>
      <div class="password-wrapper">
        <input type="password" id="confirmPassword" placeholder="Repeat your password" required />
        <button type="button" class="toggle-password" onclick="toggleVisibility('confirmPassword', this)">
          <i class="fas fa-eye"></i>
        </button>
      </div>

      <button type="submit">CREATE ACCOUNT</button>

      <div class="login-link">
        Already have an account? <a href="login.php">Login</a>
      </div>
    </form>
  </div>

  <script>
    function toggleVisibility(inputId, btn) {
      const input = document.getElementById(inputId);
      const icon = btn.querySelector('i');

      if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");
      } else {
        input.type = "password";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
      }
    }

    function handleRegister(event) {
  event.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirmPassword").value;

  // Validasi nama kosong
  if (name === "") {
    alert("Full name is required!");
    return;
  }

  // Validasi email sederhana
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    alert("Invalid email format!");
    return;
  }

  // Validasi panjang password
  if (password.length < 6) {
    alert("Password must be at least 6 characters!");
    return;
  }

  // Validasi kecocokan password
  if (password !== confirmPassword) {
    alert("Passwords do not match!");
    return;
  }

  // Simpan user ke localStorage (simulasi backend)
  const existingUser = JSON.parse(localStorage.getItem("dummyUser"));
    if (existingUser && existingUser.email === email) {
    alert("Email already registered!");
    return;
    }

  localStorage.setItem("dummyUser", JSON.stringify({
    name,
    email,
    password
  }));

  alert("Account created successfully!");
  window.location.href = "login.php"; // Redirect ke halaman login
}

  </script>
</body>
</html>
